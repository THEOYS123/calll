import express from 'express';
import path from 'path';
import fs from 'fs';
import multer from 'multer';
import { createServer as createViteServer } from 'vite';
import {
  TelegramBotInfo,
  TokenValidationResult,
  BotLogEntry,
  BotUserEntry,
  CustomCommand,
  AutoReplyRule,
  BotStats,
  BotStatusState,
  OsintApiKey,
  OsintConfig,
  CustomMenuItem,
  OsintSearchHistoryItem,
  GithubSyncConfig,
  GithubTestResult,
  GroupConfig,
  KnownTelegramGroup,
  QuotaConfig,
  BotMenuConfig,
  ModerationConfig,
  ModerationIncident,
  SpikeAlertItem
} from './src/types';
import { extractLocationFromNik } from './src/utils/nikAnalyzer';
import {
  getAllDatasetFiles,
  readDatasetContent,
  writeDatasetContent,
  deleteDatasetFile,
  smartSearchDatasets,
  sanitizeDatasetFilename,
  isForbiddenDatasetName,
  parseGithubUrl,
  testGithubDataset,
  syncGithubDataset,
  DATASETS_DIR,
  DEFAULT_DATASET_FILE
} from './src/server/datasetEngine';

// Path for persistent bot storage
const DATA_DIR = path.join(process.cwd(), 'data');
const CONFIG_FILE = path.join(DATA_DIR, 'bot_config.json');
const SEARCH_CACHE_DIR = path.join(DATA_DIR, 'search_cache');

// Ensure data and search_cache directories exist
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}
if (!fs.existsSync(SEARCH_CACHE_DIR)) {
  fs.mkdirSync(SEARCH_CACHE_DIR, { recursive: true });
}

// Multer Storage for Datasets - Unlimited File Size (Tidak Ada Batasan Maksimal)
const datasetUploadStorage = multer.diskStorage({
  destination: (req, file, cb) => {
    if (!fs.existsSync(DATASETS_DIR)) {
      fs.mkdirSync(DATASETS_DIR, { recursive: true });
    }
    cb(null, DATASETS_DIR);
  },
  filename: (req, file, cb) => {
    const sanitized = sanitizeDatasetFilename(file.originalname || 'dataset.txt');
    if (isForbiddenDatasetName(sanitized)) {
      return cb(new Error(`Nama berkas '${sanitized}' adalah berkas konfigurasi sistem dan tidak dapat diunggah sebagai dataset.`), '');
    }
    cb(null, sanitized);
  }
});

const datasetUpload = multer({
  storage: datasetUploadStorage,
  limits: {
    fileSize: Infinity // No maximum size limit, as explicitly requested!
  }
});

// Default OSINT Configuration
const DEFAULT_OSINT_CONFIG: OsintConfig = {
  enabled: false, // Default is OFF: must be explicitly turned on by owner
  ngrokUrl: 'https://dd60-180-247-62-62.ngrok-free.app',
  ownerUsername: '@flood1233',
  notifyOnStatusChange: true,
  searchEngineMode: 'smart_dataset', // Smart auto-search dataset.txt is primary!
  apiKeys: [
    {
      id: 'key-default-ppp',
      key: 'ppp',
      ownerNotes: 'Default API Key Contoh dari Owner',
      tier: 'limited',
      initialQuota: 10,
      remainingQuota: 10,
      bonusQuota: 1, // Bonus 1x untuk pembelian >= 10k
      totalUsed: 0,
      createdAt: new Date().toISOString(),
      enabled: true
    },
    {
      id: 'key-vip-unlimited',
      key: 'vip-unlimited',
      ownerNotes: 'Paket Unlimited VIP Owner',
      tier: 'unlimited',
      initialQuota: 999999,
      remainingQuota: 999999,
      bonusQuota: 0,
      totalUsed: 0,
      createdAt: new Date().toISOString(),
      enabled: true
    }
  ]
};

// In-Memory & Persistent Bot State
interface StoredBotConfig {
  token: string;
  isActive: boolean;
  welcomeMessage: string;
  customCommands: CustomCommand[];
  autoReplies: AutoReplyRule[];
  customMenus: CustomMenuItem[];
  stats: BotStats;
  activeUsers: BotUserEntry[];
  osintConfig: OsintConfig;
  searchHistories?: OsintSearchHistoryItem[];
  githubSync?: GithubSyncConfig;
  groupConfig?: GroupConfig;
  quotaConfig?: QuotaConfig;
  menuConfig?: BotMenuConfig;
  moderationConfig?: ModerationConfig;
  lastPollingOffset?: number;
}

const DEFAULT_MODERATION_CONFIG: ModerationConfig = {
  enabled: true,
  deleteInGroups: true,
  deleteInPrivate: true,
  sendExplanationMessage: true,
  autoDeleteExplanationSeconds: 0,

  blockGamblingSlot: true,
  blockAdult18Plus: true,
  blockDrugs: true,
  blockFraudScam: true,
  blockWeaponsExplosives: true,

  allowCyberAndOsint: true,
  cyberWhitelistKeywords: [
    'cyber', 'osint', 'intel', 'pentest', 'penetration testing', 'exploit',
    'breach', 'leak', 'kebocoran data', 'hacking', 'ethical hacking', 'hacker',
    'security', 'cve', 'vulnerability', 'payload', 'reverse engineering',
    'malware', 'bug bounty', 'infosec', 'deface', 'soc', 'threat intelligence',
    'nik', 'dox', 'doxing', 'tracer', 'recon', 'kali linux', 'shodan',
    'sql injection', 'xss', 'rce', 'zeroday', '0day', 'forensic', 'darkweb'
  ],

  customBannedKeywords: [],
  whitelistKeywords: [],
  recentIncidents: []
};

const DEFAULT_QUOTA_CONFIG: QuotaConfig = {
  newUserQuotaEnabled: true, // Bonus kuota sambutan aktif
  newUserQuotaAmount: 5, // Default +5x kuota pencarian gratis
  dailyQuotaEnabled: true, // Klaim kuota gratis harian aktif
  dailyQuotaAmount: 2, // Default +2x kuota harian
  dailyResetHourWib: 0, // Reset pukul 00:00 WIB
  deductQuotaOnlyOnFound: true, // Hanya kurangi kuota jika target ditemukan di dataset
  allowSearchWithoutApiKey: true, // Otomatis pakai kuota pribadi pengguna
  quotaCostPerSearch: 1 // 1 kuota per pencarian berhasil
};

const DEFAULT_MENU_CONFIG: BotMenuConfig = {
  welcomeMessageHeader: '👋 *Halo! Selamat datang di axxosintbot Intelligence & Automation (Created by Ax.).*',
  showClaimButtonInMenu: true,
  showQuotaButtonInMenu: true,
  showOsintButtonInMenu: true,
  showPriceButtonInMenu: true,
  showOwnerButtonInMenu: true,
  showHelpButtonInMenu: true,
  customButtons: []
};

const DEFAULT_GITHUB_SYNC: GithubSyncConfig = {
  url: 'https://github.com/THEOYS123/track-call/blob/main/data/dataset.txt',
  rawUrl: 'https://raw.githubusercontent.com/THEOYS123/track-call/main/data/dataset.txt',
  targetFilename: 'dataset.txt',
  replacePrimary: true,
  lastSyncStatus: 'idle',
  autoSyncEnabled: false
};

const DEFAULT_GROUP_CONFIG: GroupConfig = {
  allowGroups: true, // Izinkan bot merespon di grup Telegram
  groupAdminOnly: false, // Perintah dapat dijalankan semua anggota grup atau hanya admin
  silentFallbackInGroup: true, // Cegah spam: Abaikan obrolan santai/biasa di grup (Hanya respon /command & search:)
  allowAllCommandsInGroup: true,
  enableAntiFlood: true, // Anti-spam rate limiting & protection
  antiFloodCooldownSeconds: 3, // Jeda minimal 3 detik antar perintah per pengguna
  allowedGroupIds: [],
  blockedGroupIds: [],
  knownGroups: []
};

const DEFAULT_WELCOME_MESSAGE = `👋 *Halo! Selamat datang di axxosintbot Intelligence & Automation.*

Saya adalah *axxosintbot*, bot intelijen & profiling otomatis yang diciptakan oleh *Ax.* (@flood1233).

Silakan gunakan tombol menu interaktif di bawah atau ketik perintah:
• /id - Cek Chat ID & status verifikasi akun
• /osint - Status & pencarian Intelijen OSINT
• /history - Riwayat pencarian OSINT pribadi Anda
• /harga - Daftar harga & kuota API Key
• /bot - Detail & spesifikasi bot
• /ping - Cek latency & status server
• /waktu - Cek jam real-time Indonesia
• /help - Bantuan & daftar perintah lengkap`;

const DEFAULT_CUSTOM_COMMANDS: CustomCommand[] = [
  {
    id: 'cmd-1',
    command: 'kontak',
    description: 'Informasi kontak resmi owner bot (@flood1233)',
    replyText: '📞 *KONTAK RESMI OWNER BOT*\n\nSilakan hubungi owner di Telegram:\n👤 @flood1233\n_(Bebas mau chat ataupun call, asal tidak spam)_',
    enabled: true
  },
  {
    id: 'cmd-2',
    command: 'fitur',
    description: 'Ringkasan fitur utama bot Telegram',
    replyText: '⚡ *FITUR UTAMA BOT*\n\n1. Verifikasi Wajib /id Akun Pengguna\n2. Server OSINT Intelijen (Ngrok API Key)\n3. Cek Status Kuota API Key Realtime\n4. Deteksi Mata Uang Sesuai Negara (IDR/USD/MYR/SGD)\n5. Notifikasi Otomatis Broadcast Status Server\n6. Menu Rahasia Owner (ax0895)',
    enabled: true
  }
];

const DEFAULT_AUTO_REPLIES: AutoReplyRule[] = [
  {
    id: 'ar-1',
    triggerKeyword: 'halo',
    matchType: 'contains',
    replyText: 'Halo juga! Ada yang bisa saya bantu? Ketik /menu untuk melihat opsi yang tersedia.',
    enabled: true
  },
  {
    id: 'ar-2',
    triggerKeyword: 'assalamualaikum',
    matchType: 'contains',
    replyText: 'Waalaikumsalam warahmatullahi wabarakatuh! Selamat datang, ketik /menu untuk bantuan.',
    enabled: true
  },
  {
    id: 'ar-3',
    triggerKeyword: 'siapa kamu',
    matchType: 'contains',
    replyText: 'Saya adalah Bot Telegram cerdas yang selalu aktif 24/7 dan dikontrol melalui Website Controller.',
    enabled: true
  },
  {
    id: 'ar-4',
    triggerKeyword: 'p',
    matchType: 'exact',
    replyText: 'Ya, bot online dan siap merespon! Ketik /id untuk cek Chat ID dan verifikasi akun kamu.',
    enabled: true
  }
];

const DEFAULT_CUSTOM_MENUS: CustomMenuItem[] = [
  {
    id: 'menu-promo',
    label: '🎁 Info Promo & Bonus',
    type: 'callback',
    responseText: '🎉 *PROMOSI SPESIAL API KEY OSINT:*\n\n• Pembelian paket Rp 10.000 ke atas langsung dapat +1x BONUS pakai!\n• Pembelian paket Rp 50.000 dapat +2x BONUS pakai!\n• Paket Unlimited Rp 100.000 bebas pakai selamanya tanpa batas!\n\nHubungi Owner Telegram: @flood1233\n_(Bebas mau chat ataupun call, asal tidak spam)_',
    enabled: true
  },
  {
    id: 'menu-rules',
    label: '📜 Ketentuan & Panduan',
    type: 'callback',
    responseText: '📜 *KETENTUAN PENGGUNAAN BOT:*\n\n1. Semua pengguna baru wajib verifikasi awal via perintah /id.\n2. Fitur OSINT hanya dapat digunakan saat Server diaktifkan (ON) oleh Owner.\n3. Gunakan API Key resmi dari Owner @flood1233.\n4. Format pencarian: `search: <target> <apiKey>`\n5. Dilarang melakukan spamming request.',
    enabled: true
  },
  {
    id: 'menu-faq',
    label: '❓ Tanya Jawab (FAQ)',
    type: 'callback',
    responseText: '❓ *PERTANYAAN UMUM (FAQ):*\n\nQ: Mengapa fitur OSINT tertulis OFF?\nA: Server OSINT sedang di-offline kan oleh owner. Hubungi @flood1233 untuk meminta menyalakan server.\n\nQ: Bagaimana cara mendapatkan API Key?\nA: Silakan hubungi Owner di Telegram: @flood1233\n\nQ: Bagaimana jika server ngrok mati saat pencarian?\nA: Kuota API Key Anda TIDAK akan dipotong.',
    enabled: true
  }
];

let botConfig: StoredBotConfig = {
  token: process.env.TELEGRAM_BOT_TOKEN || '',
  isActive: false,
  welcomeMessage: DEFAULT_WELCOME_MESSAGE,
  customCommands: DEFAULT_CUSTOM_COMMANDS,
  autoReplies: DEFAULT_AUTO_REPLIES,
  customMenus: DEFAULT_CUSTOM_MENUS,
  stats: {
    messagesReceived: 0,
    messagesSent: 0,
    commandsExecuted: 0,
    activeUsersCount: 0,
    osintSearchesCount: 0
  },
  activeUsers: [],
  osintConfig: DEFAULT_OSINT_CONFIG,
  searchHistories: [],
  githubSync: DEFAULT_GITHUB_SYNC,
  groupConfig: DEFAULT_GROUP_CONFIG,
  quotaConfig: DEFAULT_QUOTA_CONFIG,
  menuConfig: DEFAULT_MENU_CONFIG
};

let recentLogs: BotLogEntry[] = [];
let botStartedAt: number | null = null;
let lastError: string | null = null;
let currentBotInfo: TelegramBotInfo | null = null;
let isPollingRunning = false;
let pollingAbortController: AbortController | null = null;
let pollingOffset = 0;
let lastPollingTimestamp: string | null = null;

// Concurrency lock to prevent race-condition exploits on claiming quotas
const activeClaimLocks = new Set<string>();

// Persistent claimed new user IDs (strict 1x lifetime shield)
const CLAIMED_USERS_FILE = path.join(DATA_DIR, 'claimed_new_users.json');
let persistentClaimedUserIds = new Set<number>();
function loadPersistentClaimedUsers() {
  try {
    if (fs.existsSync(CLAIMED_USERS_FILE)) {
      const data = JSON.parse(fs.readFileSync(CLAIMED_USERS_FILE, 'utf8'));
      if (Array.isArray(data)) {
        persistentClaimedUserIds = new Set(data.map(Number));
      }
    }
  } catch {}
}
function savePersistentClaimedUsers() {
  try {
    fs.writeFileSync(CLAIMED_USERS_FILE, JSON.stringify(Array.from(persistentClaimedUserIds)), 'utf8');
  } catch {}
}
loadPersistentClaimedUsers();

// Anti-Spam, Deduplication & Anti-Flood State
const processedUpdateIds = new Set<number>();
const processedMessageIds = new Set<string>();
const lastUserActionTimestamp = new Map<string, number>();
const floodWarningSentTimestamps = new Map<string, number>();
const activeDownloads = new Set<string>();

// 1. Hot In-Memory Search Cache (Speed & Resource Optimization: sub-millisecond repeated queries)
interface SearchCacheEntry {
  result: any;
  cachedAt: number;
}
const hotSearchCache = new Map<string, SearchCacheEntry>();
const SEARCH_CACHE_TTL_MS = 60 * 1000; // 60s TTL

// 2. Suspicious Search Spike Detection & Threshold System
interface SearchEventRecord {
  timestamp: number;
  chatId: number | string;
  userName: string;
  target: string;
}
let recentSearchEvents: SearchEventRecord[] = [];
let recentSpikeAlerts: SpikeAlertItem[] = [];

function recordSearchAndDetectSpike(chatId: number | string, userName: string, target: string): SpikeAlertItem | null {
  const now = Date.now();
  recentSearchEvents.push({ timestamp: now, chatId, userName, target });

  // Prune events older than 60 seconds
  recentSearchEvents = recentSearchEvents.filter((ev) => now - ev.timestamp <= 60000);

  // Check 1: Global Surge (>= 5 queries in last 30s)
  const window30s = recentSearchEvents.filter((ev) => now - ev.timestamp <= 30000);
  const globalCount = window30s.length;

  // Check 2: Single User Burst (>= 3 queries in last 10s by same user)
  const user10s = recentSearchEvents.filter((ev) => String(ev.chatId) === String(chatId) && now - ev.timestamp <= 10000);
  const userCount = user10s.length;

  let alertItem: SpikeAlertItem | null = null;

  if (globalCount >= 5) {
    alertItem = {
      id: `spike_${now}_${Math.random().toString(36).substring(2, 6)}`,
      timestamp: new Date().toISOString(),
      queryCount: globalCount,
      threshold: 5,
      windowSeconds: 30,
      triggerType: 'global_surge',
      chatId,
      userName,
      targetSample: target,
      severity: globalCount >= 10 ? 'critical' : 'warning',
      details: `Lonjakan aktivitas global: ${globalCount} pencarian dalam 30 detik.`
    };
  } else if (userCount >= 3) {
    alertItem = {
      id: `spike_${now}_${Math.random().toString(36).substring(2, 6)}`,
      timestamp: new Date().toISOString(),
      queryCount: userCount,
      threshold: 3,
      windowSeconds: 10,
      triggerType: 'user_burst',
      chatId,
      userName,
      targetSample: target,
      severity: userCount >= 6 ? 'high' : 'warning',
      details: `Lonjakan cepat dari satu pengguna: ${userCount} pencarian dalam 10 detik.`
    };
  }

  if (alertItem) {
    const lastAlert = recentSpikeAlerts[0];
    if (!lastAlert || now - new Date(lastAlert.timestamp).getTime() > 12000) {
      recentSpikeAlerts.unshift(alertItem);
      if (recentSpikeAlerts.length > 30) recentSpikeAlerts.pop();

      addLog(
        'warn',
        `🚨 [SUSPICIOUS SEARCH SPIKE] Lonjakan terdeteksi: ${alertItem.queryCount} query dalam ${alertItem.windowSeconds}s (${userName}, ID: ${chatId}, target: "${target}")`,
        chatId,
        userName
      );
    }
    return alertItem;
  }

  return null;
}

// 3. Adaptive Security Shield (Balanced rate limiting: protects against automated DDoS/scrapers without blocking legit cyber researchers)
const userBurstTracker = new Map<string, number[]>();

function checkAdaptiveSecurityBurst(
  fromId: number | string,
  chatId: number | string,
  senderName: string
): { isBlocked: boolean; message?: string } {
  const key = String(fromId);
  const now = Date.now();
  const history = userBurstTracker.get(key) || [];

  const recent = history.filter((t) => now - t <= 10000);
  recent.push(now);
  userBurstTracker.set(key, recent);

  // Severe automated scraper flood (> 14 requests in 10s)
  if (recent.length > 14) {
    addLog(
      'warn',
      `🛡️ [SECURITY DEFENSE] Terdeteksi flood otomatis (${recent.length} req/10s) dari ${senderName} (ID: ${fromId}). Soft cooldown diaktifkan.`,
      chatId
    );
    return {
      isBlocked: true,
      message: `🛡️ *Keamanan Sistem (Adaptive Security Shield)*\nTerdeteksi frekuensi permintaan otomatis yang terlalu cepat (${recent.length} req/10s).\nUntuk menjaga stabilitas server bagi semua pengguna, silakan tunggu *15 detik* sebelum melanjutkan.`
    };
  }

  // Moderate rapid burst (> 4 requests in 5s)
  const in5s = recent.filter((t) => now - t <= 5000);
  if (in5s.length > 4) {
    return {
      isBlocked: true,
      message: `⏳ *Jeda Keamanan (Anti-Burst Protection)*\nAnda mengirim permintaan terlalu cepat (${in5s.length}x berturut-turut). Mohon jeda *4 detik* agar proses pencarian dataset selesai secara optimal.`
    };
  }

  return { isBlocked: false };
}

// 4. Query Normalizer & Sanitizer (Fuzzy phone numbers, cleaned NIKs, anti-injection)
function sanitizeAndNormalizeQuery(rawQuery: string): { clean: string; isValid: boolean; reason?: string } {
  if (!rawQuery || typeof rawQuery !== 'string') {
    return { clean: '', isValid: false, reason: 'Query kosong.' };
  }

  let text = rawQuery.trim();

  // Defense against null byte / directory traversal
  if (text.includes('\0') || text.includes('../') || text.includes('..\\')) {
    return { clean: '', isValid: false, reason: 'Karakter terlarang (null byte / directory traversal) terdeteksi.' };
  }

  // Max query length protection (100 characters max, prevent buffer bloat)
  if (text.length > 100) {
    text = text.substring(0, 100);
  }

  // Clean NIK spaces if 16-digit like "3201 0101 0190 0001" -> "3201010101900001"
  const cleanDigits = text.replace(/[\s\-_.]/g, '');
  if (/^\d{16}$/.test(cleanDigits)) {
    return { clean: cleanDigits, isValid: true };
  }

  // Normalize phone number (e.g. +62812-3456-7890 -> clean formats)
  if (/^(\+62|62|0)8[1-9][0-9]{6,11}$/.test(cleanDigits)) {
    return { clean: cleanDigits, isValid: true };
  }

  return { clean: text, isValid: true };
}

// Update or track known Telegram group
function updateKnownGroup(chat: any) {
  if (!chat || (chat.type !== 'group' && chat.type !== 'supergroup')) return;
  if (!botConfig.groupConfig) {
    botConfig.groupConfig = { ...DEFAULT_GROUP_CONFIG };
  }
  if (!Array.isArray(botConfig.groupConfig.knownGroups)) {
    botConfig.groupConfig.knownGroups = [];
  }
  const numericId = Number(chat.id);
  const existing = botConfig.groupConfig.knownGroups.find((g) => g.id === numericId);
  const now = new Date().toISOString();
  if (existing) {
    existing.title = chat.title || existing.title || `Grup ${numericId}`;
    existing.lastSeen = now;
    existing.totalCommands = (existing.totalCommands || 0) + 1;
    existing.status = botConfig.groupConfig.blockedGroupIds?.includes(numericId) ? 'blocked' : 'active';
  } else {
    botConfig.groupConfig.knownGroups.unshift({
      id: numericId,
      title: chat.title || `Grup ${numericId}`,
      type: chat.type,
      firstSeen: now,
      lastSeen: now,
      totalCommands: 1,
      status: botConfig.groupConfig.blockedGroupIds?.includes(numericId) ? 'blocked' : 'active'
    });
  }
  saveBotConfig();
}

// Check if user is Telegram Group Administrator
async function isTelegramGroupAdmin(token: string, chatId: number | string, userId: number): Promise<boolean> {
  try {
    const res = await callTelegramApi(token, 'getChatMember', {
      chat_id: chatId,
      user_id: userId
    }, 4000);
    if (res && res.status) {
      return res.status === 'creator' || res.status === 'administrator';
    }
    return false;
  } catch {
    return false;
  }
}

// Synchronize user personal API key in osintConfig.apiKeys
function syncUserApiKey(user: BotUserEntry) {
  const numericId = Number(user.userId || user.chatId);
  if (!numericId || numericId <= 0) return;
  user.userId = numericId;
  if (!user.chatId || Number(user.chatId) <= 0) {
    user.chatId = numericId;
  }
  user.personalApiKey = `usr_${numericId}`;
  const keyName = user.personalApiKey;

  let matched = botConfig.osintConfig.apiKeys.find((k) => k.key.toLowerCase() === keyName.toLowerCase());
  if (!matched) {
    matched = {
      id: `usr-key-${numericId}`,
      key: keyName,
      ownerNotes: `Kunci Kuota Pribadi: ${user.firstName} (User ID: ${numericId})`,
      tier: 'limited',
      initialQuota: user.personalQuota || 0,
      remainingQuota: user.personalQuota || 0,
      bonusQuota: 0,
      totalUsed: 0,
      createdAt: user.firstSeen || new Date().toISOString(),
      enabled: true
    };
    botConfig.osintConfig.apiKeys.push(matched);
  } else {
    matched.remainingQuota = typeof user.personalQuota === 'number' ? user.personalQuota : 0;
    matched.enabled = true;
  }
}

// Load configuration from disk
function loadBotConfig() {
  try {
    if (fs.existsSync(CONFIG_FILE)) {
      const raw = fs.readFileSync(CONFIG_FILE, 'utf8');
      const parsed = JSON.parse(raw);
      botConfig = {
        token: parsed.token || botConfig.token || '',
        isActive: typeof parsed.isActive === 'boolean' ? parsed.isActive : false,
        welcomeMessage: parsed.welcomeMessage || DEFAULT_WELCOME_MESSAGE,
        customCommands: Array.isArray(parsed.customCommands) ? parsed.customCommands : DEFAULT_CUSTOM_COMMANDS,
        autoReplies: Array.isArray(parsed.autoReplies) ? parsed.autoReplies : DEFAULT_AUTO_REPLIES,
        customMenus: Array.isArray(parsed.customMenus) && parsed.customMenus.length > 0 ? parsed.customMenus : DEFAULT_CUSTOM_MENUS,
        stats: {
          messagesReceived: parsed.stats?.messagesReceived || 0,
          messagesSent: parsed.stats?.messagesSent || 0,
          commandsExecuted: parsed.stats?.commandsExecuted || 0,
          activeUsersCount: Array.isArray(parsed.activeUsers) ? parsed.activeUsers.length : 0,
          osintSearchesCount: parsed.stats?.osintSearchesCount || 0
        },
        activeUsers: Array.isArray(parsed.activeUsers) ? parsed.activeUsers : [],
        osintConfig: parsed.osintConfig ? {
          enabled: typeof parsed.osintConfig.enabled === 'boolean' ? parsed.osintConfig.enabled : false,
          ngrokUrl: parsed.osintConfig.ngrokUrl || DEFAULT_OSINT_CONFIG.ngrokUrl,
          ownerUsername: parsed.osintConfig.ownerUsername || DEFAULT_OSINT_CONFIG.ownerUsername,
          notifyOnStatusChange: typeof parsed.osintConfig.notifyOnStatusChange === 'boolean' ? parsed.osintConfig.notifyOnStatusChange : true,
          searchEngineMode: parsed.osintConfig.searchEngineMode || 'smart_dataset',
          apiKeys: Array.isArray(parsed.osintConfig.apiKeys) && parsed.osintConfig.apiKeys.length > 0 ? parsed.osintConfig.apiKeys : DEFAULT_OSINT_CONFIG.apiKeys,
          lastToggledAt: parsed.osintConfig.lastToggledAt
        } : DEFAULT_OSINT_CONFIG,
        searchHistories: Array.isArray(parsed.searchHistories) ? parsed.searchHistories : [],
        githubSync: parsed.githubSync ? {
          ...DEFAULT_GITHUB_SYNC,
          ...parsed.githubSync
        } : DEFAULT_GITHUB_SYNC,
        groupConfig: parsed.groupConfig ? {
          ...DEFAULT_GROUP_CONFIG,
          ...parsed.groupConfig,
          knownGroups: Array.isArray(parsed.groupConfig.knownGroups) ? parsed.groupConfig.knownGroups : []
        } : DEFAULT_GROUP_CONFIG,
        quotaConfig: parsed.quotaConfig ? {
          ...DEFAULT_QUOTA_CONFIG,
          ...parsed.quotaConfig
        } : DEFAULT_QUOTA_CONFIG,
        menuConfig: parsed.menuConfig ? {
          ...DEFAULT_MENU_CONFIG,
          ...parsed.menuConfig,
          customButtons: Array.isArray(parsed.menuConfig.customButtons) ? parsed.menuConfig.customButtons : []
        } : DEFAULT_MENU_CONFIG,
        lastPollingOffset: typeof parsed.lastPollingOffset === 'number' ? parsed.lastPollingOffset : 0
      };

      if (botConfig.lastPollingOffset && botConfig.lastPollingOffset > 0) {
        pollingOffset = botConfig.lastPollingOffset;
      }

      // Deduplicate activeUsers and normalize quota fields
      if (Array.isArray(botConfig.activeUsers)) {
        const userMap = new Map<number, BotUserEntry>();
        for (const u of botConfig.activeUsers) {
          const cid = Number(u.chatId);
          // Strictly keep human Telegram user accounts (positive numerical IDs)
          if (!cid || cid <= 0) continue;
          if (!userMap.has(cid)) {
            userMap.set(cid, {
              chatId: cid,
              firstName: u.firstName || 'Anonymous',
              lastName: u.lastName || '',
              username: u.username || '',
              firstSeen: u.firstSeen || new Date().toISOString(),
              lastSeen: u.lastSeen || new Date().toISOString(),
              totalMessages: typeof u.totalMessages === 'number' ? u.totalMessages : 1,
              type: 'private',
              isVerified: true, // Permanent official verification for registered users
              verifiedAt: u.verifiedAt || u.firstSeen || new Date().toISOString(),
              languageCode: u.languageCode || 'id',
              hasClaimedNewUserQuota: Boolean(u.hasClaimedNewUserQuota),
              newUserQuotaClaimedAt: u.newUserQuotaClaimedAt,
              dailyQuotaLastClaimedDate: u.dailyQuotaLastClaimedDate,
              dailyQuotaLastClaimedAt: u.dailyQuotaLastClaimedAt,
              dailyQuotaClaimsCount: typeof u.dailyQuotaClaimsCount === 'number' ? u.dailyQuotaClaimsCount : 0,
              personalQuota: typeof u.personalQuota === 'number' ? u.personalQuota : 0,
              personalApiKey: u.personalApiKey || `usr_${cid}`
            });
          }
        }
        botConfig.activeUsers = Array.from(userMap.values());
        botConfig.stats.activeUsersCount = botConfig.activeUsers.length;

        // Clean up invalid negative group-level apiKeys
        if (botConfig.osintConfig && Array.isArray(botConfig.osintConfig.apiKeys)) {
          botConfig.osintConfig.apiKeys = botConfig.osintConfig.apiKeys.filter((k) => !k.key.includes('-'));
        }

        // Sync personal API keys to osintConfig and persistent claimed user IDs
        for (const u of botConfig.activeUsers) {
          syncUserApiKey(u);
          if (u.hasClaimedNewUserQuota) {
            persistentClaimedUserIds.add(Number(u.userId || u.chatId));
          }
        }
        savePersistentClaimedUsers();
      }

      // Sync in-memory searchHistories with disk search_cache so searches are never lost
      try {
        if (!Array.isArray(botConfig.searchHistories)) {
          botConfig.searchHistories = [];
        }
        if (fs.existsSync(SEARCH_CACHE_DIR)) {
          const files = fs.readdirSync(SEARCH_CACHE_DIR).filter((f) => f.endsWith('.json'));
          for (const f of files) {
            try {
              const fileData = JSON.parse(fs.readFileSync(path.join(SEARCH_CACHE_DIR, f), 'utf8'));
              if (fileData && fileData.id && !botConfig.searchHistories.some((h) => h.id === fileData.id)) {
                botConfig.searchHistories.push(fileData);
              }
            } catch {}
          }
          // Sort descending by timestamp
          botConfig.searchHistories.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
        }
      } catch {}

      // Ensure moderationConfig exists with all defaults
      if (!botConfig.moderationConfig) {
        botConfig.moderationConfig = { ...DEFAULT_MODERATION_CONFIG };
      } else {
        botConfig.moderationConfig = {
          ...DEFAULT_MODERATION_CONFIG,
          ...botConfig.moderationConfig
        };
      }

      console.log(`[Telegram Bot] Config loaded successfully. Active: ${botConfig.isActive}, OSINT: ${botConfig.osintConfig.enabled}, Users: ${botConfig.activeUsers.length}`);
    }
  } catch (err: any) {
    console.error('[Telegram Bot] Error reading bot config:', err.message);
  }
}

// Save configuration to disk
function saveBotConfig() {
  try {
    fs.writeFileSync(CONFIG_FILE, JSON.stringify(botConfig, null, 2), 'utf8');
  } catch (err: any) {
    console.error('[Telegram Bot] Error saving bot config:', err.message);
  }
}

// Add Log Entry
function addLog(
  type: 'incoming' | 'outgoing' | 'system' | 'error' | 'callback' | 'warn',
  text: string,
  chatId?: string | number,
  fromUser?: string,
  details?: string
) {
  const entry: BotLogEntry = {
    id: `log-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
    timestamp: new Date().toISOString(),
    type,
    text,
    chatId,
    fromUser,
    details
  };
  recentLogs.unshift(entry);
  if (recentLogs.length > 200) {
    recentLogs.pop();
  }
}

// Mask Token for Safe UI Display
function maskToken(token: string): string {
  if (!token) return '';
  if (token.length <= 10) return '••••••••';
  const prefix = token.substring(0, 6);
  const suffix = token.substring(token.length - 4);
  return `${prefix}...${suffix}`;
}

// Telegram API Helper
async function callTelegramApi(token: string, method: string, payload?: any, timeoutMs = 25000): Promise<any> {
  const url = `https://api.telegram.org/bot${token}/${method}`;
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);

  try {
    const response = await fetch(url, {
      method: payload ? 'POST' : 'GET',
      headers: {
        'Content-Type': 'application/json'
      },
      body: payload ? JSON.stringify(payload) : undefined,
      signal: controller.signal
    });

    const data = await response.json();
    return data;
  } finally {
    clearTimeout(timer);
  }
}

// Validate Token Directly Against Telegram API
async function verifyTelegramToken(token: string): Promise<TokenValidationResult> {
  const startTime = Date.now();
  const trimmed = (token || '').trim();

  if (!trimmed) {
    return {
      valid: false,
      errorMessage: 'Token Telegram tidak boleh kosong.',
      checkedAt: new Date().toISOString()
    };
  }

  // Basic regex check for Telegram bot token pattern: digits:alphanumeric_chars
  if (!/^\d{6,13}:[A-Za-z0-9_-]{30,55}$/.test(trimmed)) {
    return {
      valid: false,
      errorMessage: 'Format token tidak valid. Token bot resmi harus diawali angka ID diikuti titik dua (contoh: 123456789:ABCDef...).',
      checkedAt: new Date().toISOString()
    };
  }

  try {
    const res = await callTelegramApi(trimmed, 'getMe', undefined, 10000);
    const latencyMs = Date.now() - startTime;

    if (res && res.ok && res.result) {
      return {
        valid: true,
        botInfo: res.result,
        latencyMs,
        checkedAt: new Date().toISOString()
      };
    } else {
      return {
        valid: false,
        errorCode: res?.error_code || 401,
        errorMessage: res?.description || 'Token tidak diterima oleh Telegram API (Unauthorized).',
        latencyMs,
        checkedAt: new Date().toISOString()
      };
    }
  } catch (err: any) {
    const latencyMs = Date.now() - startTime;
    return {
      valid: false,
      errorMessage: `Gagal menghubungi server Telegram: ${err.message || 'Timeout / Network error'}`,
      latencyMs,
      checkedAt: new Date().toISOString()
    };
  }
}

// Format Indonesian Time
function getFormattedWIB(): { dateStr: string; timeStr: string; fullStr: string } {
  const now = new Date();
  const optionsDate: Intl.DateTimeFormatOptions = {
    timeZone: 'Asia/Jakarta',
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  };
  const optionsTime: Intl.DateTimeFormatOptions = {
    timeZone: 'Asia/Jakarta',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: false
  };

  const dateStr = new Intl.DateTimeFormat('id-ID', optionsDate).format(now);
  const timeStr = new Intl.DateTimeFormat('id-ID', optionsTime).format(now) + ' WIB';
  return { dateStr, timeStr, fullStr: `${dateStr}, ${timeStr}` };
}

// Format Uptime Duration
function formatUptime(seconds: number): string {
  const d = Math.floor(seconds / (3600 * 24));
  const h = Math.floor((seconds % (3600 * 24)) / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);

  const parts = [];
  if (d > 0) parts.push(`${d} hari`);
  if (h > 0) parts.push(`${h} jam`);
  if (m > 0) parts.push(`${m} menit`);
  parts.push(`${s} detik`);
  return parts.join(' ');
}

// Get current date string in WIB (YYYY-MM-DD)
function getWibDateString(): string {
  try {
    return new Intl.DateTimeFormat('en-CA', {
      timeZone: 'Asia/Jakarta',
      year: 'numeric',
      month: '2-digit',
      day: '2-digit'
    }).format(new Date());
  } catch {
    const now = new Date();
    return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
  }
}

// Get countdown until next 00:00 WIB midnight (anti-exploit reset tracker)
function getTimeUntilNextWibMidnight(): { hours: number; minutes: number; seconds: number; formatted: string } {
  try {
    const now = new Date();
    const jakartaTimeString = now.toLocaleString('en-US', { timeZone: 'Asia/Jakarta' });
    const jakartaDate = new Date(jakartaTimeString);

    const nextMidnight = new Date(jakartaDate);
    nextMidnight.setHours(24, 0, 0, 0);

    const diffMs = Math.max(0, nextMidnight.getTime() - jakartaDate.getTime());
    const hours = Math.floor(diffMs / (1000 * 60 * 60));
    const minutes = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));
    const seconds = Math.floor((diffMs % (1000 * 60)) / 1000);

    return {
      hours,
      minutes,
      seconds,
      formatted: `${hours} jam ${minutes} menit`
    };
  } catch {
    return { hours: 0, minutes: 0, seconds: 0, formatted: 'tengah malam WIB' };
  }
}

// Format ISO date string into readable Indonesian WIB format
function formatWibDate(isoString?: string): string {
  if (!isoString) return '-';
  try {
    const d = new Date(isoString);
    return new Intl.DateTimeFormat('id-ID', {
      timeZone: 'Asia/Jakarta',
      dateStyle: 'medium',
      timeStyle: 'short'
    }).format(d) + ' WIB';
  } catch {
    return isoString;
  }
}

// Send Telegram Chat Action (e.g. typing indicator in header without spamming text)
async function sendTelegramChatAction(chatId: string | number, action: string = 'typing'): Promise<boolean> {
  if (!botConfig.token) return false;
  try {
    const res = await callTelegramApi(botConfig.token, 'sendChatAction', {
      chat_id: chatId,
      action
    }, 4000);
    return !!(res && res.ok);
  } catch {
    return false;
  }
}

// Send Telegram Message Helper
async function sendTelegramMessage(chatId: string | number, text: string, replyMarkup?: any, parseMode: string | null = 'Markdown') {
  if (!botConfig.token) return null;
  try {
    const payload: any = {
      chat_id: chatId,
      text
    };
    if (parseMode) {
      payload.parse_mode = parseMode;
    }
    if (replyMarkup) {
      payload.reply_markup = replyMarkup;
    }
    const res = await callTelegramApi(botConfig.token, 'sendMessage', payload, 10000);
    if (res && res.ok) {
      botConfig.stats.messagesSent += 1;
      saveBotConfig();
      addLog('outgoing', `Pesan terkirim: "${text.substring(0, 50)}${text.length > 50 ? '...' : ''}"`, chatId);
      return res.result;
    } else {
      // If failed due to Markdown entity parsing error, automatically retry as clean plain text!
      if (
        parseMode &&
        res?.description &&
        (res.description.includes("can't parse entities") ||
          res.description.includes('entity') ||
          res.description.includes('parse'))
      ) {
        addLog('warn', `Retrying message to ${chatId} as plain text due to markdown parse issue: ${res.description}`, chatId);
        const fallbackText = text.replace(/[*_`\[\]()~>#+=|{}.!-]/g, (c) => (c === '`' || c === '*' ? '' : c));
        const fallbackPayload: any = {
          chat_id: chatId,
          text: fallbackText
        };
        if (replyMarkup) {
          fallbackPayload.reply_markup = replyMarkup;
        }
        const retryRes = await callTelegramApi(botConfig.token, 'sendMessage', fallbackPayload, 10000);
        if (retryRes && retryRes.ok) {
          botConfig.stats.messagesSent += 1;
          saveBotConfig();
          addLog('outgoing', `Pesan terkirim (fallback plain text): "${fallbackText.substring(0, 50)}..."`, chatId);
          return retryRes.result;
        }
      }
      addLog('error', `Gagal kirim pesan ke ${chatId}: ${res?.description}`, chatId);
    }
  } catch (err: any) {
    addLog('error', `Error sendTelegramMessage: ${err.message}`, chatId);
  }
  return null;
}

// Send Telegram Document / File Helper (Native multipart form upload with resilient caption handling)
async function sendTelegramDocument(
  chatId: string | number,
  content: string,
  filename: string,
  caption?: string
) {
  if (!botConfig.token) return null;
  try {
    const isJson = filename.endsWith('.json');
    const mimeType = isJson ? 'application/json' : 'text/plain; charset=utf-8';
    const blob = new Blob([content], { type: mimeType });

    // Clean caption: avoid Telegram Markdown entity parsing errors on underscores, asterisks, brackets
    const cleanCaption = caption ? caption.replace(/[*_`\[\]]/g, '') : undefined;

    const formData = new FormData();
    formData.append('chat_id', String(chatId));
    formData.append('document', blob, filename);
    if (cleanCaption) {
      formData.append('caption', cleanCaption.substring(0, 1000));
    }

    const res = await fetch(`https://api.telegram.org/bot${botConfig.token}/sendDocument`, {
      method: 'POST',
      body: formData
    });
    const data = await res.json();
    if (data.ok) {
      botConfig.stats.messagesSent += 1;
      saveBotConfig();
      addLog('outgoing', `File dokumen terkirim: "${filename}"`, chatId);
      return data.result;
    } else {
      addLog('error', `Gagal kirim dokumen ke ${chatId}: ${data.description}`, chatId);
      console.error(`[Telegram] Gagal kirim dokumen ke ${chatId}:`, data.description);

      // Retry without caption if caption caused any issue
      if (cleanCaption) {
        const retryForm = new FormData();
        retryForm.append('chat_id', String(chatId));
        retryForm.append('document', blob, filename);
        const retryRes = await fetch(`https://api.telegram.org/bot${botConfig.token}/sendDocument`, {
          method: 'POST',
          body: retryForm
        });
        const retryData = await retryRes.json();
        if (retryData.ok) {
          botConfig.stats.messagesSent += 1;
          saveBotConfig();
          addLog('outgoing', `File dokumen terkirim (tanpa caption): "${filename}"`, chatId);
          return retryData.result;
        }
      }
    }
  } catch (err: any) {
    addLog('error', `Error sendTelegramDocument: ${err.message}`, chatId);
    console.error(`[Telegram] Error sendTelegramDocument:`, err.message);
  }
  return null;
}

// Generate human-readable .txt report from search result
function generateTxtReport(item: {
  target: string;
  apiKey: string;
  totalMatches: number;
  formattedWib: string;
  rawResult: string;
  userName?: string;
  chatId?: number;
}): string {
  let readable = '';
  try {
    const parsed = JSON.parse(item.rawResult);
    if (parsed && Array.isArray(parsed.results)) {
      readable = parsed.results
        .map((r: any, idx: number) => {
          const rec = r.record || r;
          const locNik = rec.nikLocation && rec.nikLocation !== '(-)'
            ? rec.nikLocation
            : (rec.nik ? extractLocationFromNik(rec.nik) : '(-)');
          return `[DATA RECORD #${idx + 1}]
Nama Lengkap  : ${rec.fullName || '-'}
NIK           : ${rec.nik || '-'}
Lokasi (NIK)  : ${locNik || '(-)'}
Nomor Telepon : ${rec.phone || '-'}
Alamat Email  : ${rec.email || '-'}
Tanggal Lahir : ${rec.birthDate || '-'} (Usia: ${rec.age || '-'})
Jenis Kelamin : ${rec.gender || '-'}
Kota / Prov   : ${rec.city || '-'}, ${rec.province || '-'}
Tingkat Bahaya: ${rec.threatLevel || '-'}
Skor Akurasi  : ${r.precisionScore ? `${r.precisionScore}%` : '-'} (${r.predictionType || '-'})
Raw Data Line : ${rec.raw || '-'}
--------------------------------------------------------------------------------`;
        })
        .join('\n');
    }
  } catch {
    readable = item.rawResult;
  }

  return `================================================================================
LAPORAN HASIL PENCARIAN INTELIJEN OSINT LENGKAP
================================================================================
Target Pencarian   : ${item.target}
Kunci API          : ${item.apiKey}
Total Ditemukan    : ${item.totalMatches} data
Waktu Pencarian    : ${item.formattedWib}
Identitas Pengguna : ${item.userName || '-'} (Chat ID: ${item.chatId || '-'})
Status Berkas      : Asli & Utuh (Tanpa ada yang dipersingkat)
================================================================================

DAFTAR RECORD LENGKAP:
--------------------------------------------------------------------------------
${readable || item.rawResult}

================================================================================
RAW DUMP (JSON / RAW):
================================================================================
${item.rawResult}
================================================================================
Dicetak otomatis oleh Telegram Bot OSINT Intelligence.
`;
}

// Helper to persistently save search history item to individual disk cache file
function saveSearchItemToDisk(item: OsintSearchHistoryItem) {
  try {
    if (!fs.existsSync(SEARCH_CACHE_DIR)) {
      fs.mkdirSync(SEARCH_CACHE_DIR, { recursive: true });
    }
    const itemPath = path.join(SEARCH_CACHE_DIR, `${item.id}.json`);
    fs.writeFileSync(itemPath, JSON.stringify(item, null, 2), 'utf8');
  } catch (err: any) {
    console.error('[SearchCache] Failed to save search cache to disk:', err.message);
  }
}

// Resilient search history finder: checks memory, disk cache, and falls back to latest search for user
function findSearchHistoryItem(searchId: string, chatId?: number | string): OsintSearchHistoryItem | null {
  if (!Array.isArray(botConfig.searchHistories)) {
    botConfig.searchHistories = [];
  }
  const histories = botConfig.searchHistories;

  // 1. Direct match by ID in memory
  if (searchId) {
    const direct = histories.find((h) => h.id === searchId);
    if (direct) return direct;
  }

  // 2. Partial / substring match
  if (searchId) {
    const partial = histories.find((h) => h.id.includes(searchId) || searchId.includes(h.id));
    if (partial) return partial;
  }

  // 3. Disk cache lookup by ID
  if (searchId) {
    try {
      const diskPath = path.join(SEARCH_CACHE_DIR, `${searchId}.json`);
      if (fs.existsSync(diskPath)) {
        const parsed = JSON.parse(fs.readFileSync(diskPath, 'utf8'));
        if (parsed && parsed.id) {
          if (!histories.some((h) => h.id === parsed.id)) {
            histories.unshift(parsed);
          }
          return parsed;
        }
      }
    } catch {}
  }

  // 4. Fallback: If user clicked an older button whose exact ID was from an earlier session,
  // find the latest search executed by this specific chat ID!
  if (chatId) {
    const userSearches = histories.filter((h) => Number(h.chatId) === Number(chatId));
    if (userSearches.length > 0) {
      return userSearches[0];
    }
    // Also scan disk cache for any files belonging to this chatId
    try {
      if (fs.existsSync(SEARCH_CACHE_DIR)) {
        const files = fs.readdirSync(SEARCH_CACHE_DIR).filter((f) => f.endsWith('.json'));
        const sortedFiles = files.sort((a, b) => {
          const sA = fs.statSync(path.join(SEARCH_CACHE_DIR, a)).mtimeMs;
          const sB = fs.statSync(path.join(SEARCH_CACHE_DIR, b)).mtimeMs;
          return sB - sA;
        });
        for (const f of sortedFiles) {
          try {
            const raw = fs.readFileSync(path.join(SEARCH_CACHE_DIR, f), 'utf8');
            const parsed = JSON.parse(raw);
            if (parsed && Number(parsed.chatId) === Number(chatId)) {
              if (!histories.some((h) => h.id === parsed.id)) {
                histories.unshift(parsed);
              }
              return parsed;
            }
          } catch {}
        }
      }
    } catch {}
  }

  // 5. Ultimate fallback if there are any histories in memory
  if (histories.length > 0) {
    return histories[0];
  }

  return null;
}

// Format OSINT Presentation with device warning for > 50 results
function formatOsintPresentation(
  target: string,
  apiKey: string,
  totalMatches: number,
  newRemaining: string,
  wibTime: { fullStr: string },
  resultText: string,
  searchId: string
) {
  const isHuge = totalMatches > 50;
  let parsed: any = null;
  try {
    parsed = JSON.parse(resultText);
  } catch {}

  let warningSection = '';
  if (isHuge) {
    warningSection = `⚠️ *PERINGATAN PERANGKAT (HASIL > 50 DATA):*
Ditemukan *${totalMatches} data* hasil intelijen.
Menyalin (copy) teks puluhan ribu karakter sekaligus ke clipboard dapat menyebabkan aplikasi Telegram atau HP Anda mengalami *lag, freeze, atau crash*.
👉 *Sangat disarankan untuk mengunduh berkas lengkap via tombol 📥 Unduh File (.txt / .json) di bawah agar aman & lancar.*
━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
  }

  let bodySection = '';
  if (parsed && Array.isArray(parsed.results) && parsed.results.length > 0) {
    const previewCount = Math.min(parsed.results.length, 4);
    const previews = parsed.results
      .slice(0, previewCount)
      .map((r: any, idx: number) => {
        const rec = r.record || r;
        const nikVal = rec.nik || '';
        // Extract location from NIK if available, or rec.nikLocation, otherwise '(-)'
        let locNik = rec.nikLocation && rec.nikLocation !== '(-)' ? rec.nikLocation : '';
        if (!locNik && nikVal) {
          locNik = extractLocationFromNik(nikVal);
        }
        if (!locNik) locNik = '(-)';

        const domisili = [rec.city, rec.province].filter(Boolean).join(', ') || rec.address || '(-)';

        return `🔹 *[Data #${idx + 1}]* ${rec.fullName || 'Tanpa Nama'}
   • *NIK:* \`${nikVal || '-'}\`
   • *📍 Lokasi (NIK):* ${locNik}
   • *HP:* \`${rec.phone || '-'}\`
   • *Email:* \`${rec.email || '-'}\`
   • *TTL / Usia:* ${rec.birthDate || '-'} (${rec.age ? `${rec.age} thn` : '-'})
   • *Domisili:* ${domisili}`;
      })
      .join('\n\n');

    bodySection = `📄 *Hasil Intelijen (${previewCount} dari ${totalMatches} Data):*\n\n${previews}${
      totalMatches > previewCount
        ? `\n\n💡 _... dan ${totalMatches - previewCount} data lainnya._\n_Gunakan tombol di bawah untuk menyalin seluruh hasil atau unduh berkas lengkap!_`
        : ''
    }`;
  } else if (resultText.length <= 2500) {
    const match16 = resultText.match(/\b([1-9][0-9]{15})\b/);
    const locFromRaw = match16 ? extractLocationFromNik(match16[1]) : '(-)';
    bodySection = `📍 *Lokasi Terdeteksi (NIK):* ${locFromRaw}\n\n\`\`\`json\n${resultText}\n\`\`\``;
  } else {
    const safeSnippet = resultText.substring(0, 1500).trim();
    const match16 = resultText.match(/\b([1-9][0-9]{15})\b/);
    const locFromRaw = match16 ? extractLocationFromNik(match16[1]) : '(-)';
    bodySection = `📍 *Lokasi Terdeteksi (NIK):* ${locFromRaw}\n\n\`\`\`\n${safeSnippet}\n...\n\`\`\`\n\n💡 _Menampilkan pratinjau. Gunakan tombol di bawah untuk menyalin seluruh ${totalMatches} data atau unduh berkas lengkap!_`;
  }

  const messageText = `🎯 *HASIL PENCARIAN INTELIJEN OSINT*
━━━━━━━━━━━━━━━━━━━━━━━━━
🎯 *Target:* \`${target}\`
🔑 *API Key:* \`${apiKey}\`
📊 *Total Ditemukan:* *${totalMatches} data hasil intelijen*
📦 *Sisa Kuota:* ${newRemaining}
🕒 *Waktu:* ${wibTime.fullStr}
━━━━━━━━━━━━━━━━━━━━━━━━━
${warningSection}${bodySection}
━━━━━━━━━━━━━━━━━━━━━━━━━
💡 _Gunakan perintah \`api ${apiKey}\` untuk cek sisa kuota, atau \`/history\` untuk riwayat._`;

  const keyboard: any[][] = [
    [
      { text: '📥 Download File (.txt)', callback_data: `dl_txt_${searchId}` },
      { text: '📥 Unduh File (.json)', callback_data: `dl_json_${searchId}` }
    ],
    [
      { text: `📋 Salin Seluruh Hasil (${totalMatches} Data)`, callback_data: `copy_all_${searchId}` }
    ],
    [
      { text: '📜 Riwayat Saya', callback_data: 'user_history' },
      { text: '🏠 Menu Utama', callback_data: 'cmd_menu' }
    ]
  ];

  return { messageText, replyMarkup: { inline_keyboard: keyboard } };
}

// User-Isolated History Viewer
async function handleUserHistoryCommand(chatId: number, senderName: string) {
  const userHistories = (botConfig.searchHistories || [])
    .filter((h) => h.chatId === chatId)
    .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());

  if (userHistories.length === 0) {
    await sendTelegramMessage(
      chatId,
      `📜 *RIWAYAT PENCARIAN INTELIJEN SAYA*
━━━━━━━━━━━━━━━━━━━━━━━━━
👤 *Nama Pengguna:* ${senderName}
🆔 *Chat ID:* \`${chatId}\`
📊 *Total Riwayat:* 0 pencarian
━━━━━━━━━━━━━━━━━━━━━━━━━
Belum ada riwayat pencarian OSINT untuk akun Anda.

📖 *Cara Mencari:*
Ketik: \`search: <target> <apiKey>\`
*Contoh:* \`search: jokowi ppp\`

💡 _Setiap pencarian Anda otomatis tersimpan secara privat khusus untuk Chat ID Anda._`,
      {
        inline_keyboard: [
          [{ text: '🔍 Cara Pakai OSINT', callback_data: 'cmd_osint' }],
          [{ text: '🏠 Menu Utama', callback_data: 'cmd_menu' }]
        ]
      }
    );
    return;
  }

  const displayItems = userHistories.slice(0, 6);
  const listFormatted = displayItems
    .map(
      (h, idx) =>
        `*${idx + 1}.* 🎯 Target: \`${h.target}\`\n   📅 ${h.formattedWib}\n   📊 Hasil: *${h.totalMatches} data* | Key: \`${h.apiKey}\``
    )
    .join('\n\n');

  const historyCard = `📜 *RIWAYAT PENCARIAN SAYA (CHAT ID: ${chatId})*
━━━━━━━━━━━━━━━━━━━━━━━━━
👤 *Nama Pengguna:* ${senderName}
📊 *Total Riwayat Tersimpan:* *${userHistories.length} pencarian*
━━━━━━━━━━━━━━━━━━━━━━━━━
${listFormatted}
━━━━━━━━━━━━━━━━━━━━━━━━━
💡 _Pilih tombol di bawah untuk membuka kembali hasil atau unduh berkas (GRATIS tanpa memotong kuota lagi):_`;

  const keyboard: any[][] = [];

  for (let i = 0; i < Math.min(displayItems.length, 3); i++) {
    const item = displayItems[i];
    keyboard.push([
      { text: `🔍 Buka #${i + 1} (${item.target.substring(0, 10)})`, callback_data: `view_hist_${item.id}` },
      { text: `📥 Unduh #${i + 1} (.txt)`, callback_data: `dl_txt_${item.id}` }
    ]);
  }

  keyboard.push([
    { text: '🗑️ Hapus Riwayat Saya', callback_data: 'confirm_clear_my_hist' },
    { text: '🏠 Menu Utama', callback_data: 'cmd_menu' }
  ]);

  await sendTelegramMessage(chatId, historyCard, { inline_keyboard: keyboard });
}

// Standard Interactive Inline Keyboard Menu (Dynamic with Custom Menus & Menu Config)
function getMainInlineMenu(isOsintOn = false) {
  const menuCfg = botConfig.menuConfig || DEFAULT_MENU_CONFIG;
  const keyboard: any[][] = [];

  // Row 1: Claim & Quota
  const rowQuota: any[] = [];
  if (menuCfg.showClaimButtonInMenu !== false) {
    rowQuota.push({ text: '🎁 Klaim Kuota Gratis', callback_data: 'cmd_claim_menu' });
  }
  if (menuCfg.showQuotaButtonInMenu !== false) {
    rowQuota.push({ text: '💎 Sisa Kuota Saya', callback_data: 'cmd_my_quota' });
  }
  if (rowQuota.length > 0) keyboard.push(rowQuota);

  // Row 2: OSINT & Pricing
  const rowOsint: any[] = [];
  if (menuCfg.showOsintButtonInMenu !== false) {
    rowOsint.push({
      text: isOsintOn ? '🟢 OSINT Intel (AKTIF)' : '🔴 OSINT Intel (OFF)',
      callback_data: 'cmd_osint'
    });
  }
  if (menuCfg.showPriceButtonInMenu !== false) {
    rowOsint.push({ text: '💎 Tarif & Cek API Key', callback_data: 'cmd_pricing' });
  }
  if (rowOsint.length > 0) keyboard.push(rowOsint);

  // Row 3: ID & Bot details
  keyboard.push([
    { text: '🆔 Cek Chat ID & Profil', callback_data: 'cmd_id' },
    { text: '🤖 Detail & Info Bot', callback_data: 'cmd_bot' }
  ]);

  // Row 4: Ping & WIB Time
  keyboard.push([
    { text: '🏓 Ping & Status Server', callback_data: 'cmd_ping' },
    { text: '⏰ Waktu Real-Time (WIB)', callback_data: 'cmd_waktu' }
  ]);

  // Row 5: Calculator & Owner
  const rowOwner: any[] = [{ text: '🧮 Kalkulator Cepat', callback_data: 'cmd_calc_info' }];
  if (menuCfg.showOwnerButtonInMenu !== false) {
    rowOwner.push({ text: '📞 Hubungi Owner (@flood1233)', callback_data: 'cmd_owner' });
  }
  keyboard.push(rowOwner);

  // Dynamically attach enabled custom menus created by owner/web
  const allCustomMenus = [
    ...(botConfig.customMenus || []),
    ...(menuCfg.customButtons || [])
  ].filter((m, idx, self) => m.enabled && self.findIndex((x) => x.id === m.id) === idx);

  for (let i = 0; i < allCustomMenus.length; i += 2) {
    const item1 = allCustomMenus[i];
    const item2 = allCustomMenus[i + 1];

    const row: any[] = [];
    if (item1) {
      if (item1.type === 'url' && item1.url) {
        row.push({ text: item1.label, url: item1.url });
      } else {
        row.push({ text: item1.label, callback_data: `cmenu_${item1.id}` });
      }
    }
    if (item2) {
      if (item2.type === 'url' && item2.url) {
        row.push({ text: item2.label, url: item2.url });
      } else {
        row.push({ text: item2.label, callback_data: `cmenu_${item2.id}` });
      }
    }
    if (row.length > 0) {
      keyboard.push(row);
    }
  }

  const bottomRow: any[] = [{ text: '📜 Riwayat Pencarian Saya', callback_data: 'user_history' }];
  if (menuCfg.showHelpButtonInMenu !== false) {
    bottomRow.push({ text: '📖 Daftar Perintah Lengkap', callback_data: 'cmd_help' });
  }
  keyboard.push(bottomRow);

  return {
    inline_keyboard: keyboard
  };
}

// Pricing Helper with Automatic Local Currency Detection
function getPricingData(langCode?: string) {
  const code = (langCode || '').toLowerCase();
  if (code.startsWith('ms') || code.startsWith('my')) {
    return {
      currency: 'MYR (RM - Ringgit Malaysia)',
      formatted: `• 5x Pakai: *RM 1.00*\n• 10x Pakai: *RM 1.80*\n• 15x Pakai: *RM 3.50* _(+ BONUS 1x Pakai)_\n• 40x Pakai: *RM 8.00* _(+ BONUS 1x Pakai)_\n• 100x Pakai: *RM 16.00* _(+ BONUS 2x Pakai)_\n• Unlimited: *RM 32.00* _(Akses Tanpa Batas Kuota)_`,
      note: '🎁 *BONUS KHUSUS:* Pembelian di atas RM 3.50 otomatis mendapatkan bonus 1x pakai ekstra!'
    };
  } else if (code.startsWith('sg')) {
    return {
      currency: 'SGD (S$ - Singapore Dollar)',
      formatted: `• 5x Pakai: *S$ 0.35*\n• 10x Pakai: *S$ 0.60*\n• 15x Pakai: *S$ 1.20* _(+ BONUS 1x Pakai)_\n• 40x Pakai: *S$ 2.80* _(+ BONUS 1x Pakai)_\n• 100x Pakai: *S$ 5.50* _(+ BONUS 2x Pakai)_\n• Unlimited: *S$ 12.00* _(Akses Tanpa Batas Kuota)_`,
      note: '🎁 *BONUS KHUSUS:* Pembelian di atas S$ 1.20 otomatis mendapatkan bonus 1x pakai ekstra!'
    };
  } else if (code.startsWith('en')) {
    return {
      currency: 'USD ($ - US Dollar)',
      formatted: `• 5x Usage: *$0.25*\n• 10x Usage: *$0.40*\n• 15x Usage: *$0.75* _(+ BONUS 1x Usage)_\n• 40x Usage: *$1.75* _(+ BONUS 1x Usage)_\n• 100x Usage: *$3.50* _(+ BONUS 2x Usage)_\n• Unlimited: *$7.00* _(Unlimited Queries)_`,
      note: '🎁 *SPECIAL BONUS:* Purchases over $0.75 automatically receive +1x free bonus usage!'
    };
  } else {
    // Default Indonesian Rupiah (IDR)
    return {
      currency: 'IDR (Rp - Rupiah Indonesia)',
      formatted: `• 5x Pakai: *Rp 3.000*\n• 10x Pakai: *Rp 5.000*\n• 15x Pakai: *Rp 10.000* _(+ BONUS 1x Pakai)_\n• 40x Pakai: *Rp 25.000* _(+ BONUS 1x Pakai)_\n• 100x Pakai: *Rp 50.000* _(+ BONUS 2x Pakai)_\n• Unlimited: *Rp 100.000* _(Akses Sepuasnya Tanpa Batas Kuota!)_`,
      note: '🎁 *BONUS KHUSUS:* Pembelian API Key di atas Rp 10.000 otomatis mendapatkan bonus 1x pakai ekstra!'
    };
  }
}

// Broadcast OSINT Status Change to All Users
async function broadcastOsintStatusChange(isOnline: boolean) {
  const users = botConfig.activeUsers || [];
  if (users.length === 0 || !botConfig.token) return;

  const header = isOnline
    ? '🟢 *PEMBERITAHUAN: SERVER DATA OSINT DIAKTIFKAN (ON)*'
    : '🔴 *PEMBERITAHUAN: SERVER DATA OSINT DINONAKTIFKAN (OFF)*';

  const body = isOnline
    ? `Halo! Server Data OSINT baru saja *DINYALAKAN (ON)* oleh Owner.\n\nSekarang Anda sudah bisa melakukan pencarian intelijen menggunakan API Key.\n\n📖 *Cara Pakai:*\n\`search: <target> <apiKey>\`\n*Contoh:* \`search: jokowi ppp\`\n\nBagi yang belum memiliki API Key atau ingin top up kuota, silakan hubungi Admin:\n📞 *Owner Telegram:* @flood1233\n_(Bebas mau chat ataupun call, asal tidak spam)_`
    : `Halo! Server Data OSINT saat ini telah *DIMATIKAN (OFF)* sementara oleh Owner untuk pemeliharaan server.\n\nFitur pencarian OSINT saat ini ditutup sementara.\n\nJika Anda memiliki keperluan mendesak atau ingin meminta server diaktifkan, silakan hubungi Owner:\n📞 *Owner Telegram:* @flood1233\n_(Bebas mau chat ataupun call, asal tidak spam)_`;

  const fullText = `${header}\n━━━━━━━━━━━━━━━━━━━━━━━━━\n${body}\n━━━━━━━━━━━━━━━━━━━━━━━━━`;

  addLog('system', `Menyiarkan notifikasi status OSINT (${isOnline ? 'ON' : 'OFF'}) ke ${users.length} pengguna...`);

  let count = 0;
  for (const u of users) {
    try {
      await sendTelegramMessage(u.chatId, fullText, {
        inline_keyboard: [
          [{ text: '📞 Hubungi Owner @flood1233', url: 'https://t.me/flood1233' }],
          [{ text: '🏠 Buka Menu Bot', callback_data: 'cmd_menu' }]
        ]
      });
      count++;
    } catch {
      // ignore individual failures
    }
    // Small delay to prevent rate limit
    await new Promise((resolve) => setTimeout(resolve, 50));
  }
  addLog('system', `Siaran status OSINT selesai: ${count} pengguna berhasil menerima notifikasi.`);
}

// Update Active Users List with Anti-Vulnerability Shield
function registerOrUpdateUser(fromUser: any, chat: any): BotUserEntry {
  const userId = Number(fromUser.id);
  const isPrivate = chat.type === 'private';
  const numericChatId = isPrivate ? userId : Number(chat.id);
  const now = new Date().toISOString();

  // Find user by their permanent immutable Telegram User ID (from.id)
  let existing = botConfig.activeUsers.find(
    (u) => (u.userId && Number(u.userId) === userId) || Number(u.chatId) === userId
  );

  if (existing) {
    existing.userId = userId;
    existing.chatId = userId; // Always ensure positive Telegram user ID
    existing.firstName = fromUser.first_name || existing.firstName;
    existing.lastName = fromUser.last_name || existing.lastName;
    existing.username = fromUser.username || existing.username;
    existing.lastSeen = now;
    existing.totalMessages += 1;
    existing.isVerified = true;
    if (fromUser.language_code) {
      existing.languageCode = fromUser.language_code;
    }
    existing.personalApiKey = `usr_${userId}`;
    if (typeof existing.personalQuota !== 'number') {
      existing.personalQuota = 0;
    }
    if (persistentClaimedUserIds.has(userId)) {
      existing.hasClaimedNewUserQuota = true;
    } else if (typeof existing.hasClaimedNewUserQuota !== 'boolean') {
      existing.hasClaimedNewUserQuota = false;
    }
    if (typeof existing.dailyQuotaClaimsCount !== 'number') {
      existing.dailyQuotaClaimsCount = 0;
    }
    syncUserApiKey(existing);
    saveBotConfig();
    return existing;
  } else {
    const isClaimedNew = persistentClaimedUserIds.has(userId);
    const newUser: BotUserEntry = {
      chatId: userId,
      userId: userId,
      firstName: fromUser.first_name || 'Anonymous',
      lastName: fromUser.last_name || '',
      username: fromUser.username || '',
      firstSeen: now,
      lastSeen: now,
      totalMessages: 1,
      type: isPrivate ? 'private' : chat.type,
      isVerified: true, // Permanent verified status
      verifiedAt: now,
      languageCode: fromUser.language_code || 'id',
      hasClaimedNewUserQuota: isClaimedNew,
      dailyQuotaClaimsCount: 0,
      personalQuota: 0,
      personalApiKey: `usr_${userId}`
    };
    botConfig.activeUsers.unshift(newUser);
    botConfig.stats.activeUsersCount = botConfig.activeUsers.length;
    syncUserApiKey(newUser);
    saveBotConfig();
    return newUser;
  }
}

// =========================================================================
// ANTI-VULNERABILITY QUOTA CLAIM SYSTEM (NEW USER & DAILY QUOTA)
// =========================================================================

// Handle Claim New User Quota (Welcome Quota - Strictly 1x Lifetime)
async function handleClaimNewUserQuota(userId: number, replyChatId: number, senderName: string) {
  const numericUserId = Number(userId);
  const targetReplyChatId = Number(replyChatId);
  const lockKey = `claim_new_${numericUserId}`;
  if (activeClaimLocks.has(lockKey)) {
    return;
  }
  activeClaimLocks.add(lockKey);

  try {
    const user = botConfig.activeUsers.find(
      (u) => (u.userId && Number(u.userId) === numericUserId) || Number(u.chatId) === numericUserId
    );
    if (!user) {
      await sendTelegramMessage(targetReplyChatId, '⚠️ Data akun Anda tidak ditemukan. Silakan kirim pesan /start terlebih dahulu.');
      return;
    }

    const quotaCfg = botConfig.quotaConfig || DEFAULT_QUOTA_CONFIG;
    if (!quotaCfg.newUserQuotaEnabled) {
      await sendTelegramMessage(
        targetReplyChatId,
        `⚠️ *KLAIM DINONAKTIFKAN*\n\nProgram bonus kuota sambutan pengguna baru saat ini sedang dinonaktifkan oleh administrator.\nSilakan gunakan menu Klaim Harian atau hubungi owner @flood1233.`
      );
      return;
    }

    // STRICT VULNERABILITY SHIELD: Check if user already claimed
    if (user.hasClaimedNewUserQuota || persistentClaimedUserIds.has(numericUserId)) {
      user.hasClaimedNewUserQuota = true;
      persistentClaimedUserIds.add(numericUserId);
      savePersistentClaimedUsers();
      saveBotConfig();

      const claimDateStr = formatWibDate(user.newUserQuotaClaimedAt);
      const todayWib = getWibDateString();
      const isDailyClaimed = user.dailyQuotaLastClaimedDate === todayWib;
      const countdown = getTimeUntilNextWibMidnight();

      const rejectCard = `🛡️ *KLAIM DITOLAK: VULNERABILITY SHIELD AKTIF*
━━━━━━━━━━━━━━━━━━━━━━━━━
⚠️ *Pemberitahuan Keamanan:*
Akun Anda (*User ID:* \`${numericUserId}\`) *SUDAH PERNAH* mengklaim Kuota Pengguna Baru sebelumnya pada:
🕒 *${claimDateStr}*

🔒 *Ketentuan Anti-Exploit:*
• Kuota Pengguna Baru *HANYA DAPAT DIKLAIM 1X SEUMUR HIDUP* per akun Telegram.
• Menggunakan grup berbeda, menghapus chat, ataupun mendaftar ulang TIDAK AKAN mereset jatah ini.
• Sistem secara ketat mendeteksi dan menolak eksploitasi ganda.

💎 *Status Kuota Anda Saat Ini:*
• Sisa Kuota Pribadi: *${user.personalQuota || 0}x Pencarian*
• API Key Pribadi: \`${user.personalApiKey || `usr_${numericUserId}`}\`
• Kuota Harian Hari Ini: ${isDailyClaimed ? `✅ Sudah Diambil (Reset: ${countdown.formatted})` : '✨ *Tersedia untuk Diklaim!*'}

💡 *Solusi Tambah Kuota Gratis:*
Anda dapat mengklaim *Kuota Harian Gratis (+${quotaCfg.dailyQuotaAmount}x)* setiap 24 jam sekali (pukul 00:00 WIB) atau hubungi Owner @flood1233 untuk top up.`;

      await sendTelegramMessage(targetReplyChatId, rejectCard, {
        inline_keyboard: [
          [{ text: `📅 Klaim Kuota Harian (+${quotaCfg.dailyQuotaAmount}x)`, callback_data: 'claim_daily' }],
          [{ text: '💎 Cek Sisa Kuota Saya', callback_data: 'cmd_my_quota' }],
          [{ text: '🏠 Kembali ke Menu Utama', callback_data: 'cmd_menu' }]
        ]
      });
      return;
    }

    // Give welcome quota (ATOMIC WRITE FIRST!)
    const BONUS_AMOUNT = quotaCfg.newUserQuotaAmount || 5;
    user.hasClaimedNewUserQuota = true;
    user.newUserQuotaClaimedAt = new Date().toISOString();
    user.personalQuota = (user.personalQuota || 0) + BONUS_AMOUNT;
    user.personalApiKey = `usr_${numericUserId}`;
    persistentClaimedUserIds.add(numericUserId);
    savePersistentClaimedUsers();

    syncUserApiKey(user);
    saveBotConfig();

    addLog('system', `Pengguna ${numericUserId} (${senderName}) berhasil klaim Kuota Pengguna Baru (+${BONUS_AMOUNT} kuota). Total: ${user.personalQuota}x`);

    const successCard = `🎉 *SELAMAT! KLAIM KUOTA PENGGUNA BARU BERHASIL*
━━━━━━━━━━━━━━━━━━━━━━━━━
👤 *Pengguna:* ${senderName}
🆔 *User ID:* \`${numericUserId}\`
🎁 *Hadiah Sambutan:* *+${BONUS_AMOUNT}x Kuota Pencarian OSINT*
💎 *Total Sisa Kuota Pribadi:* *${user.personalQuota}x Pemakaian*
🔑 *API Key Pribadi Anda:* \`${user.personalApiKey}\`
━━━━━━━━━━━━━━━━━━━━━━━━━
📖 *PANDUAN PENGGUNAAN KUOTA (LANGSUNG AKTIF!):*
1️⃣ *Format Otomatis (Langsung Tanpa API Key):*
   Ketik: \`search: <target>\` atau \`/search <target>\` atau \`cari: <target>\`
   _Contoh:_ \`search: jokowi\` atau \`cari: slamet\`
   _Bot akan langsung mencari di berkas arsip 1.000.000 data dan otomatis memotong 1 kuota pribadi Anda!_

2️⃣ *Format Manual:*
   \`search: <target> ${user.personalApiKey}\`

💡 *Tips:* Sisa kuota HANYA berkurang jika data target berhasil ditemukan di dataset!`;

    await sendTelegramMessage(targetReplyChatId, successCard, {
      inline_keyboard: [
        [{ text: `📅 Klaim Kuota Harian Juga (+${quotaCfg.dailyQuotaAmount}x)`, callback_data: 'claim_daily' }],
        [{ text: '💎 Cek Kuota & Profil', callback_data: 'cmd_my_quota' }],
        [{ text: '🏠 Buka Menu Utama', callback_data: 'cmd_menu' }]
      ]
    });
  } finally {
    activeClaimLocks.delete(lockKey);
  }
}

// Handle Claim Daily Quota (Reset Every 00:00 WIB Midnight)
async function handleClaimDailyQuota(userId: number, replyChatId: number, senderName: string) {
  const numericUserId = Number(userId);
  const targetReplyChatId = Number(replyChatId);
  const lockKey = `claim_daily_${numericUserId}`;
  if (activeClaimLocks.has(lockKey)) {
    return;
  }
  activeClaimLocks.add(lockKey);

  try {
    const user = botConfig.activeUsers.find(
      (u) => (u.userId && Number(u.userId) === numericUserId) || Number(u.chatId) === numericUserId
    );
    if (!user) {
      await sendTelegramMessage(targetReplyChatId, '⚠️ Data akun Anda tidak ditemukan. Silakan kirim pesan /start terlebih dahulu.');
      return;
    }

    const quotaCfg = botConfig.quotaConfig || DEFAULT_QUOTA_CONFIG;
    if (!quotaCfg.dailyQuotaEnabled) {
      await sendTelegramMessage(
        targetReplyChatId,
        `⚠️ *KLAIM HARIAN DINONAKTIFKAN*\n\nProgram klaim kuota harian gratis saat ini sedang dinonaktifkan oleh administrator.\nSilakan hubungi owner @flood1233.`
      );
      return;
    }

    const todayWib = getWibDateString();
    const countdown = getTimeUntilNextWibMidnight();

    // Check if user already claimed today
    if (user.dailyQuotaLastClaimedDate === todayWib) {
      const rejectCard = `🛡️ *KLAIM DITOLAK: JATAH HARIAN SUDAH DIAMBIL*
━━━━━━━━━━━━━━━━━━━━━━━━━
👤 *Pengguna:* ${senderName}
🆔 *User ID:* \`${numericUserId}\`
📅 *Tanggal Hari Ini:* ${todayWib} WIB

⚠️ *Pemberitahuan Sistem:*
Anda *SUDAH MENGKLAIM* jatah Kuota Harian untuk hari ini. Kuota harian dibatasi *1x per hari kalender WIB*.

⏳ *Reset Kuota Harian Berikutnya:*
• Waktu Reset: Pukul 00:00 WIB (Tengah Malam)
• Sisa Waktu: *${countdown.hours} jam ${countdown.minutes} menit lagi*

💎 *Sisa Kuota Pribadi Anda:* *${user.personalQuota || 0}x Pemakaian*
🔑 *API Key Pribadi:* \`${user.personalApiKey || `usr_${numericUserId}`}\`

🛡️ _Sistem perlindungan anti-exploit aktif melindungi integritas kuota._`;

      await sendTelegramMessage(targetReplyChatId, rejectCard, {
        inline_keyboard: [
          [{ text: '💎 Cek Kuota Saya', callback_data: 'cmd_my_quota' }],
          [{ text: '📞 Top Up via Owner', callback_data: 'cmd_owner' }],
          [{ text: '🏠 Kembali ke Menu', callback_data: 'cmd_menu' }]
        ]
      });
      return;
    }

    // Give daily quota (ATOMIC WRITE FIRST!)
    const DAILY_AMOUNT = quotaCfg.dailyQuotaAmount || 2;
    user.dailyQuotaLastClaimedDate = todayWib;
    user.dailyQuotaLastClaimedAt = new Date().toISOString();
    user.dailyQuotaClaimsCount = (user.dailyQuotaClaimsCount || 0) + 1;
    user.personalQuota = (user.personalQuota || 0) + DAILY_AMOUNT;
    if (!user.personalApiKey) {
      user.personalApiKey = `usr_${numericUserId}`;
    }

    syncUserApiKey(user);
    saveBotConfig();

    addLog('system', `Pengguna ${numericUserId} (${senderName}) berhasil klaim Kuota Harian (+${DAILY_AMOUNT} kuota). Total: ${user.personalQuota}x`);

    const successCard = `✨ *ALHAMDULILLAH! KLAIM KUOTA HARIAN BERHASIL*
━━━━━━━━━━━━━━━━━━━━━━━━━
👤 *Pengguna:* ${senderName}
📅 *Tanggal Klaim:* ${todayWib} WIB
🎁 *Bonus Kuota Harian:* *+${DAILY_AMOUNT}x Kuota OSINT Gratis*
💎 *Total Sisa Kuota Pribadi:* *${user.personalQuota}x Pemakaian*
🔑 *API Key Pribadi Anda:* \`${user.personalApiKey}\`
━━━━━━━━━━━━━━━━━━━━━━━━━
🕒 *Informasi Reset:*
Jatah harian berikutnya akan aktif kembali besok setelah pukul 00:00 WIB.

📖 *Cara Pakai Kuota:*
Ketik: \`search: <target>\` atau \`/search <target>\` atau \`cari: <target>\``;

    await sendTelegramMessage(targetReplyChatId, successCard, {
      inline_keyboard: [
        [{ text: '🔍 Cara Pakai OSINT', callback_data: 'cmd_osint' }],
        [{ text: '💎 Cek Sisa Kuota', callback_data: 'cmd_my_quota' }],
        [{ text: '🏠 Buka Menu Utama', callback_data: 'cmd_menu' }]
      ]
    });
  } finally {
    activeClaimLocks.delete(lockKey);
  }
}

// Send Claim Quota Dashboard
async function sendClaimQuotaDashboard(userId: number, replyChatId: number, senderName: string) {
  const numericUserId = Number(userId);
  const targetReplyChatId = Number(replyChatId);
  const user = botConfig.activeUsers.find(
    (u) => (u.userId && Number(u.userId) === numericUserId) || Number(u.chatId) === numericUserId
  );
  const quotaCfg = botConfig.quotaConfig || DEFAULT_QUOTA_CONFIG;
  const todayWib = getWibDateString();
  const countdown = getTimeUntilNextWibMidnight();

  const isNewClaimed = Boolean(user?.hasClaimedNewUserQuota);
  const isDailyClaimed = user?.dailyQuotaLastClaimedDate === todayWib;
  const personalQuota = user?.personalQuota || 0;
  const personalKey = user?.personalApiKey || `usr_${numericUserId}`;

  const dashboardText = `🎁 *DASHBOARD KLAIM KUOTA GRATIS*
━━━━━━━━━━━━━━━━━━━━━━━━━
👤 *Pengguna:* ${senderName}
🆔 *User ID:* \`${numericUserId}\`
💎 *Saldo Kuota Pribadi:* *${personalQuota}x Pencarian*
🔑 *API Key Pribadi:* \`${personalKey}\`
━━━━━━━━━━━━━━━━━━━━━━━━━
📋 *STATUS KLAIM ANDA:*

1️⃣ *KUOTA PENGGUNA BARU (+${quotaCfg.newUserQuotaAmount}x Kuota)*
• Status: ${isNewClaimed ? '✅ *SUDAH DIKLAIM* (1x seumur hidup)' : (quotaCfg.newUserQuotaEnabled ? '🎁 *TERSEDIA! (Belum Diklaim)*' : '⏸️ *Dinonaktifkan Admin*')}
• Keterangan: Bonus selamat datang khusus pengguna bot.

2️⃣ *KUOTA HARIAN (+${quotaCfg.dailyQuotaAmount}x Kuota)*
• Status: ${isDailyClaimed ? `✅ *SUDAH DIKLAIM HARI INI*\n  ⏳ Reset: *${countdown.hours}j ${countdown.minutes}m lagi* (00:00 WIB)` : (quotaCfg.dailyQuotaEnabled ? '✨ *SIAP DIKLAIM HARI INI!*' : '⏸️ *Dinonaktifkan Admin*')}
• Keterangan: Kuota gratis yang bisa diklaim setiap 24 jam kalender WIB.
━━━━━━━━━━━━━━━━━━━━━━━━━
🛡️ *Sistem Keamanan Anti-Vulnerability Aktif:*
Setiap klaim diverifikasi secara ketat berdasarkan User ID terdaftar. Perintah /id tidak akan mereset status klaim Anda.`;

  const keyboard: any[][] = [];

  if (!isNewClaimed && quotaCfg.newUserQuotaEnabled) {
    keyboard.push([{ text: `🎁 Klaim Kuota Pengguna Baru (+${quotaCfg.newUserQuotaAmount}x)`, callback_data: 'claim_new_user' }]);
  }
  if (!isDailyClaimed && quotaCfg.dailyQuotaEnabled) {
    keyboard.push([{ text: `📅 Klaim Kuota Harian (+${quotaCfg.dailyQuotaAmount}x)`, callback_data: 'claim_daily' }]);
  } else if (quotaCfg.dailyQuotaEnabled) {
    keyboard.push([{ text: `⏳ Kuota Harian Sudah Diambil (${countdown.hours}j ${countdown.minutes}m lagi)`, callback_data: 'claim_daily' }]);
  }

  keyboard.push([
    { text: '💎 Cek Kuota Saya', callback_data: 'cmd_my_quota' },
    { text: '🏠 Menu Utama', callback_data: 'cmd_menu' }
  ]);

  await sendTelegramMessage(targetReplyChatId, dashboardText, { inline_keyboard: keyboard });
}

// Send User Quota Status & Profile
async function sendUserQuotaStatus(userId: number, replyChatId: number, senderName: string) {
  const numericUserId = Number(userId);
  const targetReplyChatId = Number(replyChatId);
  const user = botConfig.activeUsers.find(
    (u) => (u.userId && Number(u.userId) === numericUserId) || Number(u.chatId) === numericUserId
  );
  const quotaCfg = botConfig.quotaConfig || DEFAULT_QUOTA_CONFIG;
  const todayWib = getWibDateString();
  const countdown = getTimeUntilNextWibMidnight();
  const personalQuota = user?.personalQuota || 0;
  const personalKey = user?.personalApiKey || `usr_${numericUserId}`;

  const statusCard = `💎 *INFORMASI KUOTA & PROFIL PRIBADI*
━━━━━━━━━━━━━━━━━━━━━━━━━
👤 *Nama Pengguna:* ${senderName}
🆔 *User ID:* \`${numericUserId}\`
🔒 *Status Akun:* ${user?.isVerified ? '✅ *Terverifikasi Resmi*' : '⚠️ *Belum Verifikasi*'}
📅 *Terdaftar Sejak:* ${formatWibDate(user?.firstSeen)}
━━━━━━━━━━━━━━━━━━━━━━━━━
📊 *RINCIAN KUOTA PRIBADI:*
• *Sisa Kuota Aktif:* *${personalQuota}x Pencarian OSINT*
• *API Key Pribadi:* \`${personalKey}\`

🎁 *STATUS JATAH KLAIM:*
• *Kuota Pengguna Baru (${quotaCfg.newUserQuotaAmount}x):* ${user?.hasClaimedNewUserQuota ? '✅ Sudah Diklaim (1x seumur hidup)' : '🎁 *Belum Diklaim (Siap Ambil)*'}
• *Kuota Harian (${quotaCfg.dailyQuotaAmount}x):* ${user?.dailyQuotaLastClaimedDate === todayWib ? `✅ Sudah Diklaim (Reset: ${countdown.hours}j ${countdown.minutes}m lagi)` : '✨ *Tersedia Hari Ini!*'}
━━━━━━━━━━━━━━━━━━━━━━━━━
💡 *Cara Menggunakan Kuota:*
Ketik perintah pencarian langsung:
• \`search: <target>\`
• \`/search <target>\`
• \`cari: <target>\`

Contoh: \`search: jokowi\` atau \`cari: slamet\`
_Kuota HANYA berkurang jika data target ditemukan di dataset!_`;

  const keyboard: any[][] = [
    [
      { text: '🎁 Ambil Kuota Gratis', callback_data: 'cmd_claim_menu' },
      { text: '💎 Top Up API Key', callback_data: 'cmd_pricing' }
    ],
    [
      { text: '📞 Hubungi Owner (@flood1233)', callback_data: 'cmd_owner' },
      { text: '🏠 Menu Utama', callback_data: 'cmd_menu' }
    ]
  ];

  await sendTelegramMessage(targetReplyChatId, statusCard, { inline_keyboard: keyboard });
}

// =========================================================================
// CONTENT MODERATION ENGINE: AUTO-DELETE ILLEGAL MESSAGES & DETAILED EXPLANATION
// =========================================================================

const MODERATION_GAMBLING_KEYWORDS = [
  'slot', 'sl0t', 'judol', 'judi online', 'judi bola', 'gacor', 'scatter', 'maxwin',
  'pragmatic', 'zeus slot', 'kakek zeus', 'olympus', 'sweet bonanza', 'mahjong ways',
  'bandar togel', 'togel online', 'toto gelap', 'togel sgp', 'togel hk', 'toto macau',
  'casino online', 'live casino', 'sbobet', 'agen judi', 'daftar slot', 'link slot',
  'link gacor', 'situs slot', 'situs judi', 'depo pulsa', 'depo 10k', 'depo 25k', 'depo 50k',
  'wd kilat', 'freebet', 'bocoran slot', 'pola gacor', 'jackpot slot', 'slot88',
  'slot777', 'rtp slot', 'rtp live', 'rolet online', 'baccarat online', 'domino qiu',
  'judi slot', 'agen slot', 'situs gacor', 'menang slot', 'gates of olympus', 'starlight princess',
  'spxslot', 'mposlot', 'hoki slot', 'sensational slot', 'pola slot', 'cheat slot'
];

const MODERATION_ADULT_KEYWORDS = [
  'bokep', 'b0kep', 'porn', 'porno', 'pornografi', '18+', 'vcs', 'open bo',
  'bo cod', 'av sub indo', 'video viral bokep', 'desah', 'sange', 'bugil',
  'toket', 'croot', 'crot', 'prostitusi', 'becek', 'mesum', 'seks', 'sex gratis',
  'masturbasi', 'ngentot', 'memek', 'kontol', 'jav sub', 'onlyfans bocor',
  'video mesum', 'doodstream', 'terabox bokep', 'vcs murah', 'pepek', 'ngocok',
  'lonte', 'perek', 'tetek', 'colmek', 'colik', 'hentai', 'bokep viral', 'lendir'
];

const MODERATION_DRUGS_KEYWORDS = [
  'narkoba', 'sabu', 'sabu-sabu', 'ekstasi', 'inex', 'inek', 'ganja',
  'tembakau gorila', 'tembakau sintetis', 'sinte', 'pil koplo', 'tramadol',
  'trihex', 'alprazolam', 'dumolid', 'kokain', 'heroin', 'psikotropika',
  'jual sabu', 'beli ganja', 'bong sabu', 'shabu', 'cimahi sinte', 'obat keras daftar g',
  'narkotika', 'pil anjing', 'methamphetamine', 'amfetamin'
];

const MODERATION_FRAUD_KEYWORDS = [
  'pinjol ilegal', 'pengganda uang', 'pesugihan uang gaib', 'dana kaget palsu',
  'jasa hack saldo dana', 'apk pembobol rekening', 'saldo dana gratis tipu',
  'jual beli rekening', 'rekening penampung', 'jual akun e-wallet bodong', 'arisan bodong',
  'investasi bodong', 'kloning atm'
];

const MODERATION_WEAPONS_KEYWORDS = [
  'jual senpi', 'senjata api rakitan', 'jual celurit begal', 'bom ikan',
  'bahan peledak rakitan', 'jual pistol rakitan', 'senjata tajam tawuran'
];

interface ModerationCheckResult {
  isBanned: boolean;
  category?: string;
  matchedKeyword?: string;
  explanation?: string;
}

function checkMessageModeration(rawText: string): ModerationCheckResult {
  const cfg = botConfig.moderationConfig || DEFAULT_MODERATION_CONFIG;
  if (!cfg.enabled) {
    return { isBanned: false };
  }

  const text = (rawText || '').trim();
  if (!text) return { isBanned: false };

  const lower = text.toLowerCase();
  // Normalize leetspeak
  const normalized = lower
    .replace(/[0o]/g, 'o')
    .replace(/[1l|!]/g, 'i')
    .replace(/3/g, 'e')
    .replace(/4/g, 'a')
    .replace(/5/g, 's')
    .replace(/\$/g, 's')
    .replace(/@/g, 'a');

  // Collapsed representation to defeat spaced-out evasion (e.g. "s l o t", "b.o.k.e.p", "v-c-s")
  const collapsed = normalized.replace(/[\s\-_.,/\\*#+@!~|]+/g, '');

  // 1. General Whitelist check
  if (Array.isArray(cfg.whitelistKeywords) && cfg.whitelistKeywords.length > 0) {
    for (const wl of cfg.whitelistKeywords) {
      const wClean = wl.trim().toLowerCase();
      if (wClean && (lower.includes(wClean) || normalized.includes(wClean) || collapsed.includes(wClean.replace(/\s+/g, '')))) {
        return { isBanned: false };
      }
    }
  }

  // 2. Cyber & OSINT Special Whitelist:
  // "tetapi yang berbau Cyber mau legal ilegal itu baru gapapa"
  if (cfg.allowCyberAndOsint !== false) {
    const cyberTerms = cfg.cyberWhitelistKeywords || DEFAULT_MODERATION_CONFIG.cyberWhitelistKeywords;
    const hasCyberContext = cyberTerms.some((ct) => {
      const term = ct.toLowerCase().trim();
      return term && (lower.includes(term) || normalized.includes(term));
    });

    if (hasCyberContext) {
      // If the message is talking about Cyber / OSINT / security / pentest / breach / leak,
      // it is EXPLICITLY ALLOWED!
      // Only block if it is explicitly an aggressive commercial slot/porn/drug spam advertisement
      const isBlatantCommercialSpam =
        /(link\s*slot|daftar\s*slot|depo\s*pulsa|open\s*bo|vcs\s*real|jual\s*sabu)/i.test(lower) ||
        /(linkslot|daftarslot|depopulsa|openbo|vcsreal|jualsabu)/i.test(collapsed);
      if (!isBlatantCommercialSpam) {
        return { isBanned: false };
      }
    }
  }

  // 3. Category Checks
  // A. Judi Online & Slot
  if (cfg.blockGamblingSlot !== false) {
    for (const kw of MODERATION_GAMBLING_KEYWORDS) {
      const kwCollapsed = kw.replace(/[\s\-_.]+/g, '');
      const regex = new RegExp(`(^|\\s|[^a-zA-Z0-9])${kw.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}($|\\s|[^a-zA-Z0-9])`, 'i');
      if (regex.test(lower) || lower.includes(kw) || normalized.includes(kw) || (kwCollapsed.length >= 4 && collapsed.includes(kwCollapsed))) {
        return {
          isBanned: true,
          category: '🎰 Judi Online / Slot / Kasino / Togel',
          matchedKeyword: kw,
          explanation: 'Pesan mengandung promosi, tautan, atau istilah perjudian online / slot yang dilarang undang-undang serta aturan ruang obrolan.'
        };
      }
    }
  }

  // B. Konten Dewasa & 18+
  if (cfg.blockAdult18Plus !== false) {
    for (const kw of MODERATION_ADULT_KEYWORDS) {
      const kwCollapsed = kw.replace(/[\s\-_.]+/g, '');
      const regex = new RegExp(`(^|\\s|[^a-zA-Z0-9])${kw.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}($|\\s|[^a-zA-Z0-9])`, 'i');
      if (regex.test(lower) || lower.includes(kw) || normalized.includes(kw) || (kwCollapsed.length >= 3 && collapsed.includes(kwCollapsed))) {
        return {
          isBanned: true,
          category: '🔞 Konten Dewasa / 18+ / Pornografi / VCS',
          matchedKeyword: kw,
          explanation: 'Pesan mengandung materi pornografi, ketidaksenonohan, VCS, prostitusi, atau materi 18+ terlarang.'
        };
      }
    }
  }

  // C. Narkoba & Zat/Obat Terlarang
  if (cfg.blockDrugs !== false) {
    for (const kw of MODERATION_DRUGS_KEYWORDS) {
      const kwCollapsed = kw.replace(/[\s\-_.]+/g, '');
      const regex = new RegExp(`(^|\\s|[^a-zA-Z0-9])${kw.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}($|\\s|[^a-zA-Z0-9])`, 'i');
      if (regex.test(lower) || lower.includes(kw) || normalized.includes(kw) || (kwCollapsed.length >= 4 && collapsed.includes(kwCollapsed))) {
        return {
          isBanned: true,
          category: '💊 Narkoba & Zat / Obat Terlarang',
          matchedKeyword: kw,
          explanation: 'Pesan mengandung indikasi penawaran, jual-beli, atau promosi narkotika dan obat-obatan terlarang.'
        };
      }
    }
  }

  // D. Penipuan Finansial & Phishing
  if (cfg.blockFraudScam !== false) {
    for (const kw of MODERATION_FRAUD_KEYWORDS) {
      const kwCollapsed = kw.replace(/[\s\-_.]+/g, '');
      if (lower.includes(kw) || normalized.includes(kw) || (kwCollapsed.length >= 6 && collapsed.includes(kwCollapsed))) {
        return {
          isBanned: true,
          category: '💳 Penipuan Finansial / Phishing / Scam',
          matchedKeyword: kw,
          explanation: 'Pesan mengandung modus penipuan keuangan, pinjol bodong ilegal, atau tautan phishing perbankan.'
        };
      }
    }
  }

  // E. Senjata & Bahan Peledak
  if (cfg.blockWeaponsExplosives !== false) {
    for (const kw of MODERATION_WEAPONS_KEYWORDS) {
      const kwCollapsed = kw.replace(/[\s\-_.]+/g, '');
      if (lower.includes(kw) || normalized.includes(kw) || (kwCollapsed.length >= 6 && collapsed.includes(kwCollapsed))) {
        return {
          isBanned: true,
          category: '💣 Senjata Ilegal & Bahan Berbahaya',
          matchedKeyword: kw,
          explanation: 'Pesan memuat transaksi senjata api rakitan atau bahan peledak ilegal yang mengancam keselamatan.'
        };
      }
    }
  }

  // F. Custom Banned Keywords
  if (Array.isArray(cfg.customBannedKeywords)) {
    for (const kw of cfg.customBannedKeywords) {
      const cleanKw = kw.trim().toLowerCase();
      const kwCollapsed = cleanKw.replace(/[\s\-_.]+/g, '');
      if (cleanKw && (lower.includes(cleanKw) || normalized.includes(cleanKw) || (kwCollapsed.length >= 3 && collapsed.includes(kwCollapsed)))) {
        return {
          isBanned: true,
          category: '🚫 Kata Kunci Terlarang (Kustom Pengelola)',
          matchedKeyword: kw,
          explanation: 'Pesan memuat kata kunci terlarang khusus yang telah diatur oleh pengelola bot.'
        };
      }
    }
  }

  return { isBanned: false };
}

async function handleBannedMessage(message: any, checkResult: ModerationCheckResult) {
  const chat = message.chat;
  const chatId = chat.id;
  const from = message.from || chat;
  const messageId = message.message_id;
  const senderName = [from.first_name, from.last_name].filter(Boolean).join(' ') || from.username || 'Pengguna';
  const usernameTag = from.username ? `@${from.username}` : '-';
  const rawText = (message.text || message.caption || '').trim();
  const isGroup = chat.type === 'group' || chat.type === 'supergroup';
  const wibTime = getFormattedWIB().fullStr;

  // 1. Delete the message via Telegram API
  let deleteSuccess = false;
  let deleteError: string | undefined;

  try {
    const delRes = await callTelegramApi(
      botConfig.token,
      'deleteMessage',
      { chat_id: chatId, message_id: messageId },
      8000
    );
    if (delRes && delRes.ok) {
      deleteSuccess = true;
    } else {
      deleteError = delRes?.description || 'Gagal menghapus pesan (Pastikan bot adalah Admin dengan izin Delete Messages).';
    }
  } catch (err: any) {
    deleteError = err.message;
  }

  addLog(
    'system',
    `[Auto-Moderasi] Pesan dari ${senderName} (${usernameTag}) ${deleteSuccess ? 'berhasil dihapus' : 'gagal dihapus'}. Kategori: ${checkResult.category} | Kata: "${checkResult.matchedKeyword}"`,
    chatId
  );

  // 2. Prepare Detailed Explanation & Copied Original Message
  const safeQuotedMessage = rawText.length > 500 ? rawText.substring(0, 500) + '... (dipersingkat)' : rawText;

  const warningMessage = `🚫 *PESAN OTOMATIS DIHAPUS OLEH SISTEM KEAMANAN*
━━━━━━━━━━━━━━━━━━━━━━━━━
👤 *Pengirim:* ${senderName} (${usernameTag})
🆔 *User ID:* \`${from.id}\`
🕒 *Waktu Tindakan:* ${wibTime}
🏛️ *Ruang Obrolan:* ${chat.title ? `*${chat.title}*` : 'Chat Pribadi'}

⚠️ *DETAIL KESALAHAN & PELANGGARAN:*
• *Kategori Terlarang:* ${checkResult.category}
• *Kata Kunci Terdeteksi:* \`${checkResult.matchedKeyword}\`
• *Keterangan Aturan:* ${checkResult.explanation}

📝 *SALINAN PESAN ASLI PENGIRIM:*
\`\`\`
${safeQuotedMessage}
\`\`\`

🛡️ *KEBIJAKAN KETERTIBAN SISTEM:*
Bot *axxosintbot* menerapkan penyaringan otomatis tanpa kompromi terhadap:
1. 🎰 *Judi Online, Slot Gacor, Kasino & Togel*
2. 🔞 *Konten Dewasa, Bokep, VCS & Prostitusi*
3. 💊 *Narkoba, Psikotropika & Zat/Obat Terlarang*
4. 💳 *Penipuan Finansial, Phishing & Scam Rekening*

ℹ️ *PENGECUALIAN RESMI (CYBER & OSINT):*
Seluruh topik edukasi, investigasi, analisis, dan diskusi seputar *Cyber Security, OSINT, Exploit, Penetration Testing, Kebocoran Data (Data Leak) & Forensik* tetap *100% BEBAS & DIPERBOLEHKAN*.
━━━━━━━━━━━━━━━━━━━━━━━━━
💡 _Pesan pelanggaran telah dimusnahkan demi kenyamanan dan keamanan bersama._`;

  // 3. Send Explanation Message
  const cfg = botConfig.moderationConfig || DEFAULT_MODERATION_CONFIG;
  if (cfg.sendExplanationMessage !== false) {
    const sentMsg = await sendTelegramMessage(chatId, warningMessage);
    if (sentMsg && sentMsg.message_id && cfg.autoDeleteExplanationSeconds && cfg.autoDeleteExplanationSeconds > 0) {
      setTimeout(async () => {
        try {
          await callTelegramApi(
            botConfig.token,
            'deleteMessage',
            { chat_id: chatId, message_id: sentMsg.message_id },
            5000
          );
        } catch {}
      }, cfg.autoDeleteExplanationSeconds * 1000);
    }
  }

  // 4. Record Incident in Recent Moderation Incidents
  if (!botConfig.moderationConfig) {
    botConfig.moderationConfig = { ...DEFAULT_MODERATION_CONFIG };
  }
  if (!Array.isArray(botConfig.moderationConfig.recentIncidents)) {
    botConfig.moderationConfig.recentIncidents = [];
  }
  const incident: ModerationIncident = {
    id: `mod_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
    chatId: Number(chatId),
    chatTitle: isGroup ? chat.title : undefined,
    userId: Number(from.id),
    userName: senderName,
    usernameTag,
    category: checkResult.category || 'Konten Terlarang',
    matchedKeyword: checkResult.matchedKeyword || '-',
    originalMessage: rawText,
    timestamp: new Date().toISOString(),
    actionTaken: deleteSuccess ? 'deleted_and_warned' : 'delete_failed',
    errorMessage: deleteError
  };
  botConfig.moderationConfig.recentIncidents.unshift(incident);
  if (botConfig.moderationConfig.recentIncidents.length > 60) {
    botConfig.moderationConfig.recentIncidents.pop();
  }
  saveBotConfig();
}

// Handle Incoming Telegram Message
async function handleIncomingMessage(message: any) {
  if (!message || !message.chat) return;

  const chat = message.chat;
  const from = message.from || chat;

  // 1. Anti-Loop & Anti-Spam: Ignore other automated bots and channel broadcasts
  if (from.is_bot) return;
  if (chat.type === 'channel') return;

  const chatId = chat.id;
  const isGroup = chat.type === 'group' || chat.type === 'supergroup';
  const senderName = [from.first_name, from.last_name].filter(Boolean).join(' ') || from.username || 'Pengguna';
  const usernameTag = from.username ? `@${from.username}` : '-';

  // 2. Anti-Spam: Deduplicate Telegram message IDs (prevent re-delivered updates from triggering duplicate replies)
  const msgDedupKey = `${chatId}_${message.message_id}`;
  if (processedMessageIds.has(msgDedupKey)) {
    return;
  }
  processedMessageIds.add(msgDedupKey);
  if (processedMessageIds.size > 3000) {
    const firstKey = processedMessageIds.values().next().value;
    if (firstKey) processedMessageIds.delete(firstKey);
  }

  // 3. Group Handling & Permissions
  if (isGroup) {
    updateKnownGroup(chat);

    // If bot is configured to NOT allow group operation
    if (botConfig.groupConfig && !botConfig.groupConfig.allowGroups) {
      return;
    }

    // Check if group is blacklisted
    if (botConfig.groupConfig?.blockedGroupIds?.includes(Number(chatId))) {
      return;
    }

    // Check if group whitelist is enforced
    if (
      botConfig.groupConfig?.allowedGroupIds &&
      botConfig.groupConfig.allowedGroupIds.length > 0 &&
      !botConfig.groupConfig.allowedGroupIds.includes(Number(chatId))
    ) {
      return;
    }
  }

  const rawText = (message.text || message.caption || '').trim();
  botConfig.stats.messagesReceived += 1;
  const currentUser = registerOrUpdateUser(from, chat);

  // 4. Content Moderation & Auto-Delete Illegal Content (Slots, 18+, Drugs, Scam, etc.)
  if (rawText) {
    const moderationResult = checkMessageModeration(rawText);
    if (moderationResult.isBanned) {
      const shouldDelete =
        (isGroup && botConfig.moderationConfig?.deleteInGroups !== false) ||
        (!isGroup && botConfig.moderationConfig?.deleteInPrivate !== false);

      if (shouldDelete) {
        await handleBannedMessage(message, moderationResult);
        return; // Stop processing: Message deleted & detailed warning sent!
      }
    }
  }

  if (!rawText) {
    if (message.photo || message.document || message.sticker) {
      if (!isGroup) {
        await sendTelegramMessage(
          chatId,
          `📥 Berkas media diterima dari *${senderName}*.\nKetik /id untuk cek Chat ID atau /menu untuk membuka opsi.`
        );
      }
    }
    return;
  }

  // 4. Group Command Normalization & Bot Tag Filtering
  const botUsername = (currentBotInfo?.username || '').toLowerCase();
  let text = rawText;
  let isExplicitMention = false;

  if (text.startsWith('/')) {
    const cmdMatch = text.match(/^\/([a-zA-Z0-9_]+)@([a-zA-Z0-9_]+)/i);
    if (cmdMatch) {
      const targetBot = cmdMatch[2].toLowerCase();
      if (botUsername && targetBot !== botUsername) {
        // Command is targeted at another bot in the group, do NOT respond!
        return;
      }
      text = '/' + cmdMatch[1] + text.substring(cmdMatch[0].length);
    }
  }

  if (botUsername && text.toLowerCase().includes(`@${botUsername}`)) {
    isExplicitMention = true;
    text = text.replace(new RegExp(`@${botUsername}\\b`, 'gi'), '').trim();
  }

  const lowerText = text.toLowerCase();

  // 5. Anti-Flood / Anti-Spam Rate Limiter (Active for both Private & Groups)
  const isCommandLike =
    text.startsWith('/') ||
    lowerText.startsWith('search:') ||
    lowerText.startsWith('search ') ||
    lowerText.startsWith('osint:') ||
    lowerText.startsWith('cari:') ||
    lowerText.startsWith('cari ') ||
    lowerText.startsWith('cek:') ||
    lowerText.startsWith('cek ') ||
    lowerText.startsWith('track:') ||
    lowerText.startsWith('track ') ||
    lowerText.startsWith('api ') ||
    lowerText.startsWith('ax0895') ||
    isExplicitMention;

  const isAntiFloodOn = botConfig.groupConfig?.enableAntiFlood !== false;
  if (isAntiFloodOn) {
    const floodKey = `user_${from.id}`;
    const nowMs = Date.now();
    const cooldownMs = Math.max(1, botConfig.groupConfig?.antiFloodCooldownSeconds || 3) * 1000;
    const lastAction = lastUserActionTimestamp.get(floodKey) || 0;

    // Adaptive Security Burst Defense (Catches automated burst scraping loops)
    if (isCommandLike) {
      const burstCheck = checkAdaptiveSecurityBurst(from.id, chatId, senderName);
      if (burstCheck.isBlocked && burstCheck.message) {
        await sendTelegramMessage(chatId, burstCheck.message);
        return;
      }
    }

    if (nowMs - lastAction < cooldownMs) {
      const lastWarn = floodWarningSentTimestamps.get(floodKey) || 0;
      if (nowMs - lastWarn > 6000) {
        floodWarningSentTimestamps.set(floodKey, nowMs);
        await sendTelegramMessage(
          chatId,
          `⏳ *Anti-Flood & Anti-Spam Protection*\nMohon tunggu *${botConfig.groupConfig?.antiFloodCooldownSeconds || 3} detik* sebelum mengirim pesan atau perintah berikutnya.`
        );
      }
      return;
    }
    lastUserActionTimestamp.set(floodKey, nowMs);
  }

  // 6. Group Admin Restriction Check
  if (isGroup && botConfig.groupConfig?.groupAdminOnly && isCommandLike) {
    const isAdmin = await isTelegramGroupAdmin(botConfig.token, chatId, from.id);
    if (!isAdmin) {
      await sendTelegramMessage(
        chatId,
        `⚠️ *Izin Ditolak:* Perintah bot di grup ini hanya diizinkan untuk Admin / Pemilik Grup.`
      );
      return;
    }
  }

  addLog('incoming', `"${text}"`, chatId, `${senderName} (${usernameTag})`);
  const wibTime = getFormattedWIB();
  const pricing = getPricingData(currentUser.languageCode);

  // =========================================================================
  // 1. SECRET OWNER COMMAND: ax0895 (Hidden Menu)
  // =========================================================================
  if (lowerText === 'ax0895' || lowerText.startsWith('ax0895 ') || lowerText === '/ax0895' || lowerText.startsWith('/ax0895 ')) {
    botConfig.stats.commandsExecuted += 1;
    saveBotConfig();

    const parts = text.split(/\s+/);
    const subCmd = (parts[1] || '').toLowerCase();

    // ax0895 on -> Turn ON OSINT
    if (subCmd === 'on') {
      botConfig.osintConfig.enabled = true;
      botConfig.osintConfig.lastToggledAt = new Date().toISOString();
      saveBotConfig();
      addLog('system', `Owner mengaktifkan server OSINT via Telegram (ax0895 on).`);

      await sendTelegramMessage(chatId, `🟢 *SERVER OSINT BERHASIL DIAKTIFKAN (ON)*\n\nServer Ngrok: \`${botConfig.osintConfig.ngrokUrl}\`\n\nMenyiarkan notifikasi status ON ke seluruh pengguna...`);
      if (botConfig.osintConfig.notifyOnStatusChange) {
        broadcastOsintStatusChange(true).catch(console.error);
      }
      return;
    }

    // ax0895 off -> Turn OFF OSINT
    if (subCmd === 'off') {
      botConfig.osintConfig.enabled = false;
      botConfig.osintConfig.lastToggledAt = new Date().toISOString();
      saveBotConfig();
      addLog('system', `Owner menonaktifkan server OSINT via Telegram (ax0895 off).`);

      await sendTelegramMessage(chatId, `🔴 *SERVER OSINT BERHASIL DINONAKTIFKAN (OFF)*\n\nMenyiarkan notifikasi status OFF ke seluruh pengguna...`);
      if (botConfig.osintConfig.notifyOnStatusChange) {
        broadcastOsintStatusChange(false).catch(console.error);
      }
      return;
    }

    // ax0895 ngrok <url> -> Update Ngrok URL
    if (subCmd === 'ngrok') {
      const newUrl = parts.slice(2).join(' ').trim();
      if (!newUrl.startsWith('http://') && !newUrl.startsWith('https://')) {
        await sendTelegramMessage(chatId, `❌ *Format Salah!*\n\nContoh: \`ax0895 ngrok https://dd60-180-247-62-62.ngrok-free.app\``);
        return;
      }
      botConfig.osintConfig.ngrokUrl = newUrl;
      saveBotConfig();
      addLog('system', `Owner memperbarui Ngrok URL via Telegram ke: ${newUrl}`);
      await sendTelegramMessage(chatId, `✅ *URL NGROK DIPERBARUI!*\n\n🌐 URL Baru: \`${newUrl}\`\nStatus OSINT: ${botConfig.osintConfig.enabled ? '🟢 ON' : '🔴 OFF'}`);
      return;
    }

    // ax0895 addkey <key> <quota> [notes] -> Add API Key
    if (subCmd === 'addkey') {
      const newKey = parts[2];
      const quotaStr = parts[3];
      const notes = parts.slice(4).join(' ') || 'Dibuat via ax0895 Telegram';

      if (!newKey || !quotaStr) {
        await sendTelegramMessage(chatId, `❌ *Format Salah!*\n\nContoh:\n• \`ax0895 addkey user1 15 Paket 10k\`\n• \`ax0895 addkey user2 unlimited Paket 100k\``);
        return;
      }

      const isUnlimited = quotaStr.toLowerCase() === 'unlimited' || quotaStr === '999999';
      const quotaNum = isUnlimited ? 999999 : parseInt(quotaStr, 10) || 5;

      // Bonus rule: pembelian >= 15 atau harga > 10k mendapatkan bonus 1x
      const bonus = isUnlimited ? 0 : quotaNum >= 15 ? 1 : 0;

      const newApiKey: OsintApiKey = {
        id: `key-${Date.now()}`,
        key: newKey,
        ownerNotes: notes,
        tier: isUnlimited ? 'unlimited' : 'limited',
        initialQuota: quotaNum,
        remainingQuota: quotaNum,
        bonusQuota: bonus,
        totalUsed: 0,
        createdAt: new Date().toISOString(),
        enabled: true
      };

      // Remove duplicate if exists
      botConfig.osintConfig.apiKeys = botConfig.osintConfig.apiKeys.filter((k) => k.key.toLowerCase() !== newKey.toLowerCase());
      botConfig.osintConfig.apiKeys.unshift(newApiKey);
      saveBotConfig();

      addLog('system', `Owner membuat API Key baru: "${newKey}" (${quotaNum}x + ${bonus} bonus).`);
      await sendTelegramMessage(
        chatId,
        `✅ *API KEY BERHASIL DIBUAT!*\n\n🔑 *Key:* \`${newKey}\`\n📊 *Tipe:* ${isUnlimited ? 'Unlimited' : `${quotaNum}x pakai`}\n🎁 *Bonus Ekstra:* ${bonus}x\n📝 *Catatan:* ${notes}\n\n_Pengguna dapat mengecek kuota dengan mengetik:_ \`api ${newKey}\``
      );
      return;
    }

    // ax0895 delkey <key> -> Delete API Key
    if (subCmd === 'delkey') {
      const targetKey = parts[2];
      if (!targetKey) {
        await sendTelegramMessage(chatId, `❌ Ketik: \`ax0895 delkey <key>\``);
        return;
      }
      const beforeCount = botConfig.osintConfig.apiKeys.length;
      botConfig.osintConfig.apiKeys = botConfig.osintConfig.apiKeys.filter((k) => k.key.toLowerCase() !== targetKey.toLowerCase());
      saveBotConfig();
      if (botConfig.osintConfig.apiKeys.length < beforeCount) {
        await sendTelegramMessage(chatId, `✅ API Key \`${targetKey}\` berhasil dihapus.`);
      } else {
        await sendTelegramMessage(chatId, `⚠️ API Key \`${targetKey}\` tidak ditemukan.`);
      }
      return;
    }

    // ax0895 keys -> List all keys
    if (subCmd === 'keys') {
      const keys = botConfig.osintConfig.apiKeys;
      if (keys.length === 0) {
        await sendTelegramMessage(chatId, `📭 Belum ada API Key yang tersimpan.`);
        return;
      }
      const listStr = keys
        .map((k, i) => {
          const quota = k.tier === 'unlimited' ? 'Unlimited' : `${k.remainingQuota} sisa (+${k.bonusQuota} bonus)`;
          return `${i + 1}. \`${k.key}\` [${k.enabled ? 'Aktif' : 'Nonaktif'}]\n   • Kuota: ${quota}\n   • Terpakai: ${k.totalUsed}x\n   • Catatan: ${k.ownerNotes}`;
        })
        .join('\n\n');

      await sendTelegramMessage(chatId, `🔑 *DAFTAR API KEY AKTIF (${keys.length}):*\n━━━━━━━━━━━━━━━━━━━━━━━━━\n${listStr}`);
      return;
    }

    // ax0895 test -> Test ping ngrok
    if (subCmd === 'test') {
      await sendTelegramMessage(chatId, `🔄 Mengetes koneksi ke Ngrok: \`${botConfig.osintConfig.ngrokUrl}\`...`);
      try {
        const testTarget = `${botConfig.osintConfig.ngrokUrl.replace(/\/$/, '')}/api/v1/search?q=ping&apiKey=test`;
        const testRes = await fetch(testTarget, { method: 'GET', headers: { 'User-Agent': 'TelegramBot/1.0' } });
        await sendTelegramMessage(chatId, `✅ *RESPON NGROK OK!*\n\nStatus HTTP: *${testRes.status} ${testRes.statusText}*\nURL: \`${testTarget}\``);
      } catch (err: any) {
        await sendTelegramMessage(chatId, `❌ *NGROK OFFLINE / GAGAL!*\n\nError: \`${err.message}\`\nPastikan tunnel ngrok sedang running.`);
      }
      return;
    }

    // ax0895 addmenu <label> | <response text>
    if (subCmd === 'addmenu') {
      const remainder = text.substring(text.indexOf(parts[1]) + parts[1].length).trim();
      const splitPipe = remainder.split('|');
      if (splitPipe.length < 2) {
        await sendTelegramMessage(chatId, `❌ *Format Salah!*\n\nContoh:\n\`ax0895 addmenu 🎁 Promo Khusus | Dapatkan diskon 50% untuk pembelian API Key hari ini! Hubungi @flood1233\``);
        return;
      }
      const label = splitPipe[0].trim();
      const reply = splitPipe.slice(1).join('|').trim();

      const newMenu: CustomMenuItem = {
        id: `m-${Date.now()}`,
        label,
        type: 'callback',
        responseText: reply,
        enabled: true
      };

      botConfig.customMenus = botConfig.customMenus || [];
      botConfig.customMenus.push(newMenu);
      saveBotConfig();

      addLog('system', `Owner menambahkan tombol menu baru via Telegram: "${label}"`);
      await sendTelegramMessage(chatId, `✅ *TOMBOL MENU BERHASIL DITAMBAHKAN!*\n\n🔘 *Tombol:* ${label}\n💬 *Respon:* ${reply}\n\nTombol kini langsung tampil di /menu Telegram!`);
      return;
    }

    // ax0895 delmenu <id or keyword>
    if (subCmd === 'delmenu') {
      const target = parts[2];
      if (!target) {
        await sendTelegramMessage(chatId, `❌ Ketik: \`ax0895 delmenu <id_atau_nama_tombol>\``);
        return;
      }
      const beforeLen = (botConfig.customMenus || []).length;
      botConfig.customMenus = (botConfig.customMenus || []).filter(
        (m) => m.id !== target && !m.label.toLowerCase().includes(target.toLowerCase())
      );
      saveBotConfig();
      if ((botConfig.customMenus || []).length < beforeLen) {
        await sendTelegramMessage(chatId, `✅ Menu "${target}" berhasil dihapus.`);
      } else {
        await sendTelegramMessage(chatId, `⚠️ Menu "${target}" tidak ditemukan.`);
      }
      return;
    }

    // ax0895 menus
    if (subCmd === 'menus') {
      const menus = botConfig.customMenus || [];
      if (menus.length === 0) {
        await sendTelegramMessage(chatId, `📭 Belum ada menu kustom tambahan.`);
        return;
      }
      const listStr = menus
        .map((m, i) => `${i + 1}. *${m.label}* [ID: \`${m.id}\`] (${m.enabled ? 'Aktif' : 'Nonaktif'})\n   • Tipe: ${m.type}\n   • Respon: ${m.type === 'url' ? m.url : (m.responseText?.substring(0, 60) + '...')}`)
        .join('\n\n');
      await sendTelegramMessage(chatId, `📋 *DAFTAR MENU KUSTOM TAMBAHAN (${menus.length}):*\n━━━━━━━━━━━━━━━━━━━━━━━━━\n${listStr}`);
      return;
    }

    // Default: Show Secret Owner Menu Dashboard
    const totalKeys = botConfig.osintConfig.apiKeys.length;
    const totalMenus = (botConfig.customMenus || []).length;
    const isOsintOn = botConfig.osintConfig.enabled;
    const ownerCard = `👑 *MENU RAHASIA OWNER (ax0895)*
━━━━━━━━━━━━━━━━━━━━━━━━━
Status Fitur OSINT: ${isOsintOn ? '🟢 *AKTIF (ON)*' : '🔴 *NONAKTIF (OFF)*'}
🌐 Ngrok URL: \`${botConfig.osintConfig.ngrokUrl}\`
🔑 Total API Key: *${totalKeys} key*
🗂️ Menu Tambahan: *${totalMenus} menu*
👥 Total Pengguna Bot: *${botConfig.activeUsers.length} pengguna*
🔍 Total Pencarian OSINT: *${botConfig.stats.osintSearchesCount || 0}x*
━━━━━━━━━━━━━━━━━━━━━━━━━
📖 *Perintah Cepat Owner:*
• \`ax0895 on\` - Aktifkan OSINT & siarkan notifikasi
• \`ax0895 off\` - Matikan OSINT & siarkan notifikasi
• \`ax0895 ngrok <url>\` - Ganti URL server Ngrok
• \`ax0895 addkey <key> <kuota> [notes]\` - Tambah API Key
• \`ax0895 delkey <key>\` - Hapus API Key
• \`ax0895 keys\` - Lihat semua API Key & sisa kuota
• \`ax0895 addmenu <label> | <balasan>\` - Tambah tombol menu baru
• \`ax0895 delmenu <id>\` - Hapus tombol menu
• \`ax0895 menus\` - Lihat daftar tombol menu
• \`ax0895 test\` - Cek koneksi ke server Ngrok`;

    await sendTelegramMessage(chatId, ownerCard, {
      inline_keyboard: [
        [
          { text: isOsintOn ? '🔴 Matikan OSINT (OFF)' : '🟢 Aktifkan OSINT (ON)', callback_data: isOsintOn ? 'ax_off' : 'ax_on' },
          { text: '🔑 Cek Daftar Key', callback_data: 'ax_keys' }
        ],
        [
          { text: '🌐 Tes Ping Ngrok', callback_data: 'ax_test' },
          { text: '🗂️ Cek Menu Kustom', callback_data: 'ax_menus' }
        ],
        [
          { text: '🏠 Buka Menu Utama', callback_data: 'cmd_menu' }
        ]
      ]
    });
    return;
  }

  // =========================================================================
  // 2. MANDATORY VERIFICATION GATE: /id
  // If user is NOT verified yet, they MUST send /id to unlock features!
  // =========================================================================
  if (!currentUser.isVerified) {
    // If the message is /id, verify the user immediately!
    if (['/id', '/myid', '/chatid'].includes(lowerText)) {
      currentUser.isVerified = true;
      currentUser.verifiedAt = new Date().toISOString();
      syncUserApiKey(currentUser);
      saveBotConfig();

      addLog('system', `Pengguna ${chatId} (${senderName}) berhasil diverifikasi via /id.`);

      const verifiedCard = `✅ *AKUN BERHASIL TERVERIFIKASI RESMI!*
━━━━━━━━━━━━━━━━━━━━━━━━━
Terima kasih, *${senderName}*! Akun Telegram Anda telah terverifikasi secara resmi di sistem bot.

🆔 *Chat ID:* \`${chatId}\`
👤 *Nama Lengkap:* ${senderName}
🏷 *Username:* ${usernameTag}
🕒 *Waktu Verifikasi:* ${wibTime.fullStr}
━━━━━━━━━━━━━━━━━━━━━━━━━
🎁 *HADIAH SAMBUTAN PENGGUNA BARU:*
Sebagai akun terverifikasi baru, Anda berhak mengklaim *+5x Kuota Pencarian OSINT Gratis* (1x seumur hidup)!

👉 *Ketik:* \`/claim\` atau klik tombol di bawah untuk mengambil kuota gratis Anda sekarang!`;

      await sendTelegramMessage(chatId, verifiedCard, {
        inline_keyboard: [
          [{ text: '🎁 Ambil Kuota Pengguna Baru (+5x)', callback_data: 'claim_new_user' }],
          [{ text: '🏠 Buka Menu Utama', callback_data: 'cmd_menu' }]
        ]
      });
      return;
    }

    // If the message is /start or /menu, give explicit instruction to send /id
    if (lowerText === '/start' || lowerText.startsWith('/start ') || lowerText === '/menu') {
      const verificationPrompt = `👋 *Halo ${senderName}! Selamat datang di Telegram Bot.*

🔒 *STATUS: WAJIB VERIFIKASI AWAL*
━━━━━━━━━━━━━━━━━━━━━━━━━
Untuk keamanan dan mengaktifkan seluruh fitur bot, Anda *WAJIB* mengirim pesan */id* terlebih dahulu agar akun terverifikasi di sistem kami.

👉 *Silakan kirim perintah:* \`/id\`
Atau sentuh tombol di bawah ini untuk verifikasi langsung.
━━━━━━━━━━━━━━━━━━━━━━━━━`;

      await sendTelegramMessage(chatId, verificationPrompt, {
        inline_keyboard: [
          [{ text: '🆔 Verifikasi Akun Sekarang (/id)', callback_data: 'verify_id' }]
        ]
      });
      return;
    }

    // For any other messages while unverified, block and remind user to send /id
    const unverifiedNotice = `⚠️ *AKUN BELUM TERVERIFIKASI*
━━━━━━━━━━━━━━━━━━━━━━━━━
Sebelum dapat menggunakan fitur atau menu bot, Anda *WAJIB* mengirim pesan: \`/id\`

Ketik \`/id\` sekarang untuk menyelesaikan verifikasi awal akun Anda.`;

    await sendTelegramMessage(chatId, unverifiedNotice, {
      inline_keyboard: [
        [{ text: '🆔 Verifikasi Akun Sekarang (/id)', callback_data: 'verify_id' }]
      ]
    });
    return;
  }

  // =========================================================================
  // 3. VERIFIED USERS: COMMANDS & OSINT
  // =========================================================================

  // Command: /start or /menu
  if (lowerText === '/start' || lowerText.startsWith('/start ') || lowerText === '/menu') {
    botConfig.stats.commandsExecuted += 1;
    saveBotConfig();

    const todayWib = getWibDateString();
    const isDailyClaimed = currentUser.dailyQuotaLastClaimedDate === todayWib;
    const isNewClaimed = Boolean(currentUser.hasClaimedNewUserQuota);
    const quotaBalance = currentUser.personalQuota || 0;

    const welcome = botConfig.welcomeMessage || DEFAULT_WELCOME_MESSAGE;
    const personalizedWelcome = `${welcome}

👤 *Pengguna:* ${senderName}
🆔 *Chat ID:* \`${chatId}\` ✅ _(Terdaftar Resmi)_
💎 *Sisa Kuota Pribadi:* *${quotaBalance}x Pencarian*
🎁 *Status Klaim:* ${!isNewClaimed ? '🎁 *Bonus Baru Tersedia (+5x)*' : !isDailyClaimed ? '✨ *Kuota Harian Tersedia (+2x)*' : '✅ Kuota Harian Sudah Diambil'}`;

    await sendTelegramMessage(chatId, personalizedWelcome, getMainInlineMenu(botConfig.osintConfig.enabled));
    return;
  }

  // Command: /id, /myid, /chatid (CHECK CHAT ID - SAFE & NEVER RESETS STATUS)
  if (['/id', '/myid', '/chatid'].includes(lowerText)) {
    botConfig.stats.commandsExecuted += 1;
    saveBotConfig();

    const todayWib = getWibDateString();
    const countdown = getTimeUntilNextWibMidnight();
    const firstSeenFormatted = formatWibDate(currentUser.firstSeen);

    const idCard = `📋 *DETAIL INFORMASI CHAT ID & PROFIL AKUN*
━━━━━━━━━━━━━━━━━━━━━━━━━
🆔 *Chat ID:* \`${chatId}\`
👤 *Nama Lengkap:* ${senderName}
🏷 *Username:* ${usernameTag}
💬 *Tipe Obrolan:* ${chat.type.toUpperCase()}
🔢 *Message ID:* \`${message.message_id}\`
🕒 *Waktu Sistem:* ${wibTime.fullStr}
🔒 *Status Akun:* ✅ *Terverifikasi Resmi* (Terdaftar sejak: ${firstSeenFormatted})
━━━━━━━━━━━━━━━━━━━━━━━━━
💎 *STATUS KUOTA PRIBADI ANDA:*
• *Sisa Kuota Aktif:* *${currentUser.personalQuota || 0}x Pencarian*
• *API Key Pribadi:* \`${currentUser.personalApiKey || `usr_${chatId}`}\`

🎁 *STATUS JATAH KLAIM:*
• *Kuota Pengguna Baru (5x):* ${currentUser.hasClaimedNewUserQuota ? '✅ Sudah Diklaim (1x seumur hidup)' : '🎁 *Belum Diklaim (Siap Diambil)*'}
• *Kuota Harian (2x):* ${currentUser.dailyQuotaLastClaimedDate === todayWib ? `✅ Sudah Diklaim (Reset: ${countdown.formatted} lagi)` : '✨ *Tersedia Hari Ini (Bisa Diklaim)*'}
━━━━━━━━━━━━━━━━━━━━━━━━━
🛡️ _Catatan: Akun Anda tersimpan permanen. Menjalankan perintah /id tidak akan mereset status, profil, ataupun kuota Anda._`;

    await sendTelegramMessage(chatId, idCard, {
      inline_keyboard: [
        [
          { text: '🎁 Menu Klaim Kuota', callback_data: 'cmd_claim_menu' },
          { text: '💎 Cek Saldo Kuota', callback_data: 'cmd_my_quota' }
        ],
        [
          { text: '🔄 Muat Ulang ID', callback_data: 'cmd_id' },
          { text: '🏠 Buka Menu Utama', callback_data: 'cmd_menu' }
        ]
      ]
    });
    return;
  }

  // Command: /claim, /klaim, /bonus (CLAIM DASHBOARD)
  if (['/claim', '/klaim', '/bonus', 'claim', 'klaim'].includes(lowerText)) {
    botConfig.stats.commandsExecuted += 1;
    saveBotConfig();
    await sendClaimQuotaDashboard(from.id, Number(chatId), senderName);
    return;
  }

  // Command: /claim_new, /klaim_baru (DIRECT CLAIM NEW USER QUOTA)
  if (['/claim_new', '/claimnew', '/klaim_baru', '/klaimbaru'].includes(lowerText)) {
    botConfig.stats.commandsExecuted += 1;
    saveBotConfig();
    await handleClaimNewUserQuota(from.id, Number(chatId), senderName);
    return;
  }

  // Command: /claim_daily, /claimdaily, /klaim_harian, /klaimharian, /daily (DIRECT CLAIM DAILY QUOTA)
  if (['/claim_daily', '/claimdaily', '/klaim_harian', '/klaimharian', '/daily', 'daily'].includes(lowerText)) {
    botConfig.stats.commandsExecuted += 1;
    saveBotConfig();
    await handleClaimDailyQuota(from.id, Number(chatId), senderName);
    return;
  }

  // Command: /kuota, /quota, /myquota, /saldo (CHECK USER'S PERSONAL QUOTA)
  if (['/kuota', '/quota', '/myquota', '/saldo', 'kuota', 'quota'].includes(lowerText)) {
    botConfig.stats.commandsExecuted += 1;
    saveBotConfig();
    await sendUserQuotaStatus(from.id, Number(chatId), senderName);
    return;
  }

  // Command: /osint (OSINT STATUS & USAGE)
  if (lowerText === '/osint' || lowerText === 'osint') {
    botConfig.stats.commandsExecuted += 1;
    saveBotConfig();

    const isOsintOn = botConfig.osintConfig.enabled;

    if (!isOsintOn) {
      // OSINT is OFF
      const offCard = `🔴 *STATUS SERVER DATA OSINT: NONAKTIF (OFF)*
━━━━━━━━━━━━━━━━━━━━━━━━━
⚠️ *Mohon maaf, Server Data OSINT saat ini belum diaktifkan oleh Owner.*

Fitur pencarian intelijen tidak dapat digunakan selama server masih dalam keadaan nonaktif.

📞 *CARA MENGAKTIFKAN:*
Jika Anda ingin menggunakan fitur ini, Anda harus menghubungi Owner Bot untuk mengaktifkan data/server OSINT:
👤 *Owner Telegram:* @flood1233
_(Bebas mau chat ataupun call, asal tidak spam)_
━━━━━━━━━━━━━━━━━━━━━━━━━`;

      await sendTelegramMessage(chatId, offCard, {
        inline_keyboard: [
          [{ text: '📞 Hubungi Owner @flood1233', url: 'https://t.me/flood1233' }],
          [{ text: '💎 Lihat Tarif Harga API Key', callback_data: 'cmd_pricing' }],
          [{ text: '🏠 Kembali ke Menu Utama', callback_data: 'cmd_menu' }]
        ]
      });
      return;
    }

    // OSINT is ON
    const onCard = `🟢 *STATUS SERVER DATA OSINT: AKTIF (ON)*
━━━━━━━━━━━━━━━━━━━━━━━━━
Server Data OSINT saat ini *SEDANG AKTIF* dan siap melayani pencarian intelijen!

Untuk menggunakan fitur ini, Anda memerlukan *API Key* resmi.

📖 *CARA MENGGUNAKAN OSINT:*
Kirim pesan dengan format:
\`search: <target> <apiKey>\`

*Contoh:*
\`search: jokowi ppp\`
_(jokowi = target pencarian, ppp = API Key Anda)_

🔍 *CEK SISA KUOTA API KEY:*
Ketik: \`api <apiKey>\`
*Contoh:* \`api ppp\`

💎 *TARIF HARGA API KEY (${pricing.currency}):*
${pricing.formatted}

${pricing.note}

🛒 *PEMBELIAN & TOP UP API KEY:*
Hubungi langsung Owner:
👤 *Owner Telegram:* @flood1233
_(Bebas mau chat ataupun call, asal tidak spam)_
━━━━━━━━━━━━━━━━━━━━━━━━━`;

    await sendTelegramMessage(chatId, onCard, {
      inline_keyboard: [
        [{ text: '💎 Cek Kuota API Key', callback_data: 'cmd_pricing' }],
        [{ text: '📞 Hubungi Owner @flood1233', url: 'https://t.me/flood1233' }],
        [{ text: '🏠 Kembali ke Menu Utama', callback_data: 'cmd_menu' }]
      ]
    });
    return;
  }

  // Command: /pricing, /harga, /tarif (PRICE & API KEY PROMOTION)
  if (['/pricing', '/harga', '/tarif'].includes(lowerText)) {
    botConfig.stats.commandsExecuted += 1;
    saveBotConfig();

    const priceCard = `💎 *DAFTAR HARGA & PROMOSI API KEY OSINT*
━━━━━━━━━━━━━━━━━━━━━━━━━
Mata Uang Terdeteksi: *${pricing.currency}*

${pricing.formatted}

${pricing.note}

💡 *Ketentuan & Keunggulan:*
• Pengerjaan query real-time langsung ke server intelijen
• Format pencarian: \`search: <target> <apiKey>\`
• Cek kuota kapan saja dengan: \`api <apiKey>\`

📞 *Pemesanan & Aktivasi API Key:*
👤 *Owner Telegram:* @flood1233
_(Bebas mau chat ataupun call, asal tidak spam)_
━━━━━━━━━━━━━━━━━━━━━━━━━`;

    await sendTelegramMessage(chatId, priceCard, {
      inline_keyboard: [
        [{ text: '📞 Hubungi Owner @flood1233', url: 'https://t.me/flood1233' }],
        [{ text: '🏠 Kembali ke Menu Utama', callback_data: 'cmd_menu' }]
      ]
    });
    return;
  }

  // Command: api <apiKey> (CHECK API KEY QUOTA & STATUS)
  if (lowerText === 'api' || lowerText.startsWith('api ') || lowerText === '/api' || lowerText.startsWith('/api ')) {
    botConfig.stats.commandsExecuted += 1;
    saveBotConfig();

    const parts = text.split(/\s+/);
    const queriedKey = parts[1];

    if (!queriedKey) {
      await sendTelegramMessage(
        chatId,
        `ℹ️ *Format Pengecekan API Key:*\n\nKetik: \`api <apiKey>\`\n*Contoh:* \`api ppp\`\n\nUntuk membeli API Key baru, hubungi Owner: @flood1233`,
        {
          inline_keyboard: [
            [{ text: '💎 Daftar Harga API Key', callback_data: 'cmd_pricing' }],
            [{ text: '📞 Hubungi Owner @flood1233', url: 'https://t.me/flood1233' }]
          ]
        }
      );
      return;
    }

    const foundKey = botConfig.osintConfig.apiKeys.find(
      (k) => k.key.toLowerCase() === queriedKey.toLowerCase()
    );

    if (!foundKey) {
      await sendTelegramMessage(
        chatId,
        `❌ *API KEY TIDAK DITEMUKAN*\n\nKey \`${queriedKey}\` tidak terdaftar di sistem server OSINT.\n\nPastikan penulisan key sudah benar, atau hubungi Owner untuk membuat/membeli API Key:\n👤 *Owner Telegram:* @flood1233`,
        {
          inline_keyboard: [
            [{ text: '💎 Lihat Harga API Key', callback_data: 'cmd_pricing' }],
            [{ text: '📞 Hubungi Owner @flood1233', url: 'https://t.me/flood1233' }]
          ]
        }
      );
      return;
    }

    const quotaInfo =
      foundKey.tier === 'unlimited'
        ? '♾️ *Unlimited (Akses Tanpa Batas Kuota)*'
        : `*${foundKey.remainingQuota}x* ${foundKey.bonusQuota > 0 ? `_(+ BONUS ${foundKey.bonusQuota}x)_` : ''}`;

    const keyCard = `🔑 *DETAIL & STATUS API KEY OSINT*
━━━━━━━━━━━━━━━━━━━━━━━━━
🔑 *API Key:* \`${foundKey.key}\`
🟢 *Status:* ${foundKey.enabled ? 'AKTIF' : 'NONAKTIF / DITANGGUHKAN'}
📊 *Paket:* ${foundKey.tier === 'unlimited' ? 'Unlimited VIP' : 'Limited Quota'}
📦 *Sisa Kuota:* ${quotaInfo}
📈 *Total Pemakaian:* ${foundKey.totalUsed}x
📝 *Catatan:* ${foundKey.ownerNotes || '-'}
🕒 *Terakhir Digunakan:* ${foundKey.lastUsedAt ? new Date(foundKey.lastUsedAt).toLocaleString('id-ID') : 'Belum pernah'}
━━━━━━━━━━━━━━━━━━━━━━━━━
💡 *Cara Pakai:* \`search: <target> ${foundKey.key}\`
*Contoh:* \`search: jokowi ${foundKey.key}\`

📞 *Top Up Kuota:* @flood1233`;

    await sendTelegramMessage(chatId, keyCard, {
      inline_keyboard: [
        [{ text: '🔍 Cara Pakai OSINT', callback_data: 'cmd_osint' }],
        [{ text: '📞 Hubungi Owner @flood1233', url: 'https://t.me/flood1233' }],
        [{ text: '🏠 Menu Utama', callback_data: 'cmd_menu' }]
      ]
    });
    return;
  }

  // Command: /history or /riwayat (ISOLATED PER CHAT ID)
  if (['/history', '/riwayat', 'history', 'riwayat'].includes(lowerText)) {
    botConfig.stats.commandsExecuted += 1;
    saveBotConfig();
    await handleUserHistoryCommand(Number(chatId), senderName);
    return;
  }

  // Command: search: <target> <apiKey>, /search, /cari, etc.
  const searchPrefixes = [
    'search:', '/search', 'osint:', 'cari:', '/cari', 'cek:', '/cek', 'track:', '/track'
  ];
  const isSearchCommand =
    searchPrefixes.some((p) => lowerText.startsWith(p)) ||
    lowerText.startsWith('search ') ||
    lowerText.startsWith('cari ') ||
    lowerText.startsWith('cek ') ||
    lowerText.startsWith('track ');

  if (isSearchCommand) {
    botConfig.stats.commandsExecuted += 1;
    saveBotConfig();

    // Parse target and apiKey
    let rawQuery = '';
    if (lowerText.startsWith('search:')) {
      rawQuery = text.substring(7).trim();
    } else if (lowerText.startsWith('/search')) {
      rawQuery = text.substring(7).trim();
    } else if (lowerText.startsWith('search ')) {
      rawQuery = text.substring(7).trim();
    } else if (lowerText.startsWith('osint:')) {
      rawQuery = text.substring(6).trim();
    } else if (lowerText.startsWith('cari:')) {
      rawQuery = text.substring(5).trim();
    } else if (lowerText.startsWith('/cari')) {
      rawQuery = text.substring(5).trim();
    } else if (lowerText.startsWith('cari ')) {
      rawQuery = text.substring(5).trim();
    } else if (lowerText.startsWith('cek:')) {
      rawQuery = text.substring(4).trim();
    } else if (lowerText.startsWith('/cek')) {
      rawQuery = text.substring(4).trim();
    } else if (lowerText.startsWith('cek ')) {
      rawQuery = text.substring(4).trim();
    } else if (lowerText.startsWith('track:')) {
      rawQuery = text.substring(6).trim();
    } else if (lowerText.startsWith('/track')) {
      rawQuery = text.substring(6).trim();
    } else if (lowerText.startsWith('track ')) {
      rawQuery = text.substring(6).trim();
    }

    if (rawQuery.startsWith(':')) {
      rawQuery = rawQuery.substring(1).trim();
    }

    const queryParts = rawQuery.split(/\s+/).filter(Boolean);

    if (queryParts.length === 0) {
      await sendTelegramMessage(
        chatId,
        `⚠️ *Format Perintah Kosong!*\n\n📖 *Cara Pakai:*\n• Menggunakan Kuota Pribadi: \`search: <target>\` atau \`/search <target>\`\n• Menggunakan API Key Khusus: \`search: <target> <apiKey>\`\n\n*Contoh:* \`search: jokowi\` atau \`cari: slamet\``,
        {
          inline_keyboard: [
            [{ text: '🎁 Klaim Kuota Gratis', callback_data: 'cmd_claim_menu' }],
            [{ text: '💎 Cek Sisa Kuota', callback_data: 'cmd_my_quota' }]
          ]
        }
      );
      return;
    }

    let target = '';
    let apiKey = '';

    // Check if the last part is explicitly a known API Key
    const lastToken = queryParts[queryParts.length - 1];
    const isLastTokenKey = botConfig.osintConfig.apiKeys.some(
      (k) => k.key.toLowerCase() === lastToken.toLowerCase()
    );

    const userPersonalKey = currentUser.personalApiKey || `usr_${currentUser.userId || chatId}`;

    if (queryParts.length >= 2 && isLastTokenKey) {
      apiKey = lastToken;
      target = queryParts.slice(0, queryParts.length - 1).join(' ');
    } else if (currentUser.personalQuota && currentUser.personalQuota > 0) {
      // User has personal quota, auto-use their personal API key!
      apiKey = userPersonalKey;
      target = queryParts.join(' ');
    } else {
      // User typed target without valid key and without remaining personal quota
      target = queryParts.join(' ');
      await sendTelegramMessage(
        chatId,
        `⚠️ *KUOTA PRIBADI ANDA: 0x PEMAKAIAN*\n\nAnda belum memiliki sisa kuota pribadi untuk mencari target: \`${target}\`.\n\n🎁 *Solusi Gratis:* Anda dapat mengklaim kuota gratis di menu klaim!\n• Pengguna Baru: *+${botConfig.quotaConfig?.newUserQuotaAmount || 5}x Kuota Gratis*\n• Kuota Harian: *+${botConfig.quotaConfig?.dailyQuotaAmount || 2}x Kuota Gratis per Hari*\n\nAtau gunakan API key khusus: \`search: ${target} <apiKey>\``,
        {
          inline_keyboard: [
            [{ text: '🎁 Ambil Kuota Gratis Sekarang', callback_data: 'cmd_claim_menu' }],
            [{ text: '💎 Daftar Harga & Top Up', callback_data: 'cmd_pricing' }],
            [{ text: '📞 Hubungi Owner @flood1233', url: 'https://t.me/flood1233' }]
          ]
        }
      );
      return;
    }

    const isUsingPersonalQuota =
      apiKey.toLowerCase() === userPersonalKey.toLowerCase() ||
      apiKey.startsWith('usr_');

    // 1. Check if OSINT external feature is required
    // NOTE: Personal quota users searching local dataset.txt are ALWAYS allowed without needing external server to be toggled ON!
    if (!isUsingPersonalQuota && !botConfig.osintConfig.enabled) {
      await sendTelegramMessage(
        chatId,
        `🔴 *SERVER DATA OSINT NONAKTIF (OFF)*\n━━━━━━━━━━━━━━━━━━━━━━━━━\n⚠️ Mohon maaf, Server Data OSINT saat ini *belum diaktifkan oleh Owner*.\n\nJika ingin menggunakan fitur ini, Anda harus menghubungi Owner Bot untuk mengaktifkan data OSINT nya:\n👤 *Owner Telegram:* @flood1233\n_(Bebas mau chat ataupun call, asal tidak spam)_`,
        {
          inline_keyboard: [
            [{ text: '📞 Hubungi Owner @flood1233', url: 'https://t.me/flood1233' }],
            [{ text: '🔄 Cek Status Server', callback_data: 'cmd_osint' }]
          ]
        }
      );
      return;
    }

    // 2. Validate API Key (Auto-sync personal user key if needed)
    let matchedKey = botConfig.osintConfig.apiKeys.find(
      (k) => k.key.toLowerCase() === apiKey.toLowerCase()
    );

    if (!matchedKey && isUsingPersonalQuota) {
      syncUserApiKey(currentUser);
      matchedKey = botConfig.osintConfig.apiKeys.find(
        (k) => k.key.toLowerCase() === apiKey.toLowerCase()
      );
    }

    if (!matchedKey || !matchedKey.enabled) {
      await sendTelegramMessage(
        chatId,
        `❌ *API KEY TIDAK VALID ATAU NONAKTIF*\n\nKey \`${apiKey}\` tidak dapat digunakan. Syarat menggunakan OSINT harus memiliki API Key resmi dari Owner.\n\n📞 Hubungi Owner untuk membeli atau meminta API Key:\n👤 *Owner Telegram:* @flood1233`,
        {
          inline_keyboard: [
            [{ text: '💎 Daftar Harga API Key', callback_data: 'cmd_pricing' }],
            [{ text: '📞 Hubungi Owner @flood1233', url: 'https://t.me/flood1233' }]
          ]
        }
      );
      return;
    }

    // 3. Check remaining quota
    const totalRemaining = matchedKey.remainingQuota + matchedKey.bonusQuota;
    if (matchedKey.tier === 'limited' && totalRemaining <= 0) {
      await sendTelegramMessage(
        chatId,
        `⚠️ *KUOTA API KEY TELAH HABIS (0x)*\n\nAPI Key \`${apiKey}\` sudah habis terpakai (${matchedKey.totalUsed}x pemakaian).\n\nSilakan hubungi Owner untuk top up kuota atau klaim kuota gratis:\n👤 *Owner Telegram:* @flood1233`,
        {
          inline_keyboard: [
            [{ text: '🎁 Klaim Kuota Gratis', callback_data: 'cmd_claim_menu' }],
            [{ text: '💎 Top Up Kuota API Key', callback_data: 'cmd_pricing' }],
            [{ text: '📞 Hubungi Owner @flood1233', url: 'https://t.me/flood1233' }]
          ]
        }
      );
      return;
    }

    // 4. Send typing indicator in header (Never spam 2x messages in 1 command)
    await sendTelegramChatAction(chatId, 'typing');

    // 5. Query Sanitization, Normalization, Spike Detection & Hot Caching
    const norm = sanitizeAndNormalizeQuery(target);
    if (!norm.isValid) {
      await sendTelegramMessage(chatId, `⚠️ *Pencarian Ditolak:* ${norm.reason}`);
      return;
    }
    const cleanTarget = norm.clean;
    recordSearchAndDetectSpike(chatId, senderName, cleanTarget);

    const engineMode = botConfig.osintConfig.searchEngineMode || 'smart_dataset';
    let localResult: any = null;

    const cacheKey = cleanTarget.toLowerCase();
    const cached = hotSearchCache.get(cacheKey);
    if (cached && Date.now() - cached.cachedAt < SEARCH_CACHE_TTL_MS) {
      localResult = cached.result;
    } else if (engineMode !== 'ngrok_only') {
      try {
        localResult = await smartSearchDatasets(cleanTarget, 500);
        if (localResult) {
          hotSearchCache.set(cacheKey, { result: localResult, cachedAt: Date.now() });
          if (hotSearchCache.size > 250) {
            const firstK = hotSearchCache.keys().next().value;
            if (firstK) hotSearchCache.delete(firstK);
          }
        }
      } catch (e: any) {
        addLog('error', `Error scanning local datasets: ${e.message}`, chatId);
      }
    }

    if (localResult && localResult.totalMatches > 0) {
      // Data found directly in dataset.txt or uploaded dataset files!
      const cost = botConfig.quotaConfig?.quotaCostPerSearch || 1;
      if (matchedKey.tier === 'limited') {
        if (matchedKey.remainingQuota >= cost) {
          matchedKey.remainingQuota -= cost;
        } else if (matchedKey.remainingQuota > 0) {
          matchedKey.remainingQuota = 0;
        } else if (matchedKey.bonusQuota > 0) {
          matchedKey.bonusQuota = Math.max(0, matchedKey.bonusQuota - cost);
        }
      }
      matchedKey.totalUsed += 1;
      matchedKey.lastUsedAt = new Date().toISOString();
      if (
        (currentUser.personalApiKey && matchedKey.key.toLowerCase() === currentUser.personalApiKey.toLowerCase()) ||
        matchedKey.key.toLowerCase() === `usr_${currentUser.userId}`.toLowerCase() ||
        matchedKey.key.toLowerCase() === `usr_${currentUser.chatId}`.toLowerCase() ||
        isUsingPersonalQuota
      ) {
        currentUser.personalQuota = matchedKey.remainingQuota;
        const targetUser = botConfig.activeUsers.find(
          (u) => (u.userId && Number(u.userId) === Number(currentUser.userId)) || Number(u.chatId) === Number(currentUser.userId)
        );
        if (targetUser) {
          targetUser.personalQuota = matchedKey.remainingQuota;
        }
      }
      botConfig.stats.osintSearchesCount = (botConfig.stats.osintSearchesCount || 0) + 1;
      saveBotConfig();

      const newRemaining =
        matchedKey.tier === 'unlimited'
          ? '♾️ Unlimited'
          : `${matchedKey.remainingQuota}x ${matchedKey.bonusQuota > 0 ? `(+${matchedKey.bonusQuota} bonus)` : ''}`;

      const totalMatches = localResult.totalMatches;
      const searchId = `srch_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;

      if (!Array.isArray(botConfig.searchHistories)) {
        botConfig.searchHistories = [];
      }
      const historyItem: OsintSearchHistoryItem = {
        id: searchId,
        chatId: Number(chatId),
        userName: senderName,
        usernameTag: usernameTag,
        target,
        apiKey,
        totalMatches,
        timestamp: new Date().toISOString(),
        formattedWib: wibTime.fullStr,
        rawResult: localResult.rawTextOutput
      };
      botConfig.searchHistories.unshift(historyItem);
      if (botConfig.searchHistories.length > 300) {
        botConfig.searchHistories = botConfig.searchHistories.slice(0, 300);
      }
      saveSearchItemToDisk(historyItem);
      saveBotConfig();

      addLog(
        'outgoing',
        `Hasil OSINT dataset ditemukan (${totalMatches} data) untuk ${senderName} (Chat: ${chatId}) dalam ${localResult.searchDurationMs}ms`,
        chatId
      );

      const { messageText, replyMarkup } = formatOsintPresentation(
        target,
        apiKey,
        totalMatches,
        newRemaining,
        wibTime,
        localResult.rawTextOutput,
        searchId
      );

      await sendTelegramMessage(chatId, messageText, replyMarkup);
      return;
    }

    // If local dataset has 0 matches:
    // Check if user has configured Ngrok fallback mode (hybrid or ngrok_only)
    if ((engineMode === 'hybrid' || engineMode === 'ngrok_only') && botConfig.osintConfig.ngrokUrl && !botConfig.osintConfig.ngrokUrl.includes('xxxx')) {
      const ngrokBase = botConfig.osintConfig.ngrokUrl.replace(/\/$/, '');
      const searchUrl = `${ngrokBase}/api/v1/search?q=${encodeURIComponent(target)}&apiKey=${encodeURIComponent(apiKey)}&key=${encodeURIComponent(apiKey)}`;

      try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 15000);

        const osintRes = await fetch(searchUrl, {
          method: 'GET',
          headers: {
            'Accept': 'application/json, text/plain, */*',
            'User-Agent': 'TelegramBot-OSINT-Client/2.0',
            'ngrok-skip-browser-warning': 'true',
            'X-API-Key': apiKey,
            'Authorization': `Bearer ${apiKey}`
          },
          signal: controller.signal
        });

        clearTimeout(timeoutId);

        if (osintRes.ok) {
          const cost = botConfig.quotaConfig?.quotaCostPerSearch || 1;
          if (matchedKey.tier === 'limited') {
            if (matchedKey.remainingQuota >= cost) {
              matchedKey.remainingQuota -= cost;
            } else if (matchedKey.remainingQuota > 0) {
              matchedKey.remainingQuota = 0;
            } else if (matchedKey.bonusQuota > 0) {
              matchedKey.bonusQuota = Math.max(0, matchedKey.bonusQuota - cost);
            }
          }
          matchedKey.totalUsed += 1;
          matchedKey.lastUsedAt = new Date().toISOString();
          if (
            (currentUser.personalApiKey && matchedKey.key.toLowerCase() === currentUser.personalApiKey.toLowerCase()) ||
            matchedKey.key.toLowerCase() === `usr_${currentUser.userId}`.toLowerCase() ||
            matchedKey.key.toLowerCase() === `usr_${currentUser.chatId}`.toLowerCase() ||
            isUsingPersonalQuota
          ) {
            currentUser.personalQuota = matchedKey.remainingQuota;
            const targetUser = botConfig.activeUsers.find(
              (u) => (u.userId && Number(u.userId) === Number(currentUser.userId)) || Number(u.chatId) === Number(currentUser.userId)
            );
            if (targetUser) {
              targetUser.personalQuota = matchedKey.remainingQuota;
            }
          }
          botConfig.stats.osintSearchesCount = (botConfig.stats.osintSearchesCount || 0) + 1;
          saveBotConfig();

          const newRemaining =
            matchedKey.tier === 'unlimited'
              ? '♾️ Unlimited'
              : `${matchedKey.remainingQuota}x ${matchedKey.bonusQuota > 0 ? `(+${matchedKey.bonusQuota} bonus)` : ''}`;

          const contentType = osintRes.headers.get('content-type') || '';
          let resultText = '';
          let jsonData: any = null;

          if (contentType.includes('application/json')) {
            jsonData = await osintRes.json();
            resultText = typeof jsonData === 'string' ? jsonData : JSON.stringify(jsonData, null, 2);
          } else {
            resultText = await osintRes.text();
          }

          let totalMatches = 0;
          try {
            const parsedObj = typeof jsonData === 'object' && jsonData !== null ? jsonData : JSON.parse(resultText);
            if (typeof parsedObj.totalMatches === 'number') {
              totalMatches = parsedObj.totalMatches;
            } else if (Array.isArray(parsedObj.results)) {
              totalMatches = parsedObj.results.length;
            } else if (Array.isArray(parsedObj)) {
              totalMatches = parsedObj.length;
            } else if (typeof parsedObj.count === 'number') {
              totalMatches = parsedObj.count;
            } else if (parsedObj && Object.keys(parsedObj).length > 0) {
              totalMatches = 1;
            }
          } catch {
            const lines = resultText.split('\n').filter((l) => l.trim().length > 0);
            totalMatches = lines.length > 0 ? lines.length : 1;
          }

          const searchId = `srch_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;

          if (!Array.isArray(botConfig.searchHistories)) {
            botConfig.searchHistories = [];
          }
          const historyItem: OsintSearchHistoryItem = {
            id: searchId,
            chatId: Number(chatId),
            userName: senderName,
            usernameTag: usernameTag,
            target,
            apiKey,
            totalMatches,
            timestamp: new Date().toISOString(),
            formattedWib: wibTime.fullStr,
            rawResult: resultText
          };
          botConfig.searchHistories.unshift(historyItem);
          if (botConfig.searchHistories.length > 300) {
            botConfig.searchHistories = botConfig.searchHistories.slice(0, 300);
          }
          saveSearchItemToDisk(historyItem);
          saveBotConfig();

          const { messageText, replyMarkup } = formatOsintPresentation(
            target,
            apiKey,
            totalMatches,
            newRemaining,
            wibTime,
            resultText,
            searchId
          );

          await sendTelegramMessage(chatId, messageText, replyMarkup);
          return;
        } else {
          // Server returned error (e.g. 403)
          const errText = await osintRes.text().catch(() => '');
          let cleanExplanation = '';
          try {
            const errJson = JSON.parse(errText);
            cleanExplanation = errJson.message || errJson.error || '';
          } catch {
            cleanExplanation = errText.replace(/<[^>]*>?/gm, '').trim();
          }

          if (!cleanExplanation) {
            cleanExplanation =
              osintRes.status === 403
                ? `API Key '${apiKey}' belum terdaftar di backend server.`
                : `Server backend merespon HTTP ${osintRes.status}.`;
          }

          const currentRemaining =
            matchedKey.tier === 'unlimited'
              ? '♾️ Unlimited'
              : `${matchedKey.remainingQuota}x ${matchedKey.bonusQuota > 0 ? `(+${matchedKey.bonusQuota} bonus)` : ''}`;

          const failureCard =
            engineMode === 'ngrok_only'
              ? `ℹ️ *SERVER NGROK MERESPON ${osintRes.status}*
━━━━━━━━━━━━━━━━━━━━━━━━━
🎯 *Target:* \`${target}\`
🔑 *API Key:* \`${apiKey}\`
🌐 *Server Ngrok:* ${cleanExplanation}
━━━━━━━━━━━━━━━━━━━━━━━━━
🛡️ *Status Kuota:* Kuota Anda *TIDAK DIPOTONG* (Sisa: *${currentRemaining}*).
💡 *Solusi:* Pastikan format query dan API key di backend Ngrok telah sesuai, atau gunakan mode *File Dataset (dataset.txt)* di Panel untuk pencarian instan lokal.`
              : `ℹ️ *TIDAK DITEMUKAN DI DATASET & SERVER MERESPON ${osintRes.status}*
━━━━━━━━━━━━━━━━━━━━━━━━━
🎯 *Target:* \`${target}\`
🔑 *API Key:* \`${apiKey}\`
📁 *Dataset Lokal:* Tidak ditemukan data di dataset.txt
🌐 *Server Ngrok:* ${cleanExplanation}
━━━━━━━━━━━━━━━━━━━━━━━━━
🛡️ *Status Kuota:* Kuota Anda *TIDAK DIPOTONG* (Sisa: *${currentRemaining}*).
💡 *Solusi:* Anda bisa mengunggah file dataset berisi target ini via Web Dashboard pada tab *File Dataset (dataset.txt)* agar dapat langsung dicari tanpa server eksternal!`;

          addLog('error', `OSINT Search (${engineMode}): HTTP ${osintRes.status}: ${cleanExplanation}`, chatId);
          await sendTelegramMessage(chatId, failureCard);
          return;
        }
      } catch (fetchErr: any) {
        addLog('error', `Koneksi Ngrok gagal (${engineMode}): ${fetchErr.message}`);
        if (engineMode === 'ngrok_only') {
          const currentRemaining =
            matchedKey.tier === 'unlimited'
              ? '♾️ Unlimited'
              : `${matchedKey.remainingQuota}x ${matchedKey.bonusQuota > 0 ? `(+${matchedKey.bonusQuota} bonus)` : ''}`;
          await sendTelegramMessage(
            chatId,
            `❌ *SERVER NGROK TIDAK DAPAT DIAKSES*\n\n🎯 *Target:* \`${target}\`\n🌐 *URL Ngrok:* \`${botConfig.osintConfig.ngrokUrl}\`\n⚠️ *Keterangan:* ${fetchErr.message || 'Koneksi timeout/offline'}\n\n🛡️ Kuota Anda *TIDAK DIPOTONG* (Sisa: *${currentRemaining}*).\n💡 *Solusi:* Pastikan tunnel Ngrok aktif, atau ubah mode ke *File Dataset (dataset.txt)* di Panel agar pencarian langsung dari arsip lokal tanpa server eksternal!`
          );
          return;
        }
      }
    }

    // Default: Smart Dataset Mode (Target not found in dataset.txt or any dataset files)
    const currentRemaining =
      matchedKey.tier === 'unlimited'
        ? '♾️ Unlimited'
        : `${matchedKey.remainingQuota}x ${matchedKey.bonusQuota > 0 ? `(+${matchedKey.bonusQuota} bonus)` : ''}`;

    const notFoundCard = `ℹ️ *DATA TIDAK DITEMUKAN*
━━━━━━━━━━━━━━━━━━━━━━━━━
🎯 *Target:* \`${target}\`
🔑 *API Key:* \`${apiKey}\`
📁 *Sumber Data:* \`dataset.txt\` & Arsip Dataset Pintar
━━━━━━━━━━━━━━━━━━━━━━━━━
Sistem pintar telah memindai seluruh file dataset aktif (\`dataset.txt\`), namun data untuk target \`${target}\` tidak ditemukan.

🛡️ *Status Kuota:*
Kuota Anda *TIDAK DIPOTONG* (Sisa kuota: *${currentRemaining}*).

💡 *Tips:*
Anda dapat menambahkan atau mengunggah data baru kapan saja melalui *Web Controller* di tab *File Dataset (dataset.txt)*. Data yang diunggah akan langsung bisa dicari secara otomatis!`;

    addLog('system', `Pencarian target "${target}" selesai (0 match di dataset lokal). Kuota tidak dipotong.`, chatId);
    await sendTelegramMessage(chatId, notFoundCard, {
      inline_keyboard: [
        [{ text: '💎 Cek Sisa Kuota', callback_data: `api_${apiKey}` }],
        [{ text: '🏠 Menu Utama', callback_data: 'cmd_menu' }]
      ]
    });
    return;
  }

  // Command: /owner, /kontak, /admin
  if (['/owner', '/kontak', '/admin'].includes(lowerText)) {
    botConfig.stats.commandsExecuted += 1;
    saveBotConfig();

    const ownerCard = `📞 *KONTAK RESMI OWNER & ADMIN BOT*
━━━━━━━━━━━━━━━━━━━━━━━━━
👤 *Username Telegram:* @flood1233
💬 *Layanan Resmi:*
• Mengaktifkan / Menyalakan Server Data OSINT
• Pembelian & Top Up Kuota API Key
• Paket Hemat & Paket Unlimited Tanpa Batas
• Bantuan Teknis Bot Telegram

💡 _Bebas mau dengan chat ataupun call, asal tidak spam!_
━━━━━━━━━━━━━━━━━━━━━━━━━`;

    await sendTelegramMessage(chatId, ownerCard, {
      inline_keyboard: [
        [{ text: '📞 Buka Chat Owner @flood1233', url: 'https://t.me/flood1233' }],
        [{ text: '💎 Daftar Harga API Key', callback_data: 'cmd_pricing' }],
        [{ text: '🏠 Menu Utama', callback_data: 'cmd_menu' }]
      ]
    });
    return;
  }

  // Command: /bot, /detail, /info, /about (DETAIL BOT)
  if (['/bot', '/detail', '/info', '/about'].includes(lowerText)) {
    botConfig.stats.commandsExecuted += 1;
    saveBotConfig();

    const uptimeSec = botStartedAt ? Math.floor((Date.now() - botStartedAt) / 1000) : 0;
    const botInfo = currentBotInfo;

    const botCard = `🤖 *DETAIL & SPESIFIKASI RESMI AXXOSINTBOT*
━━━━━━━━━━━━━━━━━━━━━━━━━
📛 *Nama Bot:* ${botInfo?.first_name || 'axxosintbot'}
🏷 *Username:* @${botInfo?.username || 'axxosintbot'}
👑 *Developer / Creator:* Ax. (@flood1233)
🔢 *Bot ID:* \`${botInfo?.id || 'N/A'}\`
🟢 *Status Server:* AKTIF (Always-ON Service)
⏱ *Durasi Uptime:* ${formatUptime(uptimeSec)}
🔍 *Status OSINT:* ${botConfig.osintConfig.enabled ? '🟢 AKTIF (ON)' : '🔴 NONAKTIF (OFF)'}
👥 *Izin Masuk Grup:* ${botInfo?.can_join_groups ? '✅ Ya' : '❌ Tidak'}
⚡ *Engine:* axxosintbot Core Engine v3.0 (Created by Ax.)
📊 *Total Pesan Masuk:* ${botConfig.stats.messagesReceived}
📤 *Total Pesan Terkirim:* ${botConfig.stats.messagesSent}
🔍 *Total Pencarian OSINT:* ${botConfig.stats.osintSearchesCount || 0}
━━━━━━━━━━━━━━━━━━━━━━━━━
🌐 _axxosintbot diciptakan oleh Ax. Dikelola langsung melalui Web Controller Dashboard._`;

    await sendTelegramMessage(chatId, botCard, {
      inline_keyboard: [
        [{ text: '🆔 Cek ID Saya', callback_data: 'cmd_id' }],
        [{ text: '🏠 Kembali ke Menu', callback_data: 'cmd_menu' }]
      ]
    });
    return;
  }

  // Command: /ping
  if (lowerText === '/ping') {
    botConfig.stats.commandsExecuted += 1;
    saveBotConfig();
    const uptimeSec = botStartedAt ? Math.floor((Date.now() - botStartedAt) / 1000) : 0;

    const pingText = `🏓 *PONG! BOT ONLINE & RESPONSIF*
━━━━━━━━━━━━━━━━━━━━━━━━━
⚡ *Kecepatan:* Normal (~30ms)
🟢 *Mode:* Always ON (Aktif terus selama tombol off belum dimatikan)
⏱ *Uptime:* ${formatUptime(uptimeSec)}
🕒 *Jam Server:* ${wibTime.timeStr}
🔍 *Server OSINT:* ${botConfig.osintConfig.enabled ? '🟢 ON' : '🔴 OFF'}
━━━━━━━━━━━━━━━━━━━━━━━━━`;

    await sendTelegramMessage(chatId, pingText);
    return;
  }

  // Command: /waktu or /time
  if (lowerText === '/waktu' || lowerText === '/time') {
    botConfig.stats.commandsExecuted += 1;
    saveBotConfig();

    const now = new Date();
    const wibStr = new Intl.DateTimeFormat('id-ID', { timeZone: 'Asia/Jakarta', timeStyle: 'medium', dateStyle: 'full' }).format(now);
    const witaStr = new Intl.DateTimeFormat('id-ID', { timeZone: 'Asia/Makassar', timeStyle: 'medium' }).format(now);
    const witStr = new Intl.DateTimeFormat('id-ID', { timeZone: 'Asia/Jayapura', timeStyle: 'medium' }).format(now);

    const timeText = `⏰ *INFORMASI WAKTU REAL-TIME*
━━━━━━━━━━━━━━━━━━━━━━━━━
🇮🇩 *Zona Waktu Indonesia:*
• *WIB (Jakarta):* ${wibStr} WIB
• *WITA (Bali/Makassar):* ${witaStr} WITA
• *WIT (Jayapura):* ${witStr} WIT
━━━━━━━━━━━━━━━━━━━━━━━━━`;

    await sendTelegramMessage(chatId, timeText);
    return;
  }

  // Command: /help or /bantuan
  if (lowerText === '/help' || lowerText === '/bantuan') {
    botConfig.stats.commandsExecuted += 1;
    saveBotConfig();

    let customCmdList = '';
    if (botConfig.customCommands && botConfig.customCommands.length > 0) {
      const activeCustom = botConfig.customCommands.filter((c) => c.enabled);
      if (activeCustom.length > 0) {
        customCmdList = '\n\n*Perintah Kustom Web:*\n' + activeCustom.map((c) => `• /${c.command} - ${c.description}`).join('\n');
      }
    }

    const helpText = `📖 *PANDUAN & DAFTAR PERINTAH BOT*
━━━━━━━━━━━━━━━━━━━━━━━━━
*Perintah Utama:*
• /start atau /menu - Membuka menu interaktif
• /id - Cek Chat ID & status verifikasi akun
• /osint - Cek status & petunjuk intelijen OSINT
• /harga - Daftar harga & promo kuota API Key
• api <apiKey> - Cek sisa kuota API Key (Contoh: api ppp)
• search: <target> <key> - Cari data intelijen OSINT
• /bot - Detail lengkap spesifikasi bot
• /ping - Tes latency & status respon bot
• /waktu - Jam real-time WIB/WITA/WIT
• /owner - Hubungi owner resmi (@flood1233)
• /calc <rumus> - Kalkulator cepat (contoh: /calc 5000*3+250)
• /echo <teks> - Mengulang pesan yang dikirim${customCmdList}

💡 _Semua fitur aktif otomatis selama bot ON di Web Dashboard._`;

    await sendTelegramMessage(chatId, helpText, getMainInlineMenu(botConfig.osintConfig.enabled));
    return;
  }

  // Command: /echo <teks>
  if (lowerText.startsWith('/echo ')) {
    botConfig.stats.commandsExecuted += 1;
    saveBotConfig();
    const echoContent = text.substring(6).trim();
    await sendTelegramMessage(chatId, `📢 *Gema Pesan (Echo):*\n\n${echoContent}`);
    return;
  }

  // Command: /calc <expression>
  if (lowerText.startsWith('/calc ')) {
    botConfig.stats.commandsExecuted += 1;
    saveBotConfig();
    const expr = text.substring(6).trim();
    try {
      if (/^[0-9+\-*/().\s^%]+$/.test(expr)) {
        // Safe evaluation
        // eslint-disable-next-line no-new-func
        const result = Function(`'use strict'; return (${expr})`)();
        await sendTelegramMessage(chatId, `🧮 *Hasil Perhitungan:*\n\`${expr}\` = *${result}*`);
      } else {
        await sendTelegramMessage(chatId, '⚠️ Rumus hanya boleh berisi angka dan operator (+, -, *, /, %).');
      }
    } catch {
      await sendTelegramMessage(chatId, '❌ Format perhitungan salah. Contoh: `/calc 1500 * 3 + 250`');
    }
    return;
  }

  // Check Custom Commands
  if (text.startsWith('/')) {
    const cmdName = text.substring(1).split(' ')[0].toLowerCase();
    const customMatch = botConfig.customCommands.find(
      (c) => c.enabled && c.command.toLowerCase() === cmdName
    );
    if (customMatch) {
      botConfig.stats.commandsExecuted += 1;
      saveBotConfig();
      await sendTelegramMessage(chatId, customMatch.replyText);
      return;
    }
  }

  // Check Keyword Auto-Replies
  for (const rule of botConfig.autoReplies) {
    if (!rule.enabled) continue;
    const trigger = rule.triggerKeyword.toLowerCase().trim();
    let isMatch = false;

    if (rule.matchType === 'exact') {
      isMatch = lowerText === trigger;
    } else {
      isMatch = lowerText.includes(trigger);
    }

    if (isMatch) {
      await sendTelegramMessage(chatId, rule.replyText);
      return;
    }
  }

  // SILENT FALLBACK IN GROUPS (Prevents bot spamming on casual member messages!)
  if (isGroup) {
    if (isExplicitMention) {
      await sendTelegramMessage(
        chatId,
        `👋 Halo *${senderName}*! Saya Bot Intelligence siap digunakan di grup ini.\n\n` +
        `Gunakan perintah resmi:\n` +
        `• /menu - Menu Interaktif\n` +
        `• /id - Cek Chat ID Grup & Profil\n` +
        `• /osint - Status Server Intelijen\n` +
        `• \`search: <target> <apiKey>\` - Cari Data Intelijen\n` +
        `• /ping - Tes Kecepatan Bot`
      );
    }
    // Silent in group: Do NOT send default reply on ordinary member conversations!
    return;
  }

  // Intelligent Direct Query Search (Private chat auto-detection)
  const looksLikeQuery =
    !isGroup &&
    rawText.length >= 3 &&
    rawText.length <= 60 &&
    !rawText.includes('\n') &&
    !rawText.startsWith('/') &&
    currentUser.personalQuota &&
    currentUser.personalQuota > 0;

  if (looksLikeQuery) {
    botConfig.stats.commandsExecuted += 1;
    saveBotConfig();
    const norm = sanitizeAndNormalizeQuery(rawText);
    if (!norm.isValid) {
      await sendTelegramMessage(chatId, `⚠️ *Pencarian Ditolak:* ${norm.reason}`);
      return;
    }
    const queryTarget = norm.clean;
    recordSearchAndDetectSpike(chatId, senderName, queryTarget);

    const cost = botConfig.quotaConfig?.quotaCostPerSearch || 1;

    // Send typing indicator so Telegram displays "typing..." in header without sending duplicate message
    await sendTelegramChatAction(chatId, 'typing');

    let localResult: any = null;
    const cacheKey = queryTarget.toLowerCase();
    const cached = hotSearchCache.get(cacheKey);
    if (cached && Date.now() - cached.cachedAt < SEARCH_CACHE_TTL_MS) {
      localResult = cached.result;
    } else {
      try {
        localResult = await smartSearchDatasets(queryTarget, 500);
        if (localResult) {
          hotSearchCache.set(cacheKey, { result: localResult, cachedAt: Date.now() });
          if (hotSearchCache.size > 250) {
            const firstK = hotSearchCache.keys().next().value;
            if (firstK) hotSearchCache.delete(firstK);
          }
        }
      } catch (e: any) {
        addLog('error', `Error scanning local datasets: ${e.message}`, chatId);
      }
    }

    if (localResult && localResult.totalMatches > 0) {
      currentUser.personalQuota = Math.max(0, currentUser.personalQuota - cost);
      syncUserApiKey(currentUser);
      botConfig.stats.osintSearchesCount = (botConfig.stats.osintSearchesCount || 0) + 1;
      saveBotConfig();

      const newRemaining = `${currentUser.personalQuota}x`;
      const totalMatches = localResult.totalMatches;
      const searchId = `srch_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;

      if (!Array.isArray(botConfig.searchHistories)) {
        botConfig.searchHistories = [];
      }
      const historyItem: OsintSearchHistoryItem = {
        id: searchId,
        chatId: Number(chatId),
        userName: senderName,
        usernameTag: usernameTag,
        target: queryTarget,
        apiKey: currentUser.personalApiKey || `usr_${from.id}`,
        totalMatches,
        timestamp: new Date().toISOString(),
        formattedWib: wibTime.fullStr,
        rawResult: localResult.rawTextOutput
      };
      botConfig.searchHistories.unshift(historyItem);
      if (botConfig.searchHistories.length > 300) {
        botConfig.searchHistories = botConfig.searchHistories.slice(0, 300);
      }
      saveSearchItemToDisk(historyItem);
      saveBotConfig();

      const { messageText, replyMarkup } = formatOsintPresentation(
        queryTarget,
        currentUser.personalApiKey || `usr_${from.id}`,
        totalMatches,
        newRemaining,
        wibTime,
        localResult.rawTextOutput,
        searchId
      );

      await sendTelegramMessage(chatId, messageText, replyMarkup);
      return;
    } else {
      const notFoundCard = `ℹ️ *DATA TIDAK DITEMUKAN*
━━━━━━━━━━━━━━━━━━━━━━━━━
🎯 *Target:* \`${queryTarget}\`
📁 *Sumber Data:* \`dataset.txt\` & Arsip Dataset Pintar
━━━━━━━━━━━━━━━━━━━━━━━━━
Sistem telah memindai seluruh file dataset aktif, namun data untuk target \`${queryTarget}\` belum ditemukan.

🛡️ *Status Kuota:*
Kuota Anda *TIDAK DIPOTONG* (Sisa kuota: *${currentUser.personalQuota}x*).

💡 *Format Pencarian Resmi:*
\`search: <target>\` atau \`/search <target>\``;

      await sendTelegramMessage(chatId, notFoundCard, {
        inline_keyboard: [
          [{ text: '💎 Cek Saldo Kuota', callback_data: 'cmd_my_quota' }],
          [{ text: '🏠 Menu Utama', callback_data: 'cmd_menu' }]
        ]
      });
      return;
    }
  }

  // Default fallback response for private chat only
  const defaultReply = `Halo *${senderName}*! Pesan kamu telah diterima oleh server bot.
Ketik /id untuk melihat Chat ID, ketik /osint untuk fitur intelijen, atau ketik /menu untuk membuka menu lengkap.`;

  await sendTelegramMessage(chatId, defaultReply, getMainInlineMenu(botConfig.osintConfig.enabled));
}

// Safely answer Telegram callback query to clear button spinner, with graceful error/abort handling
async function safeAnswerCallbackQuery(callbackQueryId: string, text?: string, showAlert = false, timeoutMs = 8000) {
  if (!botConfig.token || !callbackQueryId) return;
  try {
    const payload: Record<string, any> = { callback_query_id: callbackQueryId };
    if (text) {
      payload.text = text;
      payload.show_alert = showAlert;
    }
    await callTelegramApi(botConfig.token, 'answerCallbackQuery', payload, timeoutMs);
  } catch (_err: any) {
    // Gracefully handle aborts, network timeouts, or expired query errors
    // Telegram callback queries expire after a few seconds or when network is congested.
    // Suppress console.error since this is a non-fatal, background acknowledgement.
  }
}

// Handle Telegram Callback Query (Inline Button Click)
async function handleCallbackQuery(cbQuery: any) {
  if (!cbQuery || !cbQuery.message) return;

  const data = cbQuery.data;
  const message = cbQuery.message;
  const chatId = message.chat.id;
  const from = cbQuery.from;
  const senderName = [from.first_name, from.last_name].filter(Boolean).join(' ') || from.username || 'Pengguna';
  const usernameTag = from.username ? `@${from.username}` : '-';

  addLog('callback', `Tombol ditekan: "${data}"`, chatId, `${senderName} (${usernameTag})`);

  // Anti-Spam debounce on callback queries (1.2s cooldown per user)
  const cbKey = `cb_${from.id}`;
  const nowCb = Date.now();
  const lastCb = lastUserActionTimestamp.get(cbKey) || 0;
  if (nowCb - lastCb < 1200) {
    safeAnswerCallbackQuery(cbQuery.id, '⏳ Mohon tunggu sebentar...', false, 4000);
    return;
  }
  lastUserActionTimestamp.set(cbKey, nowCb);

  // Acknowledge the callback query immediately to clear Telegram's loading spinner without blocking
  safeAnswerCallbackQuery(cbQuery.id);

  const wibTime = getFormattedWIB();
  const pricing = getPricingData(from.language_code);

  // Verification button handler (Anti-re-registration)
  if (data === 'verify_id') {
    const user = botConfig.activeUsers.find((u) => Number(u.chatId) === Number(chatId));
    if (user && user.isVerified) {
      // User is already verified! Never re-verify or reset
      const alreadyVerifiedCard = `ℹ️ *AKUN ANDA SUDAH TERVERIFIKASI RESMI!*
━━━━━━━━━━━━━━━━━━━━━━━━━
Halo, *${senderName}*! Akun Anda sebelumnya telah terverifikasi di sistem kami sejak:
🕒 *${formatWibDate(user.verifiedAt || user.firstSeen)}*

🆔 *Chat ID:* \`${chatId}\`
💎 *Sisa Kuota Pribadi:* *${user.personalQuota || 0}x Pencarian*
🔑 *API Key Pribadi:* \`${user.personalApiKey || `usr_${chatId}`}\`

💡 _Status akun Anda tetap aman dan tidak pernah direset. Anda dapat langsung menggunakan semua fitur bot atau mengklaim kuota gratis di bawah._`;

      await sendTelegramMessage(chatId, alreadyVerifiedCard, {
        inline_keyboard: [
          [{ text: '🎁 Menu Klaim Kuota', callback_data: 'cmd_claim_menu' }],
          [{ text: '💎 Cek Kuota Saya', callback_data: 'cmd_my_quota' }],
          [{ text: '🏠 Buka Menu Utama', callback_data: 'cmd_menu' }]
        ]
      });
      return;
    }

    if (user) {
      user.isVerified = true;
      user.verifiedAt = new Date().toISOString();
      syncUserApiKey(user);
      saveBotConfig();
    }

    const verifiedCard = `✅ *AKUN BERHASIL TERVERIFIKASI RESMI!*
━━━━━━━━━━━━━━━━━━━━━━━━━
Terima kasih, *${senderName}*! Akun Telegram Anda telah terverifikasi secara resmi.

🆔 *Chat ID:* \`${chatId}\`
👤 *Nama Lengkap:* ${senderName}
🏷 *Username:* ${usernameTag}
🕒 *Waktu Verifikasi:* ${wibTime.fullStr}
━━━━━━━━━━━━━━━━━━━━━━━━━
🎁 *HADIAH SAMBUTAN PENGGUNA BARU:*
Sebagai pengguna terverifikasi, Anda berhak mengklaim *+5x Kuota Pencarian OSINT Gratis* (1x seumur hidup)!

👉 *Klik tombol di bawah untuk mengambil kuota gratis Anda:*`;

    await sendTelegramMessage(chatId, verifiedCard, {
      inline_keyboard: [
        [{ text: '🎁 Ambil Kuota Pengguna Baru (+5x)', callback_data: 'claim_new_user' }],
        [{ text: '🏠 Buka Menu Utama', callback_data: 'cmd_menu' }]
      ]
    });
    return;
  }

  // Claim Quota Dashboard Callback
  if (data === 'cmd_claim_menu') {
    await sendClaimQuotaDashboard(from.id, chatId, senderName);
    return;
  }

  // My Quota & Profile Callback
  if (data === 'cmd_my_quota') {
    await sendUserQuotaStatus(from.id, chatId, senderName);
    return;
  }

  // Claim New User Quota Action Callback
  if (data === 'claim_new_user') {
    await handleClaimNewUserQuota(from.id, chatId, senderName);
    return;
  }

  // Claim Daily Quota Action Callback
  if (data === 'claim_daily') {
    await handleClaimDailyQuota(from.id, chatId, senderName);
    return;
  }

  // OSINT Menu Callback
  if (data === 'cmd_osint') {
    const isOsintOn = botConfig.osintConfig.enabled;
    if (!isOsintOn) {
      const offCard = `🔴 *STATUS SERVER DATA OSINT: NONAKTIF (OFF)*
━━━━━━━━━━━━━━━━━━━━━━━━━
⚠️ *Mohon maaf, Server Data OSINT saat ini belum diaktifkan oleh Owner.*

Fitur pencarian intelijen tidak dapat digunakan selama server masih dalam keadaan nonaktif.

📞 *CARA MENGAKTIFKAN:*
Jika Anda ingin menggunakan fitur ini, Anda harus menghubungi Owner Bot untuk mengaktifkan data/server OSINT:
👤 *Owner Telegram:* @flood1233
_(Bebas mau chat ataupun call, asal tidak spam)_
━━━━━━━━━━━━━━━━━━━━━━━━━`;

      await sendTelegramMessage(chatId, offCard, {
        inline_keyboard: [
          [{ text: '📞 Hubungi Owner @flood1233', url: 'https://t.me/flood1233' }],
          [{ text: '💎 Lihat Tarif Harga API Key', callback_data: 'cmd_pricing' }],
          [{ text: '🏠 Kembali ke Menu Utama', callback_data: 'cmd_menu' }]
        ]
      });
    } else {
      const onCard = `🟢 *STATUS SERVER DATA OSINT: AKTIF (ON)*
━━━━━━━━━━━━━━━━━━━━━━━━━
Server Data OSINT saat ini *SEDANG AKTIF* dan siap digunakan!

📖 *CARA MENGGUNAKAN OSINT:*
Kirim pesan dengan format:
\`search: <target> <apiKey>\`

*Contoh:* \`search: jokowi ppp\`

🔍 *CEK SISA KUOTA API KEY:*
Ketik: \`api <apiKey>\` (Contoh: \`api ppp\`)

💎 *TARIF HARGA API KEY (${pricing.currency}):*
${pricing.formatted}

${pricing.note}

🛒 *PEMBELIAN & TOP UP API KEY:*
👤 *Owner Telegram:* @flood1233
_(Bebas mau chat ataupun call, asal tidak spam)_
━━━━━━━━━━━━━━━━━━━━━━━━━`;

      await sendTelegramMessage(chatId, onCard, {
        inline_keyboard: [
          [{ text: '💎 Cek Kuota API Key', callback_data: 'cmd_pricing' }],
          [{ text: '📞 Hubungi Owner @flood1233', url: 'https://t.me/flood1233' }],
          [{ text: '🏠 Kembali ke Menu Utama', callback_data: 'cmd_menu' }]
        ]
      });
    }
    return;
  }

  // Pricing Callback
  if (data === 'cmd_pricing') {
    const priceCard = `💎 *DAFTAR HARGA & PROMOSI API KEY OSINT*
━━━━━━━━━━━━━━━━━━━━━━━━━
Mata Uang: *${pricing.currency}*

${pricing.formatted}

${pricing.note}

💡 *Pencarian OSINT:* \`search: <target> <apiKey>\`
💡 *Cek Sisa Kuota:* \`api <apiKey>\`

📞 *Pemesanan & Top Up:* @flood1233
━━━━━━━━━━━━━━━━━━━━━━━━━`;

    await sendTelegramMessage(chatId, priceCard, {
      inline_keyboard: [
        [{ text: '📞 Hubungi Owner @flood1233', url: 'https://t.me/flood1233' }],
        [{ text: '🏠 Menu Utama', callback_data: 'cmd_menu' }]
      ]
    });
    return;
  }

  // Owner Callback
  if (data === 'cmd_owner') {
    const ownerCard = `📞 *KONTAK RESMI OWNER & ADMIN BOT*
━━━━━━━━━━━━━━━━━━━━━━━━━
👤 *Username Telegram:* @flood1233
💬 *Layanan Resmi:*
• Mengaktifkan Server Data OSINT
• Pembelian & Top Up Kuota API Key
• Paket Hemat & Unlimited
• Bantuan Teknis Bot

💡 _Bebas mau dengan chat ataupun call, asal tidak spam!_
━━━━━━━━━━━━━━━━━━━━━━━━━`;

    await sendTelegramMessage(chatId, ownerCard, {
      inline_keyboard: [
        [{ text: '📞 Buka Chat Owner @flood1233', url: 'https://t.me/flood1233' }],
        [{ text: '💎 Daftar Harga API Key', callback_data: 'cmd_pricing' }],
        [{ text: '🏠 Menu Utama', callback_data: 'cmd_menu' }]
      ]
    });
    return;
  }

  // Calculator info callback
  if (data === 'cmd_calc_info') {
    await sendTelegramMessage(
      chatId,
      `🧮 *FITUR KALKULATOR CEPAT BOT*\n\nKetik perintah dengan format:\n\`/calc <rumus>\`\n\n*Contoh:* \`/calc 2500 * 4 + 1500\`\n• Mendukung perkalian (*), pembagian (/), penambahan (+), pengurangan (-), dan pangkat (^).`
    );
    return;
  }

  // Secret Owner Callbacks
  if (data === 'ax_on') {
    botConfig.osintConfig.enabled = true;
    botConfig.osintConfig.lastToggledAt = new Date().toISOString();
    saveBotConfig();
    await sendTelegramMessage(chatId, `🟢 *SERVER OSINT DIAKTIFKAN (ON)*\n\nMenyiarkan ke seluruh pengguna...`);
    if (botConfig.osintConfig.notifyOnStatusChange) {
      broadcastOsintStatusChange(true).catch(console.error);
    }
    return;
  }

  if (data === 'ax_off') {
    botConfig.osintConfig.enabled = false;
    botConfig.osintConfig.lastToggledAt = new Date().toISOString();
    saveBotConfig();
    await sendTelegramMessage(chatId, `🔴 *SERVER OSINT DINONAKTIFKAN (OFF)*\n\nMenyiarkan ke seluruh pengguna...`);
    if (botConfig.osintConfig.notifyOnStatusChange) {
      broadcastOsintStatusChange(false).catch(console.error);
    }
    return;
  }

  if (data === 'ax_keys') {
    const keys = botConfig.osintConfig.apiKeys;
    const listStr = keys
      .map((k, i) => `${i + 1}. \`${k.key}\` - ${k.tier === 'unlimited' ? 'Unlimited' : `${k.remainingQuota}x (+${k.bonusQuota} bonus)`} (Pakai: ${k.totalUsed}x)`)
      .join('\n');
    await sendTelegramMessage(chatId, `🔑 *DAFTAR API KEY (${keys.length}):*\n━━━━━━━━━━━━━━━━━━━━━━━━━\n${listStr || 'Kosong'}`);
    return;
  }

  if (data === 'ax_test') {
    try {
      const testTarget = `${botConfig.osintConfig.ngrokUrl.replace(/\/$/, '')}/api/v1/search?q=ping&apiKey=test`;
      const testRes = await fetch(testTarget, { method: 'GET' });
      await sendTelegramMessage(chatId, `✅ *RESPON NGROK OK:* HTTP ${testRes.status}`);
    } catch (err: any) {
      await sendTelegramMessage(chatId, `❌ *NGROK OFFLINE:* ${err.message}`);
    }
    return;
  }

  if (data === 'ax_menus') {
    const menus = botConfig.customMenus || [];
    const listStr = menus
      .map((m, i) => `${i + 1}. *${m.label}* [ID: \`${m.id}\`] (${m.enabled ? 'Aktif' : 'Nonaktif'})`)
      .join('\n');
    await sendTelegramMessage(chatId, `🗂️ *DAFTAR MENU KUSTOM TAMBAHAN:*\n━━━━━━━━━━━━━━━━━━━━━━━━━\n${listStr || 'Belum ada menu kustom.'}`);
    return;
  }

  // Handle Custom Dynamic Menu Button Clicks
  if (data.startsWith('cmenu_')) {
    const menuId = data.replace('cmenu_', '');
    const matched = (botConfig.customMenus || []).find((m) => m.id === menuId);
    if (matched) {
      const reply = matched.responseText || `📌 *${matched.label}*`;
      await sendTelegramMessage(chatId, reply, {
        inline_keyboard: [
          [{ text: '🏠 Kembali ke Menu Utama', callback_data: 'cmd_menu' }]
        ]
      });
      return;
    }
  }

  if (data === 'cmd_id') {
    const user = botConfig.activeUsers.find((u) => Number(u.chatId) === Number(chatId));
    const todayWib = getWibDateString();
    const countdown = getTimeUntilNextWibMidnight();
    const firstSeenFormatted = formatWibDate(user?.firstSeen);

    const idCard = `📋 *DETAIL INFORMASI CHAT ID & PROFIL AKUN*
━━━━━━━━━━━━━━━━━━━━━━━━━
🆔 *Chat ID:* \`${chatId}\`
👤 *Nama Lengkap:* ${senderName}
🏷 *Username:* ${usernameTag}
💬 *Tipe Obrolan:* ${message.chat.type.toUpperCase()}
🕒 *Waktu Sistem:* ${wibTime.fullStr}
🔒 *Status Akun:* ${user?.isVerified ? '✅ *Terverifikasi Resmi*' : '⚠️ *Belum Verifikasi*'} (Terdaftar sejak: ${firstSeenFormatted})
━━━━━━━━━━━━━━━━━━━━━━━━━
💎 *STATUS KUOTA PRIBADI ANDA:*
• *Sisa Kuota Aktif:* *${user?.personalQuota || 0}x Pencarian*
• *API Key Pribadi:* \`${user?.personalApiKey || `usr_${chatId}`}\`

🎁 *STATUS JATAH KLAIM:*
• *Kuota Pengguna Baru (5x):* ${user?.hasClaimedNewUserQuota ? '✅ Sudah Diklaim (1x seumur hidup)' : '🎁 *Belum Diklaim (Siap Diambil)*'}
• *Kuota Harian (2x):* ${user?.dailyQuotaLastClaimedDate === todayWib ? `✅ Sudah Diklaim (Reset: ${countdown.formatted} lagi)` : '✨ *Tersedia Hari Ini (Bisa Diklaim)*'}
━━━━━━━━━━━━━━━━━━━━━━━━━
🛡️ _Data akun Anda tersimpan permanen & aman._`;

    await sendTelegramMessage(chatId, idCard, {
      inline_keyboard: [
        [
          { text: '🎁 Menu Klaim Kuota', callback_data: 'cmd_claim_menu' },
          { text: '💎 Cek Saldo Kuota', callback_data: 'cmd_my_quota' }
        ],
        [
          { text: '🔄 Muat Ulang ID', callback_data: 'cmd_id' },
          { text: '🏠 Buka Menu Utama', callback_data: 'cmd_menu' }
        ]
      ]
    });
    return;
  } else if (data === 'cmd_bot') {
    const uptimeSec = botStartedAt ? Math.floor((Date.now() - botStartedAt) / 1000) : 0;
    const botInfo = currentBotInfo;

    const botCard = `🤖 *DETAIL & SPESIFIKASI RESMI AXXOSINTBOT*
━━━━━━━━━━━━━━━━━━━━━━━━━
📛 *Nama Bot:* ${botInfo?.first_name || 'axxosintbot'}
🏷 *Username:* @${botInfo?.username || 'axxosintbot'}
👑 *Developer / Creator:* Ax. (@flood1233)
🔢 *Bot ID:* \`${botInfo?.id || 'N/A'}\`
🟢 *Status:* AKTIF & STANDBY (Always-ON)
⏱ *Durasi Uptime:* ${formatUptime(uptimeSec)}
🔍 *Status OSINT:* ${botConfig.osintConfig.enabled ? '🟢 AKTIF' : '🔴 NONAKTIF'}
👥 *Izin Grup:* ${botInfo?.can_join_groups ? 'Diizinkan' : 'Dibatasi'}
📖 *Mode Baca Pesan:* ${botInfo?.can_read_all_group_messages ? 'Aktif' : 'Default'}
⚡ *Engine:* axxosintbot Core Engine v3.0 (Created by Ax.)
━━━━━━━━━━━━━━━━━━━━━━━━━`;

    await sendTelegramMessage(chatId, botCard, {
      inline_keyboard: [
        [{ text: '🆔 Cek ID Saya', callback_data: 'cmd_id' }],
        [{ text: '🏠 Menu Utama', callback_data: 'cmd_menu' }]
      ]
    });
    return;
  } else if (data === 'cmd_ping') {
    const uptimeSec = botStartedAt ? Math.floor((Date.now() - botStartedAt) / 1000) : 0;
    await sendTelegramMessage(
      chatId,
      `🏓 *PONG! Respon Kilat!*\n\n• Server: Online\n• Latency: ~30ms\n• Uptime: ${formatUptime(uptimeSec)}\n• Waktu: ${wibTime.timeStr}\n• OSINT: ${botConfig.osintConfig.enabled ? '🟢 ON' : '🔴 OFF'}`
    );
    return;
  } else if (data === 'cmd_waktu') {
    const now = new Date();
    const wibStr = new Intl.DateTimeFormat('id-ID', { timeZone: 'Asia/Jakarta', timeStyle: 'medium', dateStyle: 'full' }).format(now);
    await sendTelegramMessage(chatId, `⏰ *Waktu Indonesia Barat (WIB):*\n\n${wibStr} WIB`);
    return;
  } else if (data === 'cmd_help' || data === 'cmd_menu') {
    const welcome = botConfig.welcomeMessage || DEFAULT_WELCOME_MESSAGE;
    await sendTelegramMessage(chatId, welcome, getMainInlineMenu(botConfig.osintConfig.enabled));
    return;
  }

  // Callback: Download Result as .TXT document
  if (data.startsWith('dl_txt_')) {
    const searchId = data.replace('dl_txt_', '');
    const lockKey = `dl_${chatId}`;
    if (activeDownloads.has(lockKey)) {
      safeAnswerCallbackQuery(cbQuery.id, '⏳ Berkas sedang dikirim ke chat Anda, mohon tunggu sebentar...', false, 4000);
      return;
    }
    activeDownloads.add(lockKey);

    try {
      const item = findSearchHistoryItem(searchId, chatId);
      if (!item) {
        await sendTelegramMessage(
          chatId,
          '⚠️ *Data pencarian ini tidak ditemukan atau sudah kadaluarsa.*\n\nData sesi pencarian telah diperbarui atau server baru direstart.\nSilakan lakukan pencarian ulang dengan format:\n`search: <target> <apiKey>`'
        );
        return;
      }

      await sendTelegramChatAction(chatId, 'upload_document');
      const txtContent = generateTxtReport(item);
      const safeTarget = (item.target || 'target').replace(/[^a-zA-Z0-9_-]/g, '_').substring(0, 30);
      const filename = `osint_${safeTarget}_${item.id || Date.now()}.txt`;

      await sendTelegramMessage(chatId, `⏳ *Menyiapkan & mengirim berkas .TXT lengkap (${item.totalMatches} Data - Target: ${item.target})...*`);

      const sent = await sendTelegramDocument(
        chatId,
        txtContent,
        filename,
        `📄 Berkas Lengkap OSINT: ${item.target}\n• Total: ${item.totalMatches} Data\n• API Key: ${item.apiKey}\n• Waktu: ${item.formattedWib || '-'}`
      );

      if (!sent) {
        await sendTelegramMessage(
          chatId,
          `⚠️ *Gagal mengirim berkas dokumen ke Telegram.*\nKoneksi jaringan Telegram sedang sibuk atau data terlalu besar. Anda dapat mencoba lagi atau melihat pratinjau di menu riwayat.`
        );
      }
    } finally {
      setTimeout(() => activeDownloads.delete(lockKey), 2500);
    }
    return;
  }

  // Callback: Download Result as .JSON document
  if (data.startsWith('dl_json_')) {
    const searchId = data.replace('dl_json_', '');
    const lockKey = `dl_${chatId}`;
    if (activeDownloads.has(lockKey)) {
      safeAnswerCallbackQuery(cbQuery.id, '⏳ Berkas sedang dikirim ke chat Anda, mohon tunggu sebentar...', false, 4000);
      return;
    }
    activeDownloads.add(lockKey);

    try {
      const item = findSearchHistoryItem(searchId, chatId);
      if (!item) {
        await sendTelegramMessage(
          chatId,
          '⚠️ *Data pencarian ini tidak ditemukan atau sudah kadaluarsa.*\n\nData sesi pencarian telah diperbarui atau server baru direstart.\nSilakan lakukan pencarian ulang dengan format:\n`search: <target> <apiKey>`'
        );
        return;
      }

      await sendTelegramChatAction(chatId, 'upload_document');
      const safeTarget = (item.target || 'target').replace(/[^a-zA-Z0-9_-]/g, '_').substring(0, 30);
      const filename = `osint_${safeTarget}_${item.id || Date.now()}.json`;

      await sendTelegramMessage(chatId, `⏳ *Menyiapkan & mengirim berkas .JSON lengkap (${item.totalMatches} Data - Target: ${item.target})...*`);

      const sent = await sendTelegramDocument(
        chatId,
        item.rawResult,
        filename,
        `📦 Berkas Raw JSON OSINT: ${item.target}\n• Total: ${item.totalMatches} Data\n• API Key: ${item.apiKey}\n• Waktu: ${item.formattedWib || '-'}`
      );

      if (!sent) {
        await sendTelegramMessage(
          chatId,
          `⚠️ *Gagal mengirim berkas dokumen ke Telegram.*\nKoneksi jaringan Telegram sedang sibuk. Anda dapat mencoba kembali beberapa saat lagi.`
        );
      }
    } finally {
      setTimeout(() => activeDownloads.delete(lockKey), 2500);
    }
    return;
  }

  // Callback: Copy All Output (Full text, with crash warning if > 50)
  if (data.startsWith('copy_all_')) {
    const searchId = data.replace('copy_all_', '');
    const item = findSearchHistoryItem(searchId, chatId);
    if (!item) {
      await sendTelegramMessage(chatId, '⚠️ Data pencarian ini tidak ditemukan atau sudah dibersihkan.');
      return;
    }

    const chunkSize = 3500;
    const fullText = item.rawResult || '';
    const totalChunks = Math.ceil(fullText.length / chunkSize);

    if (item.totalMatches > 50 || totalChunks > 3) {
      await sendTelegramMessage(
        chatId,
        `⚠️ *PERINGATAN UKURAN DATA BESAR (${item.totalMatches} Data / ${totalChunks} Bagian):*\nMenampilkan ratusan baris data langsung ke chat dapat menyebabkan Telegram mobile Anda freeze, lag, atau terkena limit pesan.\n\n📦 *Sangat disarankan langsung mengunduh berkas lengkap di bawah ini (100% utuh & lancar tanpa batas):*`,
        {
          inline_keyboard: [
            [{ text: '📥 Download File .TXT (Sangat Direkomendasikan)', callback_data: `dl_txt_${item.id}` }],
            [{ text: '📥 Download File .JSON', callback_data: `dl_json_${item.id}` }],
            [{ text: '🏠 Menu Utama', callback_data: 'cmd_menu' }]
          ]
        }
      );
      return;
    }

    // Send complete text in chunks without truncation
    for (let i = 0; i < totalChunks; i++) {
      const chunk = fullText.substring(i * chunkSize, (i + 1) * chunkSize);
      await sendTelegramMessage(
        chatId,
        `📋 *BAGIAN ${i + 1}/${totalChunks} (Target: ${item.target}) - Salin Teks Utuh:*
\`\`\`
${chunk}
\`\`\``
      );
    }
    return;
  }

  // Callback: User History (Isolated by Chat ID)
  if (data === 'user_history') {
    await handleUserHistoryCommand(Number(chatId), senderName);
    return;
  }

  // Callback: View Specific History Item
  if (data.startsWith('view_hist_')) {
    const searchId = data.replace('view_hist_', '');
    const item = findSearchHistoryItem(searchId, chatId);
    if (!item) {
      await sendTelegramMessage(chatId, '⚠️ Catatan riwayat ini tidak ditemukan atau sudah kadaluarsa.');
      return;
    }

    const { messageText, replyMarkup } = formatOsintPresentation(
      item.target,
      item.apiKey,
      item.totalMatches,
      'Sesuai Key',
      { fullStr: item.formattedWib },
      item.rawResult,
      item.id
    );

    await sendTelegramMessage(chatId, `📂 *Membuka Kembali Dari Riwayat Pribadi:*\n\n` + messageText, replyMarkup);
    return;
  }

  // Callback: Confirm Clear My History
  if (data === 'confirm_clear_my_hist') {
    await sendTelegramMessage(
      chatId,
      `⚠️ *KONFIRMASI PENGHAPUSAN RIWAYAT PRIBADI*
━━━━━━━━━━━━━━━━━━━━━━━━━
Apakah Anda yakin ingin menghapus seluruh riwayat pencarian OSINT untuk akun Chat ID \`${chatId}\`?

_Tindakan ini hanya menghapus riwayat milik Anda sendiri dan tidak mempengaruhi pengguna lain._`,
      {
        inline_keyboard: [
          [
            { text: '🗑️ Ya, Hapus Riwayat Saya', callback_data: 'do_clear_my_hist' },
            { text: '❌ Batal', callback_data: 'user_history' }
          ]
        ]
      }
    );
    return;
  }

  // Callback: Do Clear My History
  if (data === 'do_clear_my_hist') {
    if (Array.isArray(botConfig.searchHistories)) {
      const initialLen = botConfig.searchHistories.length;
      botConfig.searchHistories = botConfig.searchHistories.filter((h) => h.chatId !== Number(chatId));
      const deletedCount = initialLen - botConfig.searchHistories.length;
      saveBotConfig();
      await sendTelegramMessage(
        chatId,
        `✅ *BERHASIL DIHAPUS!*\nSebanyak *${deletedCount} catatan riwayat pencarian* milik Chat ID \`${chatId}\` telah dibersihkan.`,
        {
          inline_keyboard: [[{ text: '🏠 Kembali ke Menu', callback_data: 'cmd_menu' }]]
        }
      );
    }
    return;
  }
}

// Continuous Long-Polling Worker (Runs as long as bot is ACTIVE / ON)
async function runTelegramPollingLoop() {
  if (isPollingRunning) return;
  isPollingRunning = true;
  pollingAbortController = new AbortController();

  console.log('[Telegram Polling] Starting continuous polling loop (ALWAYS ON)...');
  addLog('system', 'Service polling Telegram dimulai. Bot status: AKTIF (Always-ON).');

  while (botConfig.isActive) {
    if (!botConfig.token) {
      lastError = 'Token belum dikonfigurasi.';
      addLog('error', 'Polling berhenti: Token Telegram belum diisi.');
      botConfig.isActive = false;
      saveBotConfig();
      break;
    }

    try {
      lastPollingTimestamp = new Date().toISOString();
      const url = `https://api.telegram.org/bot${botConfig.token}/getUpdates?offset=${pollingOffset}&timeout=15&allowed_updates=["message","callback_query"]`;

      const response = await fetch(url, {
        signal: pollingAbortController?.signal
      });

      if (!botConfig.isActive) break;

      if (!response.ok) {
        const errorBody = await response.text();
        lastError = `Telegram API Error (${response.status}): ${errorBody}`;
        addLog('error', `Gagal polling Telegram API (${response.status}). Menunggu retry...`);
        // Wait 4 seconds before retry on HTTP errors
        await new Promise((resolve) => setTimeout(resolve, 4000));
        continue;
      }

      const data = await response.json();

      if (!data.ok) {
        lastError = data.description || 'Error getUpdates';
        addLog('error', `Telegram getUpdates Error: ${data.description}`);
        if (data.error_code === 401) {
          // Token invalid or revoked
          addLog('error', 'Token bot tidak valid atau telah dicabut oleh BotFather! Mematikan polling otomatis.');
          botConfig.isActive = false;
          saveBotConfig();
          break;
        }
        await new Promise((resolve) => setTimeout(resolve, 5000));
        continue;
      }

      lastError = null;
      const updates = data.result || [];

      for (const update of updates) {
        if (!botConfig.isActive) break;

        // Advance offset
        if (update.update_id >= pollingOffset) {
          pollingOffset = update.update_id + 1;
          botConfig.lastPollingOffset = pollingOffset;
        }

        // Deduplication shield: prevent duplicate processing of the same Telegram update
        if (processedUpdateIds.has(update.update_id)) {
          continue;
        }
        processedUpdateIds.add(update.update_id);
        if (processedUpdateIds.size > 1000) {
          const first = processedUpdateIds.values().next().value;
          if (first !== undefined) processedUpdateIds.delete(first);
        }

        if (update.message) {
          await handleIncomingMessage(update.message);
        } else if (update.callback_query) {
          await handleCallbackQuery(update.callback_query);
        }
      }
    } catch (err: any) {
      if (err.name === 'AbortError' || !botConfig.isActive) {
        console.log('[Telegram Polling] Polling aborted cleanly.');
        break;
      }
      lastError = err.message;
      addLog('error', `Koneksi polling terganggu: ${err.message}. Mencoba kembali dalam 3 detik...`);
      await new Promise((resolve) => setTimeout(resolve, 3000));
    }
  }

  isPollingRunning = false;
  console.log('[Telegram Polling] Polling loop stopped.');
  addLog('system', 'Service polling Telegram dinonaktifkan (Status: OFF).');
}

// Start Bot Engine
async function startBotEngine(): Promise<{ success: boolean; message: string; botInfo?: TelegramBotInfo }> {
  if (!botConfig.token) {
    return { success: false, message: 'Token Telegram belum diisi. Silakan masukkan token terlebih dahulu.' };
  }

  // Validate token with Telegram getMe
  const validation = await verifyTelegramToken(botConfig.token);
  if (!validation.valid || !validation.botInfo) {
    lastError = validation.errorMessage || 'Token tidak valid';
    return {
      success: false,
      message: `Token tidak valid: ${validation.errorMessage || 'Unauthorized'}`
    };
  }

  currentBotInfo = validation.botInfo;
  botConfig.isActive = true;
  if (!botStartedAt) {
    botStartedAt = Date.now();
  }
  lastError = null;
  saveBotConfig();

  // Trigger continuous background loop
  runTelegramPollingLoop().catch((err) => {
    console.error('[Telegram Polling] Unhandled loop error:', err);
  });

  return {
    success: true,
    message: `Bot @${validation.botInfo.username} berhasil diaktifkan dan akan selalu aktif!`,
    botInfo: validation.botInfo
  };
}

// Stop Bot Engine
function stopBotEngine(): { success: boolean; message: string } {
  botConfig.isActive = false;
  botStartedAt = null;
  saveBotConfig();

  if (pollingAbortController) {
    try {
      pollingAbortController.abort();
    } catch (e) {
      // ignore
    }
    pollingAbortController = null;
  }

  return {
    success: true,
    message: 'Bot Telegram telah dimatikan (Status: OFF).'
  };
}

// Initialize config on server start
loadBotConfig();

// Setup Express App
async function startServer() {
  const app = express();
  const PORT = 3000;

  // Enable CORS and preflight handling
  app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
    res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
    if (req.method === 'OPTIONS') {
      return res.sendStatus(200);
    }
    next();
  });

  app.use(express.json({ limit: '500mb' }));
  app.use(express.urlencoded({ limit: '500mb', extended: true }));

  // Health Endpoint
  app.get('/api/health', (req, res) => {
    res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
    res.json({
      status: 'ok',
      service: 'Telegram Bot Automation Controller',
      botActive: botConfig.isActive,
      botUsername: currentBotInfo?.username || null,
      timestamp: new Date().toISOString()
    });
  });

  // Get Complete Bot Status
  app.get('/api/bot/status', async (req, res) => {
    try {
      const uptimeSec = botStartedAt && botConfig.isActive ? Math.floor((Date.now() - botStartedAt) / 1000) : 0;

      const response: BotStatusState = {
        isActive: Boolean(botConfig.isActive),
        token: botConfig.token || '',
        maskedToken: maskToken(botConfig.token),
        isTokenValid: Boolean(currentBotInfo),
        botInfo: currentBotInfo,
        lastError,
        uptimeSeconds: uptimeSec,
        startedAt: botStartedAt ? new Date(botStartedAt).toISOString() : null,
        stats: botConfig.stats || {
          messagesReceived: 0,
          messagesSent: 0,
          commandsExecuted: 0,
          activeUsersCount: 0
        },
        recentLogs: (recentLogs || []).slice(0, 80),
        activeUsers: (botConfig.activeUsers || []).slice(0, 50),
        customCommands: botConfig.customCommands || [],
        autoReplies: botConfig.autoReplies || [],
        customMenus: botConfig.customMenus || [],
        welcomeMessage: botConfig.welcomeMessage || DEFAULT_WELCOME_MESSAGE,
        lastPollingAt: lastPollingTimestamp || undefined,
        osintConfig: botConfig.osintConfig,
        searchHistories: botConfig.searchHistories || [],
        githubSync: botConfig.githubSync || DEFAULT_GITHUB_SYNC,
        groupConfig: botConfig.groupConfig || DEFAULT_GROUP_CONFIG,
        quotaConfig: botConfig.quotaConfig || DEFAULT_QUOTA_CONFIG,
        menuConfig: botConfig.menuConfig || DEFAULT_MENU_CONFIG,
        moderationConfig: botConfig.moderationConfig || DEFAULT_MODERATION_CONFIG,
        spikeAlerts: recentSpikeAlerts
      };

      res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
      return res.json(response);
    } catch (err: any) {
      console.error('Error in /api/bot/status handler:', err);
      return res.status(500).json({
        isActive: false,
        token: '',
        maskedToken: '',
        isTokenValid: false,
        botInfo: null,
        lastError: err?.message || 'Internal status error',
        uptimeSeconds: 0,
        startedAt: null,
        stats: { messagesReceived: 0, messagesSent: 0, commandsExecuted: 0, activeUsersCount: 0 },
        recentLogs: [],
        activeUsers: [],
        customCommands: [],
        autoReplies: [],
        customMenus: [],
        welcomeMessage: '',
        osintConfig: DEFAULT_OSINT_CONFIG
      });
    }
  });

  // Get Suspicious Search Spike Alerts
  app.get('/api/bot/spike-alerts', (req, res) => {
    res.json({
      success: true,
      alerts: recentSpikeAlerts,
      totalEventsLastMinute: recentSearchEvents.length
    });
  });

  // Clear Spike Alerts
  app.delete('/api/bot/spike-alerts', (req, res) => {
    recentSpikeAlerts = [];
    res.json({
      success: true,
      message: 'Riwayat alert lonjakan pencarian berhasil dibersihkan.'
    });
  });

  // Verify Token with Real Telegram API
  app.post('/api/bot/verify-token', async (req, res) => {
    const { token = '' } = req.body;
    const result = await verifyTelegramToken(token);
    res.json(result);
  });

  // Update Token
  app.post('/api/bot/update-token', async (req, res) => {
    const { token = '' } = req.body;
    const trimmed = (token || '').trim();

    if (!trimmed) {
      return res.status(400).json({
        success: false,
        message: 'Token Telegram tidak boleh kosong.'
      });
    }

    // Always verify before saving!
    const validation = await verifyTelegramToken(trimmed);
    if (!validation.valid || !validation.botInfo) {
      return res.status(400).json({
        success: false,
        message: validation.errorMessage || 'Token tidak valid menurut Telegram API.',
        details: validation
      });
    }

    const wasActive = botConfig.isActive;
    if (wasActive) {
      stopBotEngine();
    }

    botConfig.token = trimmed;
    currentBotInfo = validation.botInfo;
    saveBotConfig();

    addLog('system', `Token bot diperbarui ke @${validation.botInfo.username}`);

    if (wasActive) {
      await startBotEngine();
    }

    res.json({
      success: true,
      message: `Token berhasil disimpan! Terverifikasi milik @${validation.botInfo.username}.`,
      botInfo: validation.botInfo,
      latencyMs: validation.latencyMs
    });
  });

  // Toggle Bot ON/OFF
  app.post('/api/bot/toggle', async (req, res) => {
    const { active } = req.body;

    if (active) {
      const result = await startBotEngine();
      if (!result.success) {
        return res.status(400).json({
          success: false,
          message: result.message
        });
      }
      return res.json({
        success: true,
        isActive: true,
        message: result.message,
        botInfo: result.botInfo
      });
    } else {
      const result = stopBotEngine();
      return res.json({
        success: true,
        isActive: false,
        message: result.message
      });
    }
  });

  // Send Direct Message to a specific Chat ID from Web
  app.post('/api/bot/send-message', async (req, res) => {
    const { chatId, text, parseMode = 'Markdown' } = req.body;

    if (!chatId || !text) {
      return res.status(400).json({
        success: false,
        message: 'Chat ID dan pesan wajib diisi.'
      });
    }

    if (!botConfig.token) {
      return res.status(400).json({
        success: false,
        message: 'Bot token belum dikonfigurasi.'
      });
    }

    try {
      const payload: any = {
        chat_id: chatId,
        text,
        parse_mode: parseMode
      };
      const response = await callTelegramApi(botConfig.token, 'sendMessage', payload, 10000);

      if (response && response.ok) {
        botConfig.stats.messagesSent += 1;
        saveBotConfig();
        addLog('outgoing', `[Direct Web] Pesan ke ${chatId}: "${text.substring(0, 60)}"`, chatId);

        return res.json({
          success: true,
          message: `Pesan berhasil terkirim ke Chat ID ${chatId}!`,
          result: response.result
        });
      } else {
        return res.status(400).json({
          success: false,
          message: `Telegram Error: ${response?.description || 'Gagal mengirim pesan'}`
        });
      }
    } catch (err: any) {
      return res.status(500).json({
        success: false,
        message: `Terjadi kesalahan pengiriman: ${err.message}`
      });
    }
  });

  // Broadcast Message to All Known Active Users
  app.post('/api/bot/broadcast', async (req, res) => {
    const { text } = req.body;
    if (!text || !text.trim()) {
      return res.status(400).json({
        success: false,
        message: 'Pesan broadcast tidak boleh kosong.'
      });
    }

    if (!botConfig.token) {
      return res.status(400).json({
        success: false,
        message: 'Bot token belum dikonfigurasi.'
      });
    }

    const users = botConfig.activeUsers || [];
    if (users.length === 0) {
      return res.status(400).json({
        success: false,
        message: 'Belum ada pengguna yang pernah berinteraksi dengan bot untuk dikirimkan broadcast.'
      });
    }

    let successCount = 0;
    let failCount = 0;

    for (const u of users) {
      try {
        const payload = {
          chat_id: u.chatId,
          text: `📢 *PENGUMUMAN DARI CONTROLLER*\n\n${text}`,
          parse_mode: 'Markdown'
        };
        const response = await callTelegramApi(botConfig.token, 'sendMessage', payload, 5000);
        if (response && response.ok) {
          successCount++;
        } else {
          failCount++;
        }
      } catch {
        failCount++;
      }
      // Small pause to respect Telegram rate limits
      await new Promise((r) => setTimeout(r, 80));
    }

    botConfig.stats.messagesSent += successCount;
    saveBotConfig();

    addLog('outgoing', `Broadcast terkirim: ${successCount} berhasil, ${failCount} gagal.`);

    res.json({
      success: true,
      totalUsers: users.length,
      successCount,
      failCount,
      message: `Broadcast selesai: ${successCount} pengguna menerima pesan.`
    });
  });

  // Save Custom Commands
  app.post('/api/bot/custom-commands', (req, res) => {
    const { customCommands } = req.body;
    if (!Array.isArray(customCommands)) {
      return res.status(400).json({ success: false, message: 'Format custom commands harus berupa array.' });
    }
    botConfig.customCommands = customCommands;
    saveBotConfig();
    addLog('system', `Daftar perintah kustom diperbarui (${customCommands.length} perintah).`);
    res.json({ success: true, customCommands: botConfig.customCommands });
  });

  // Save Auto Replies
  app.post('/api/bot/auto-replies', (req, res) => {
    const { autoReplies } = req.body;
    if (!Array.isArray(autoReplies)) {
      return res.status(400).json({ success: false, message: 'Format auto replies harus berupa array.' });
    }
    botConfig.autoReplies = autoReplies;
    saveBotConfig();
    addLog('system', `Aturan balasan otomatis diperbarui (${autoReplies.length} aturan).`);
    res.json({ success: true, autoReplies: botConfig.autoReplies });
  });

  // Save Welcome Message
  app.post('/api/bot/welcome-message', (req, res) => {
    const { welcomeMessage } = req.body;
    if (typeof welcomeMessage !== 'string') {
      return res.status(400).json({ success: false, message: 'Welcome message harus berupa teks string.' });
    }
    botConfig.welcomeMessage = welcomeMessage;
    saveBotConfig();
    addLog('system', 'Pesan selamat datang /start diperbarui.');
    res.json({ success: true, welcomeMessage: botConfig.welcomeMessage });
  });

  // Clear Logs
  app.post('/api/bot/clear-logs', (req, res) => {
    recentLogs = [];
    addLog('system', 'Log aktivitas dibersihkan.');
    res.json({ success: true });
  });

  // Reset Stats
  app.post('/api/bot/reset-stats', (req, res) => {
    botConfig.stats = {
      messagesReceived: 0,
      messagesSent: 0,
      commandsExecuted: 0,
      activeUsersCount: botConfig.activeUsers.length,
      osintSearchesCount: 0
    };
    saveBotConfig();
    res.json({ success: true, stats: botConfig.stats });
  });

  // OSINT: Toggle Feature ON/OFF from Web
  app.post('/api/bot/osint/toggle', async (req, res) => {
    const { enabled, broadcast = true } = req.body;
    botConfig.osintConfig.enabled = Boolean(enabled);
    botConfig.osintConfig.lastToggledAt = new Date().toISOString();
    saveBotConfig();
    addLog('system', `Status server OSINT diubah via Web Dashboard ke: ${botConfig.osintConfig.enabled ? 'ON' : 'OFF'}`);

    if (broadcast && botConfig.osintConfig.notifyOnStatusChange) {
      broadcastOsintStatusChange(botConfig.osintConfig.enabled).catch(console.error);
    }

    res.json({
      success: true,
      enabled: botConfig.osintConfig.enabled,
      osintConfig: botConfig.osintConfig,
      message: `Server OSINT berhasil ${botConfig.osintConfig.enabled ? 'DIAKTIFKAN (ON)' : 'DINONAKTIFKAN (OFF)'}.`
    });
  });

  // OSINT: Update Config (Ngrok URL, Owner Username, Broadcast notify)
  app.post('/api/bot/osint/config', (req, res) => {
    const { ngrokUrl, ownerUsername, notifyOnStatusChange } = req.body;
    if (typeof ngrokUrl === 'string' && ngrokUrl.trim()) {
      botConfig.osintConfig.ngrokUrl = ngrokUrl.trim();
    }
    if (typeof ownerUsername === 'string' && ownerUsername.trim()) {
      botConfig.osintConfig.ownerUsername = ownerUsername.trim();
    }
    if (typeof notifyOnStatusChange === 'boolean') {
      botConfig.osintConfig.notifyOnStatusChange = notifyOnStatusChange;
    }
    saveBotConfig();
    addLog('system', `Konfigurasi server OSINT diperbarui via Web.`);
    res.json({ success: true, osintConfig: botConfig.osintConfig, message: 'Konfigurasi OSINT berhasil disimpan.' });
  });

  // OSINT: Manage API Keys (Add, Update, Delete)
  app.post('/api/bot/osint/api-keys', (req, res) => {
    const { apiKeys } = req.body;
    if (!Array.isArray(apiKeys)) {
      return res.status(400).json({ success: false, message: 'Format apiKeys harus array.' });
    }
    botConfig.osintConfig.apiKeys = apiKeys;
    saveBotConfig();
    addLog('system', `Daftar API Key OSINT diperbarui via Web (${apiKeys.length} keys).`);
    res.json({ success: true, apiKeys: botConfig.osintConfig.apiKeys, message: 'Daftar API Key berhasil disimpan.' });
  });

  // OSINT: Test Connection to Ngrok
  app.post('/api/bot/osint/test-ngrok', async (req, res) => {
    const { url } = req.body;
    const targetUrl = (url || botConfig.osintConfig.ngrokUrl).replace(/\/$/, '');
    const testEndpoint = `${targetUrl}/api/v1/search?q=ping&apiKey=test`;

    try {
      const start = Date.now();
      const testRes = await fetch(testEndpoint, {
        method: 'GET',
        headers: { 'User-Agent': 'TelegramBotController/2.0' }
      });
      const latency = Date.now() - start;
      res.json({
        success: true,
        status: testRes.status,
        statusText: testRes.statusText,
        latencyMs: latency,
        message: `Koneksi ke Ngrok berhasil! (HTTP ${testRes.status} ${testRes.statusText})`
      });
    } catch (err: any) {
      res.json({
        success: false,
        message: `Gagal tersambung ke tunnel Ngrok: ${err.message}`
      });
    }
  });

  // Custom Menus: Save Dynamic Menus from Web
  app.post('/api/bot/custom-menus', (req, res) => {
    const { customMenus } = req.body;
    if (!Array.isArray(customMenus)) {
      return res.status(400).json({ success: false, message: 'Format customMenus harus array.' });
    }
    botConfig.customMenus = customMenus;
    saveBotConfig();
    addLog('system', `Menu kustom Telegram diperbarui via Web (${customMenus.length} menu).`);
    res.json({ success: true, customMenus: botConfig.customMenus, message: 'Menu kustom berhasil diperbarui.' });
  });

  // User Verification: Toggle User Verification Status from Web
  app.post('/api/bot/users/verify', (req, res) => {
    const { chatId, isVerified } = req.body;
    const user = botConfig.activeUsers.find((u) => Number(u.chatId) === Number(chatId));
    if (!user) {
      return res.status(404).json({ success: false, message: 'Pengguna tidak ditemukan.' });
    }
    user.isVerified = Boolean(isVerified);
    if (user.isVerified) {
      user.verifiedAt = new Date().toISOString();
      syncUserApiKey(user);
    }
    saveBotConfig();
    addLog('system', `Status verifikasi pengguna ${chatId} (${user.firstName}) diubah ke: ${user.isVerified ? 'Terverifikasi' : 'Belum'}`);
    res.json({ success: true, user, message: `Status pengguna berhasil diperbarui.` });
  });

  // User Quota Management: Gift or Update Quota
  app.post('/api/bot/users/quota', (req, res) => {
    const { chatId, personalQuota, hasClaimedNewUserQuota, resetDailyClaim } = req.body;
    const user = botConfig.activeUsers.find((u) => Number(u.chatId) === Number(chatId));
    if (!user) {
      return res.status(404).json({ success: false, message: 'Pengguna tidak ditemukan.' });
    }

    if (typeof personalQuota === 'number') {
      user.personalQuota = Math.max(0, personalQuota);
    }
    if (typeof hasClaimedNewUserQuota === 'boolean') {
      user.hasClaimedNewUserQuota = hasClaimedNewUserQuota;
    }
    if (resetDailyClaim) {
      user.dailyQuotaLastClaimedDate = undefined;
    }

    syncUserApiKey(user);
    saveBotConfig();
    addLog('system', `Kuota pengguna ${chatId} (${user.firstName}) diperbarui via Web: Sisa Kuota ${user.personalQuota}x`);
    res.json({ success: true, user, message: 'Kuota pengguna berhasil disimpan.' });
  });

  // Gift Quota to User with optional Telegram Notification
  app.post('/api/bot/users/gift-quota', async (req, res) => {
    const { chatId, amount = 5, notifyUser = true, notes = 'Hadiah dari Admin' } = req.body;
    const user = botConfig.activeUsers.find((u) => Number(u.chatId) === Number(chatId));
    if (!user) {
      return res.status(404).json({ success: false, message: 'Pengguna tidak ditemukan.' });
    }

    user.personalQuota = (user.personalQuota || 0) + Number(amount);
    syncUserApiKey(user);
    saveBotConfig();

    addLog('system', `Admin memberikan hadiah +${amount} kuota ke pengguna ${chatId} (${user.firstName}).`);

    if (notifyUser && botConfig.token) {
      const giftMessage = `🎁 *ANDA MENDAPATKAN BONUS KUOTA DARI ADMIN!*
━━━━━━━━━━━━━━━━━━━━━━━━━
Halo *${user.firstName}*! Admin Web Controller baru saja menambahkan kuota ke akun Anda:

➕ *Bonus Kuota:* *+${amount}x Pencarian OSINT*
💎 *Total Sisa Kuota Pribadi:* *${user.personalQuota}x Pemakaian*
📝 *Catatan:* ${notes}
🔑 *API Key Anda:* \`${user.personalApiKey || `usr_${chatId}`}\`
━━━━━━━━━━━━━━━━━━━━━━━━━
💡 _Gunakan perintah \`search: <target>\` untuk mencari intelijen._`;

      try {
        await sendTelegramMessage(chatId, giftMessage, {
          inline_keyboard: [
            [{ text: '💎 Cek Saldo Kuota', callback_data: 'cmd_my_quota' }],
            [{ text: '🏠 Menu Utama', callback_data: 'cmd_menu' }]
          ]
        });
      } catch (e: any) {
        console.error('Failed to notify user of gifted quota:', e.message);
      }
    }

    res.json({
      success: true,
      user,
      message: `Berhasil menambahkan +${amount} kuota ke ${user.firstName} (${chatId}).`
    });
  });

  // OSINT: Get Search History (Optional filter by chatId)
  app.get('/api/bot/osint/history', (req, res) => {
    const { chatId } = req.query;
    let histories = botConfig.searchHistories || [];
    if (chatId) {
      histories = histories.filter((h) => h.chatId === Number(chatId));
    }
    res.json({
      success: true,
      total: histories.length,
      histories
    });
  });

  // OSINT: Delete Single Search History Item
  app.delete('/api/bot/osint/history/:id', (req, res) => {
    const { id } = req.params;
    const initialLen = (botConfig.searchHistories || []).length;
    botConfig.searchHistories = (botConfig.searchHistories || []).filter((h) => h.id !== id);
    const deletedCount = initialLen - botConfig.searchHistories.length;
    saveBotConfig();
    addLog('system', `Riwayat pencarian OSINT #${id} dihapus via Web.`);
    res.json({ success: true, deletedCount, message: 'Riwayat pencarian berhasil dihapus.' });
  });

  // OSINT: Clear Search History (Optionally per chatId or All)
  app.post('/api/bot/osint/history/clear', (req, res) => {
    const { chatId } = req.body;
    if (chatId) {
      botConfig.searchHistories = (botConfig.searchHistories || []).filter((h) => h.chatId !== Number(chatId));
      addLog('system', `Riwayat pencarian OSINT untuk Chat ID ${chatId} dibersihkan.`);
    } else {
      botConfig.searchHistories = [];
      addLog('system', `Seluruh riwayat pencarian OSINT dibersihkan via Web.`);
    }
    saveBotConfig();
    res.json({ success: true, message: 'Riwayat pencarian berhasil dibersihkan.' });
  });

  // OSINT: Direct File Download Route (.txt or .json)
  app.get('/api/bot/osint/download/:id', (req, res) => {
    const { id } = req.params;
    const format = ((req.query.format as string) || 'txt').toLowerCase();
    const item = (botConfig.searchHistories || []).find((h) => h.id === id);

    if (!item) {
      return res.status(404).send('Data pencarian tidak ditemukan atau sudah dibersihkan.');
    }

    const sanitizedTarget = item.target.replace(/[^a-zA-Z0-9_-]/g, '_');
    if (format === 'json') {
      res.setHeader('Content-Type', 'application/json; charset=utf-8');
      res.setHeader('Content-Disposition', `attachment; filename="osint_${sanitizedTarget}_${item.id}.json"`);
      return res.send(item.rawResult);
    } else {
      const txtContent = generateTxtReport(item);
      res.setHeader('Content-Type', 'text/plain; charset=utf-8');
      res.setHeader('Content-Disposition', `attachment; filename="osint_${sanitizedTarget}_${item.id}.txt"`);
      return res.send(txtContent);
    }
  });

  // ==========================================
  // DATASET MANAGEMENT API (Smart & Unlimited Size)
  // ==========================================

  // 1. Get all dataset files list
  app.get('/api/datasets', async (req, res) => {
    try {
      const files = await getAllDatasetFiles();
      res.json({ success: true, files });
    } catch (err: any) {
      res.status(500).json({ success: false, message: `Gagal memuat daftar file: ${err.message}` });
    }
  });

  // 2. Upload dataset file (no file size limit)
  app.post('/api/datasets/upload', (req, res) => {
    datasetUpload.single('file')(req, res, async (err) => {
      if (err) {
        console.error('Multer upload error:', err);
        return res.status(400).json({ success: false, message: `Gagal upload: ${err.message}` });
      }

      try {
        if (!req.file) {
          return res.status(400).json({ success: false, message: 'Tidak ada file yang diunggah.' });
        }

        const setAsDefault = req.body.setAsDefault === 'true' || req.body.setAsDefault === true;
        const uploadedPath = req.file.path;
        const originalName = path.basename(req.file.originalname || 'dataset.txt');

        if (setAsDefault || originalName.toLowerCase() === 'dataset.txt') {
          // Also copy/replace data/dataset.txt
          fs.copyFileSync(uploadedPath, DEFAULT_DATASET_FILE);
        }

        addLog('system', `File dataset diunggah: ${originalName} (${(req.file.size / 1024).toFixed(1)} KB)`);

        const files = await getAllDatasetFiles();
        res.json({
          success: true,
          message: `File ${originalName} berhasil diunggah! Sistem pintar otomatis siap menggunakannya untuk pencarian intelijen.`,
          file: req.file,
          files
        });
      } catch (uploadErr: any) {
        res.status(500).json({ success: false, message: `Gagal memproses file unggahan: ${uploadErr.message}` });
      }
    });
  });

  // 3. Create / Add new dataset file directly
  app.post('/api/datasets/create', async (req, res) => {
    try {
      const { filename, content } = req.body;
      if (!filename || typeof filename !== 'string') {
        return res.status(400).json({ success: false, message: 'Nama file wajib diisi.' });
      }

      const baseName = sanitizeDatasetFilename(filename);
      await writeDatasetContent(baseName, content || '');
      addLog('system', `File dataset baru dibuat: ${baseName}`);

      const files = await getAllDatasetFiles();
      res.json({
        success: true,
        message: `File dataset ${baseName} berhasil dibuat dan siap dicari!`,
        files
      });
    } catch (err: any) {
      res.status(500).json({ success: false, message: `Gagal membuat file: ${err.message}` });
    }
  });

  // 4. Read file content (for Edit / View mode)
  app.get('/api/datasets/content', async (req, res) => {
    try {
      const filename = sanitizeDatasetFilename((req.query.filename as string) || 'dataset.txt');
      const maxLines = req.query.maxLines ? parseInt(req.query.maxLines as string, 10) : undefined;
      const data = await readDatasetContent(filename, maxLines);
      res.json({ success: true, ...data });
    } catch (err: any) {
      res.status(500).json({ success: false, message: `Gagal membaca isi file: ${err.message}` });
    }
  });

  // 5. Save edited file content
  app.put('/api/datasets/content', async (req, res) => {
    try {
      const { filename, content } = req.body;
      if (!filename || typeof filename !== 'string') {
        return res.status(400).json({ success: false, message: 'Nama file tidak valid.' });
      }

      const baseName = sanitizeDatasetFilename(filename);
      await writeDatasetContent(baseName, content || '');
      addLog('system', `File dataset diperbarui: ${baseName}`);

      const files = await getAllDatasetFiles();
      res.json({
        success: true,
        message: `Perubahan pada ${baseName} berhasil disimpan!`,
        files
      });
    } catch (err: any) {
      res.status(500).json({ success: false, message: `Gagal menyimpan file: ${err.message}` });
    }
  });

  // 6. Delete dataset file
  app.delete('/api/datasets/:filename', async (req, res) => {
    try {
      const rawParam = req.params.filename ? decodeURIComponent(req.params.filename) : 'dataset.txt';
      const filename = sanitizeDatasetFilename(rawParam);
      const result = await deleteDatasetFile(filename);
      addLog('system', `File dataset dihapus/dibersihkan: ${filename}`);
      const files = await getAllDatasetFiles();
      res.json({
        success: true,
        message: result.message || `File ${filename} berhasil dihapus.`,
        files
      });
    } catch (err: any) {
      res.status(500).json({ success: false, message: `Gagal menghapus file: ${err.message}` });
    }
  });

  // 7. Download dataset file
  app.get('/api/datasets/download/:filename', (req, res) => {
    try {
      const rawParam = req.params.filename ? decodeURIComponent(req.params.filename) : 'dataset.txt';
      const sanitized = sanitizeDatasetFilename(rawParam);
      const filePath = sanitized.toLowerCase() === 'dataset.txt'
        ? DEFAULT_DATASET_FILE
        : path.join(DATASETS_DIR, sanitized);

      if (!fs.existsSync(filePath)) {
        return res.status(404).send('File dataset tidak ditemukan.');
      }

      res.setHeader('Content-Type', 'text/plain; charset=utf-8');
      res.setHeader('Content-Disposition', `attachment; filename="${sanitized}"`);
      fs.createReadStream(filePath).pipe(res);
    } catch (err: any) {
      res.status(500).send(`Gagal mendownload file: ${err.message}`);
    }
  });

  // 8. Test Smart Search on Datasets (Live Web Tester)
  app.post('/api/datasets/search', async (req, res) => {
    try {
      const { query, limit } = req.body;
      if (!query || typeof query !== 'string') {
        return res.status(400).json({ success: false, message: 'Query target pencarian wajib diisi.' });
      }

      const result = await smartSearchDatasets(query.trim(), limit ? parseInt(limit, 10) : 100);
      res.json({
        success: true,
        result
      });
    } catch (err: any) {
      res.status(500).json({ success: false, message: `Error saat memproses pencarian: ${err.message}` });
    }
  });

  // 9. Update OSINT Search Mode (smart_dataset | hybrid | ngrok_only)
  app.post('/api/bot/osint/mode', (req, res) => {
    const { mode } = req.body;
    if (mode && ['smart_dataset', 'hybrid', 'ngrok_only'].includes(mode)) {
      botConfig.osintConfig.searchEngineMode = mode;
      saveBotConfig();
      addLog('system', `Mode mesin pencarian OSINT diubah ke: ${mode}`);
      res.json({ success: true, mode, message: `Mode pencarian berhasil diubah ke ${mode}` });
    } else {
      res.status(400).json({ success: false, message: 'Mode tidak valid. Pilihan: smart_dataset, hybrid, ngrok_only.' });
    }
  });

  // =========================================================================
  // GITHUB DATASET SYNC & TEST ENDPOINTS
  // =========================================================================

  // 10. Get GitHub Dataset Config
  app.get('/api/datasets/github/config', (req, res) => {
    res.json({
      success: true,
      config: botConfig.githubSync || DEFAULT_GITHUB_SYNC
    });
  });

  // 11. Update GitHub Dataset Config
  app.post('/api/datasets/github/config', (req, res) => {
    try {
      const incoming = req.body;
      botConfig.githubSync = {
        ...DEFAULT_GITHUB_SYNC,
        ...(botConfig.githubSync || {}),
        ...incoming
      };
      saveBotConfig();
      res.json({
        success: true,
        message: 'Konfigurasi sinkronisasi GitHub berhasil disimpan.',
        config: botConfig.githubSync
      });
    } catch (err: any) {
      res.status(500).json({ success: false, message: `Gagal menyimpan konfigurasi: ${err.message}` });
    }
  });

  // 12. Test GitHub Dataset URL before downloading
  app.post('/api/datasets/github/test', async (req, res) => {
    try {
      const { url, githubToken } = req.body;
      const targetUrl = (url || botConfig.githubSync?.url || '').trim();

      if (!targetUrl) {
        return res.status(400).json({ success: false, message: 'URL GitHub dataset wajib diisi.' });
      }

      const testResult = await testGithubDataset(targetUrl, githubToken || botConfig.githubSync?.githubToken);

      // Update state
      if (!botConfig.githubSync) {
        botConfig.githubSync = { ...DEFAULT_GITHUB_SYNC };
      }
      botConfig.githubSync.url = targetUrl;
      botConfig.githubSync.rawUrl = testResult.rawUrl;
      botConfig.githubSync.lastTestedAt = new Date().toISOString();
      botConfig.githubSync.lastTestStatus = testResult.success ? 'success' : 'error';
      botConfig.githubSync.lastTestMessage = testResult.message;
      botConfig.githubSync.lastTestSizeFormatted = testResult.sizeFormatted;
      botConfig.githubSync.lastTestLinesPreview = testResult.previewLines;
      saveBotConfig();

      addLog('system', `Uji koneksi dataset GitHub: ${testResult.success ? 'BERHASIL' : 'GAGAL'} (${targetUrl})`);

      res.json({
        success: testResult.success,
        result: testResult
      });
    } catch (err: any) {
      res.status(500).json({ success: false, message: `Gagal menguji GitHub dataset: ${err.message}` });
    }
  });

  // 13. Sync / Download dataset from GitHub
  app.post('/api/datasets/github/sync', async (req, res) => {
    try {
      const { url, targetFilename, replacePrimary, githubToken } = req.body;
      const syncUrl = (url || botConfig.githubSync?.url || 'https://github.com/THEOYS123/track-call/blob/main/data/dataset.txt').trim();
      const filename = (targetFilename || botConfig.githubSync?.targetFilename || 'dataset.txt').trim();
      const isPrimary = replacePrimary !== undefined ? Boolean(replacePrimary) : (botConfig.githubSync?.replacePrimary ?? true);
      const token = githubToken || botConfig.githubSync?.githubToken;

      addLog('system', `Memulai sinkronisasi dataset dari GitHub: ${syncUrl} -> ${filename}`);

      const syncResult = await syncGithubDataset(syncUrl, filename, isPrimary, token);

      // Update state
      if (!botConfig.githubSync) {
        botConfig.githubSync = { ...DEFAULT_GITHUB_SYNC };
      }
      botConfig.githubSync.url = syncUrl;
      botConfig.githubSync.targetFilename = filename;
      botConfig.githubSync.replacePrimary = isPrimary;
      botConfig.githubSync.lastSyncedAt = new Date().toISOString();
      botConfig.githubSync.lastSyncStatus = 'success';
      botConfig.githubSync.lastSyncMessage = syncResult.message;
      botConfig.githubSync.lastSyncedBytes = syncResult.downloadedBytes;
      saveBotConfig();

      addLog('system', `Sinkronisasi GitHub selesai: ${syncResult.message}`);

      const files = await getAllDatasetFiles();
      res.json({
        success: true,
        message: syncResult.message,
        fileInfo: syncResult.fileInfo,
        files,
        githubSync: botConfig.githubSync
      });
    } catch (err: any) {
      if (botConfig.githubSync) {
        botConfig.githubSync.lastSyncStatus = 'error';
        botConfig.githubSync.lastSyncMessage = err.message;
        saveBotConfig();
      }
      addLog('error', `Gagal sinkronisasi dataset GitHub: ${err.message}`);
      res.status(500).json({ success: false, message: `Gagal sinkronisasi GitHub: ${err.message}` });
    }
  });

  // =========================================================================
  // TELEGRAM GROUP & ANTI-SPAM SETTINGS API
  // =========================================================================

  // 14. Get Group Config
  app.get('/api/groups/config', (req, res) => {
    res.json({
      success: true,
      config: botConfig.groupConfig || DEFAULT_GROUP_CONFIG
    });
  });

  // 15. Update Group Config
  app.post('/api/groups/config', (req, res) => {
    try {
      const incoming = req.body;
      botConfig.groupConfig = {
        ...DEFAULT_GROUP_CONFIG,
        ...(botConfig.groupConfig || {}),
        ...incoming,
        knownGroups: Array.isArray(incoming.knownGroups)
          ? incoming.knownGroups
          : (botConfig.groupConfig?.knownGroups || [])
      };
      saveBotConfig();
      addLog('system', `Pengaturan grup Telegram & anti-spam diperbarui.`);
      res.json({
        success: true,
        message: 'Pengaturan grup berhasil disimpan!',
        config: botConfig.groupConfig
      });
    } catch (err: any) {
      res.status(500).json({ success: false, message: `Gagal menyimpan konfigurasi grup: ${err.message}` });
    }
  });

  // 16. Toggle Group Feature (Allow Groups / Silent Fallback / Admin Only / Anti Flood)
  app.post('/api/groups/toggle', (req, res) => {
    try {
      const { setting, value } = req.body;
      if (!botConfig.groupConfig) {
        botConfig.groupConfig = { ...DEFAULT_GROUP_CONFIG };
      }

      if (setting in botConfig.groupConfig) {
        (botConfig.groupConfig as any)[setting] = Boolean(value);
        saveBotConfig();
        addLog('system', `Pengaturan grup ${setting} diubah menjadi: ${value}`);
        return res.json({ success: true, config: botConfig.groupConfig });
      }
      res.status(400).json({ success: false, message: 'Setting tidak valid.' });
    } catch (err: any) {
      res.status(500).json({ success: false, message: err.message });
    }
  });

  // 17. Block / Unblock Group ID
  app.post('/api/groups/block', (req, res) => {
    try {
      const { groupId, blocked } = req.body;
      const numId = Number(groupId);
      if (!numId) {
        return res.status(400).json({ success: false, message: 'Group ID tidak valid.' });
      }

      if (!botConfig.groupConfig) {
        botConfig.groupConfig = { ...DEFAULT_GROUP_CONFIG };
      }
      if (!Array.isArray(botConfig.groupConfig.blockedGroupIds)) {
        botConfig.groupConfig.blockedGroupIds = [];
      }

      if (blocked) {
        if (!botConfig.groupConfig.blockedGroupIds.includes(numId)) {
          botConfig.groupConfig.blockedGroupIds.push(numId);
        }
      } else {
        botConfig.groupConfig.blockedGroupIds = botConfig.groupConfig.blockedGroupIds.filter((id) => id !== numId);
      }

      // Update in knownGroups
      const matched = botConfig.groupConfig.knownGroups?.find((g) => g.id === numId);
      if (matched) {
        matched.status = blocked ? 'blocked' : 'active';
      }

      saveBotConfig();
      addLog('system', `Status blokir grup ID ${numId}: ${blocked ? 'DIBLOKIR' : 'DIIZINKAN'}`);

      res.json({
        success: true,
        message: `Grup ${numId} berhasil ${blocked ? 'diblokir' : 'diaktifkan kembali'}.`,
        config: botConfig.groupConfig
      });
    } catch (err: any) {
      res.status(500).json({ success: false, message: err.message });
    }
  });

  // 18. Whitelist / Remove from Whitelist Group ID
  app.post('/api/groups/whitelist', (req, res) => {
    try {
      const { groupId, whitelist } = req.body;
      const numId = Number(groupId);
      if (!numId) {
        return res.status(400).json({ success: false, message: 'Group ID tidak valid.' });
      }

      if (!botConfig.groupConfig) {
        botConfig.groupConfig = { ...DEFAULT_GROUP_CONFIG };
      }
      if (!Array.isArray(botConfig.groupConfig.allowedGroupIds)) {
        botConfig.groupConfig.allowedGroupIds = [];
      }

      if (whitelist) {
        if (!botConfig.groupConfig.allowedGroupIds.includes(numId)) {
          botConfig.groupConfig.allowedGroupIds.push(numId);
        }
      } else {
        botConfig.groupConfig.allowedGroupIds = botConfig.groupConfig.allowedGroupIds.filter((id) => id !== numId);
      }

      saveBotConfig();
      addLog('system', `Whitelist grup ID ${numId}: ${whitelist ? 'DITAMBAHKAN' : 'DIHAPUS'}`);

      res.json({
        success: true,
        message: `Grup ${numId} ${whitelist ? 'ditambahkan ke' : 'dihapus dari'} whitelist.`,
        config: botConfig.groupConfig
      });
    } catch (err: any) {
      res.status(500).json({ success: false, message: err.message });
    }
  });

  // 19. Remove known group from list
  app.delete('/api/groups/:groupId', (req, res) => {
    try {
      const numId = Number(req.params.groupId);
      if (botConfig.groupConfig && Array.isArray(botConfig.groupConfig.knownGroups)) {
        botConfig.groupConfig.knownGroups = botConfig.groupConfig.knownGroups.filter((g) => g.id !== numId);
        saveBotConfig();
      }
      res.json({ success: true, message: 'Grup dihapus dari daftar.', config: botConfig.groupConfig });
    } catch (err: any) {
      res.status(500).json({ success: false, message: err.message });
    }
  });

  // =========================================================================
  // BOT QUOTA & CLAIM CONFIGURATION API
  // =========================================================================
  app.get('/api/bot/quota-config', (req, res) => {
    res.json({
      success: true,
      config: botConfig.quotaConfig || DEFAULT_QUOTA_CONFIG
    });
  });

  app.post('/api/bot/quota-config', (req, res) => {
    try {
      const incoming = req.body;
      botConfig.quotaConfig = {
        ...DEFAULT_QUOTA_CONFIG,
        ...(botConfig.quotaConfig || {}),
        ...incoming
      };
      saveBotConfig();
      addLog('system', `Konfigurasi kuota & klaim bot diperbarui.`);
      res.json({
        success: true,
        message: 'Pengaturan kuota & klaim berhasil disimpan!',
        config: botConfig.quotaConfig
      });
    } catch (err: any) {
      res.status(500).json({ success: false, message: `Gagal menyimpan konfigurasi kuota: ${err.message}` });
    }
  });

  // Admin reset quota claim flags for a user
  app.post('/api/bot/quota/reset-claims', (req, res) => {
    try {
      const { userId, resetNewUser, resetDaily } = req.body;
      const numId = Number(userId);
      const user = botConfig.activeUsers.find(
        (u) => (u.userId && Number(u.userId) === numId) || Number(u.chatId) === numId
      );
      if (!user) {
        return res.status(404).json({ success: false, message: 'Pengguna tidak ditemukan.' });
      }
      if (resetNewUser) {
        user.hasClaimedNewUserQuota = false;
        user.newUserQuotaClaimedAt = undefined;
      }
      if (resetDaily) {
        user.dailyQuotaLastClaimedDate = undefined;
        user.dailyQuotaLastClaimedAt = undefined;
      }
      saveBotConfig();
      addLog('system', `Status klaim kuota pengguna ${numId} direset oleh Admin.`);
      res.json({ success: true, message: `Status klaim untuk ${user.firstName} berhasil direset.`, user });
    } catch (err: any) {
      res.status(500).json({ success: false, message: err.message });
    }
  });

  // =========================================================================
  // BOT MENU CONFIGURATION API
  // =========================================================================
  app.get('/api/bot/menu-config', (req, res) => {
    res.json({
      success: true,
      config: botConfig.menuConfig || DEFAULT_MENU_CONFIG
    });
  });

  app.post('/api/bot/menu-config', (req, res) => {
    try {
      const incoming = req.body;
      botConfig.menuConfig = {
        ...DEFAULT_MENU_CONFIG,
        ...(botConfig.menuConfig || {}),
        ...incoming,
        customButtons: Array.isArray(incoming.customButtons)
          ? incoming.customButtons
          : (botConfig.menuConfig?.customButtons || [])
      };
      saveBotConfig();
      addLog('system', `Konfigurasi tampilan menu bot diperbarui.`);
      res.json({
        success: true,
        message: 'Pengaturan menu bot berhasil disimpan!',
        config: botConfig.menuConfig
      });
    } catch (err: any) {
      res.status(500).json({ success: false, message: `Gagal menyimpan konfigurasi menu: ${err.message}` });
    }
  });

  // =========================================================================
  // CONTENT MODERATION & AUTO-DELETE CONFIGURATION API
  // =========================================================================
  app.get('/api/moderation/config', (req, res) => {
    res.json({
      success: true,
      config: botConfig.moderationConfig || DEFAULT_MODERATION_CONFIG
    });
  });

  app.post('/api/moderation/config', (req, res) => {
    try {
      const incoming = req.body;
      botConfig.moderationConfig = {
        ...DEFAULT_MODERATION_CONFIG,
        ...(botConfig.moderationConfig || {}),
        ...incoming,
        cyberWhitelistKeywords: Array.isArray(incoming.cyberWhitelistKeywords)
          ? incoming.cyberWhitelistKeywords
          : (botConfig.moderationConfig?.cyberWhitelistKeywords || DEFAULT_MODERATION_CONFIG.cyberWhitelistKeywords),
        customBannedKeywords: Array.isArray(incoming.customBannedKeywords)
          ? incoming.customBannedKeywords
          : (botConfig.moderationConfig?.customBannedKeywords || []),
        whitelistKeywords: Array.isArray(incoming.whitelistKeywords)
          ? incoming.whitelistKeywords
          : (botConfig.moderationConfig?.whitelistKeywords || []),
        recentIncidents: Array.isArray(botConfig.moderationConfig?.recentIncidents)
          ? botConfig.moderationConfig.recentIncidents
          : []
      };
      saveBotConfig();
      addLog('system', `Pengaturan sistem moderasi konten & auto-delete diperbarui.`);
      res.json({
        success: true,
        message: 'Pengaturan moderasi & auto-delete berhasil disimpan!',
        config: botConfig.moderationConfig
      });
    } catch (err: any) {
      res.status(500).json({ success: false, message: `Gagal menyimpan konfigurasi moderasi: ${err.message}` });
    }
  });

  // Test moderation rule with sample message text
  app.post('/api/moderation/test', (req, res) => {
    try {
      const { text } = req.body;
      if (!text || typeof text !== 'string') {
        return res.status(400).json({ success: false, message: 'Teks pesan uji coba wajib diisi.' });
      }
      const result = checkMessageModeration(text);
      res.json({
        success: true,
        text,
        result
      });
    } catch (err: any) {
      res.status(500).json({ success: false, message: err.message });
    }
  });

  // Clear moderation incident history
  app.post('/api/moderation/clear-incidents', (req, res) => {
    try {
      if (botConfig.moderationConfig) {
        botConfig.moderationConfig.recentIncidents = [];
        saveBotConfig();
      }
      res.json({
        success: true,
        message: 'Riwayat insiden pesan terlarang berhasil dibersihkan.'
      });
    } catch (err: any) {
      res.status(500).json({ success: false, message: err.message });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Telegram Bot Controller server running on http://localhost:${PORT}`);

    // If bot was previously active when server restarted, automatically resume it!
    if (botConfig.isActive && botConfig.token) {
      console.log('[Telegram Bot] Resuming bot from saved state (Always ON)...');
      verifyTelegramToken(botConfig.token)
        .then((res) => {
          if (res.valid && res.botInfo) {
            currentBotInfo = res.botInfo;
            botStartedAt = Date.now();
            runTelegramPollingLoop().catch((loopErr) => {
              console.error('[Telegram Polling] Loop startup error:', loopErr);
            });
          } else {
            console.warn('[Telegram Bot] Saved token failed validation upon resume:', res.errorMessage);
            botConfig.isActive = false;
            saveBotConfig();
          }
        })
        .catch((err) => {
          console.error('[Telegram Bot] Error during token verification on resume:', err);
        });
    }
  });
}

startServer();
