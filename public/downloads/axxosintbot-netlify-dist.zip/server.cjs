var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// server.ts
var import_express = __toESM(require("express"), 1);
var import_path2 = __toESM(require("path"), 1);
var import_fs2 = __toESM(require("fs"), 1);
var import_multer = __toESM(require("multer"), 1);
var import_module = require("module");
var import_vite = require("vite");

// src/types.ts
var DEFAULT_REFERRAL_CONFIG = {
  enabled: true,
  quotaPerInvite: 1,
  allowInstantWithdraw: true,
  minWithdrawAmount: 1,
  notifyInviterOnRegister: true
};
var DEFAULT_QUOTA_PACKAGES = [
  {
    id: "quota_basic",
    name: "Paket Hemat OSINT",
    quotaAmount: 10,
    price: "Rp 15.000",
    description: "10x Kuota Pencarian Intelijen NIK & Kependudukan",
    badge: "Pemula"
  },
  {
    id: "quota_pro",
    name: "Paket Pro Intelijen",
    quotaAmount: 50,
    price: "Rp 50.000",
    description: "50x Kuota Pencarian Deep OSINT & Trace Nomor Telepon",
    badge: "Paling Laris",
    isPopular: true
  },
  {
    id: "quota_ultra",
    name: "Paket Ultra Unlimited",
    quotaAmount: 200,
    price: "Rp 150.000",
    description: "200x Kuota Pencarian Prioritas Tanpa Antrian Cooldown",
    badge: "Investigator"
  }
];
var DEFAULT_STRICT_BANNED_KEYWORDS = [
  // 18+ / Pornografi / VCS / Prostitusi / Pelecehan
  "bokep",
  "b0kep",
  "porn",
  "porno",
  "pornografi",
  "18+",
  "vcs",
  "open bo",
  "bo cod",
  "pap tt",
  "pap bugil",
  "pap toket",
  "pap memek",
  "pap nude",
  "pap bug1l",
  "desah",
  "sange",
  "sangean",
  "bugil",
  "toket",
  "croot",
  "crot",
  "prostitusi",
  "becek",
  "mesum",
  "seks",
  "sex gratis",
  "masturbasi",
  "ngentot",
  "memek",
  "kontol",
  "jav sub",
  "onlyfans bocor",
  "video mesum",
  "doodstream",
  "terabox bokep",
  "vcs murah",
  "pepek",
  "ngocok",
  "lonte",
  "perek",
  "tetek",
  "colmek",
  "colik",
  "hentai",
  "bokep viral",
  "lendir",
  "bacol",
  "bahan coli",
  "cewek sange",
  "michat bo",
  "bo include",
  "cs mesum",
  "videy",
  "lulustream",
  "gofile bokep",
  "dildo",
  "kondom",
  "blowjob",
  "ngocok kontol",
  "hisap toket",
  "remas toket",
  "sex chat",
  "pedofil",
  "child porn",
  "lolicon",
  "shotacon",
  "incest",
  "ngaceng",
  "cairan mani",
  "sperma",
  "psk",
  "mucikari",
  "germo",
  "tante girang",
  "pelacur",
  "sundal",
  "jablay",
  "kimcil",
  "cabe cabean",
  "skandal selebgram",
  "kebaya merah",
  "chindo viral",
  "video syur",
  "doodla",
  "doodli",
  "terabox",
  // Judi Online / Slot / Togel / Kasino
  "slot",
  "sl0t",
  "judol",
  "judi online",
  "judi bola",
  "gacor",
  "scatter",
  "maxwin",
  "pragmatic",
  "zeus slot",
  "kakek zeus",
  "olympus",
  "sweet bonanza",
  "mahjong ways",
  "bandar togel",
  "togel online",
  "toto gelap",
  "togel sgp",
  "togel hk",
  "toto macau",
  "casino online",
  "live casino",
  "sbobet",
  "agen judi",
  "daftar slot",
  "link slot",
  "link gacor",
  "situs slot",
  "situs judi",
  "depo pulsa",
  "depo 10k",
  "depo 25k",
  "depo 50k",
  "wd kilat",
  "freebet",
  "bocoran slot",
  "pola gacor",
  "jackpot slot",
  "slot88",
  "slot777",
  "rtp slot",
  "rtp live",
  "rolet online",
  "baccarat online",
  "domino qiu",
  "judi slot",
  "agen slot",
  "situs gacor",
  "menang slot",
  "gates of olympus",
  "starlight princess",
  "spxslot",
  "mposlot",
  "hoki slot",
  "sensational slot",
  "pola slot",
  "cheat slot",
  "scatter hitam",
  "chip domino",
  "chip higgs",
  "anti rungkat",
  "anti rungkad",
  "garansi kekalahan",
  "bonus new member",
  // Narkoba / Obat Terlarang / Psikotropika
  "narkoba",
  "sabu",
  "sabu-sabu",
  "ekstasi",
  "inex",
  "inek",
  "ganja",
  "tembakau gorila",
  "tembakau sintetis",
  "sinte",
  "pil koplo",
  "tramadol",
  "trihex",
  "alprazolam",
  "dumolid",
  "kokain",
  "heroin",
  "psikotropika",
  "jual sabu",
  "beli ganja",
  "bong sabu",
  "shabu",
  "obat keras daftar g",
  "narkotika",
  "methamphetamine",
  "amfetamin",
  "hexymer",
  "riklona",
  "calmlet",
  "zypraz",
  "putaw",
  "bong kaca",
  "pahe sabu",
  // Penipuan / Phishing / Scam / Pinjol Ilegal
  "pinjol ilegal",
  "pengganda uang",
  "pesugihan uang gaib",
  "dana kaget palsu",
  "jasa gestun ilegal",
  "jasa hack saldo dana",
  "apk pembobol rekening",
  "saldo dana gratis tipu",
  "jual beli rekening",
  "rekening penampung",
  "jual akun e-wallet bodong",
  "arisan bodong",
  "investasi bodong",
  "kloning atm",
  "joki pinjol",
  "surat tilang apk",
  "undangan pernikahan apk",
  "jual uang palsu",
  "upal",
  // Senjata Ilegal & Peledak
  "jual senpi",
  "senjata api rakitan",
  "jual celurit begal",
  "bom ikan",
  "bahan peledak rakitan",
  "jual pistol rakitan",
  "senjata tajam tawuran",
  "celurit corbek"
];
var DEFAULT_RENTAL_PLANS = [
  {
    id: "starter",
    name: "Paket Starter Dedicated",
    duration: "30 Hari (1 Bulan)",
    price: "Rp 50.000",
    description: "Cocok untuk penggunaan pribadi atau grup komunitas kecil dengan bot branding sendiri.",
    features: [
      "1 Dedicated Bot Telegram (Username & Avatar milik Anda)",
      "Akses Penuh Database Intelijen OSINT & NIK Nasional",
      "Hosting Server 24/7 Uptime (Tanpa Perlu Sewa VPS)",
      "Sistem Kuota Gratis & Manajemen Pengguna Otomatis",
      "Fitur Anti-Spam & Moderasi Grup Bawaan"
    ]
  },
  {
    id: "pro",
    name: "Paket Pro VIP Cluster",
    duration: "90 Hari (3 Bulan)",
    price: "Rp 125.000",
    description: "Pilihan paling hemat & populer! Fitur terlengkap dengan performa pencarian prioritas.",
    features: [
      "Semua fitur Paket Starter",
      "Kustomisasi Pesan Sambutan & Menu Interaktif Bebas",
      "Jalur Proxy Pencarian Prioritas (Super Cepat)",
      "Bebas pasang Watermark Brand Komunitas Anda",
      "Koneksi Multi-Bot Cluster & Backup Server Otomatis",
      "Admin Bot Mendapatkan Akses Unlimited"
    ],
    isPopular: true
  },
  {
    id: "lifetime",
    name: "Paket Lifetime / Permanen",
    duration: "Permanen (Sekali Bayar)",
    price: "Rp 250.000",
    description: "Investasi sekali bayar aktif selamanya tanpa biaya perpanjangan bulanan.",
    features: [
      "Semua fitur Paket Pro VIP",
      "Aktivasi Bot Selamanya (Tanpa Biaya Bulanan)",
      "Update Dataset Otomatis saat ada Kebocoran Data Baru",
      "Dukungan Teknis & Maintenance Prioritas Langsung dari Ax.",
      "API & Webhook Integrasi Bebas untuk Channel/Grup"
    ]
  }
];

// src/utils/nikAnalyzer.ts
var PROVINCES = {
  "11": "Aceh",
  "12": "Sumatera Utara",
  "13": "Sumatera Barat",
  "14": "Riau",
  "15": "Jambi",
  "16": "Sumatera Selatan",
  "17": "Bengkulu",
  "18": "Lampung",
  "19": "Kepulauan Bangka Belitung",
  "21": "Kepulauan Riau",
  "31": "DKI Jakarta",
  "32": "Jawa Barat",
  "33": "Jawa Tengah",
  "34": "DI Yogyakarta",
  "35": "Jawa Timur",
  "36": "Banten",
  "51": "Bali",
  "52": "Nusa Tenggara Barat",
  "53": "Nusa Tenggara Timur",
  "61": "Kalimantan Barat",
  "62": "Kalimantan Tengah",
  "63": "Kalimantan Selatan",
  "64": "Kalimantan Timur",
  "65": "Kalimantan Utara",
  "71": "Sulawesi Utara",
  "72": "Sulawesi Tengah",
  "73": "Sulawesi Selatan",
  "74": "Sulawesi Tenggara",
  "75": "Gorontalo",
  "76": "Sulawesi Barat",
  "81": "Maluku",
  "82": "Maluku Utara",
  "91": "Papua Barat",
  "92": "Papua Barat Daya",
  "93": "Papua Selatan",
  "94": "Papua",
  "95": "Papua Tengah",
  "96": "Papua Pegunungan"
};
var REGENCIES = {
  // DKI Jakarta
  "3171": "Kota Administrasi Jakarta Pusat",
  "3172": "Kota Administrasi Jakarta Utara",
  "3173": "Kota Administrasi Jakarta Barat",
  "3174": "Kota Administrasi Jakarta Selatan",
  "3175": "Kota Administrasi Jakarta Timur",
  "3101": "Kabupaten Administrasi Kepulauan Seribu",
  // Jawa Barat
  "3201": "Kabupaten Bogor",
  "3202": "Kabupaten Sukabumi",
  "3203": "Kabupaten Cianjur",
  "3204": "Kabupaten Bandung",
  "3205": "Kabupaten Garut",
  "3206": "Kabupaten Tasikmalaya",
  "3207": "Kabupaten Ciamis",
  "3208": "Kabupaten Kuningan",
  "3209": "Kabupaten Cirebon",
  "3210": "Kabupaten Majalengka",
  "3211": "Kabupaten Sumedang",
  "3212": "Kabupaten Indramayu",
  "3213": "Kabupaten Subang",
  "3214": "Kabupaten Purwakarta",
  "3215": "Kabupaten Karawang",
  "3216": "Kabupaten Bekasi",
  "3217": "Kabupaten Bandung Barat",
  "3218": "Kabupaten Pangandaran",
  "3271": "Kota Bogor",
  "3272": "Kota Sukabumi",
  "3273": "Kota Bandung",
  "3274": "Kota Cirebon",
  "3275": "Kota Bekasi",
  "3276": "Kota Depok",
  "3277": "Kota Cimahi",
  "3278": "Kota Tasikmalaya",
  "3279": "Kota Banjar",
  // Banten
  "3601": "Kabupaten Pandeglang",
  "3602": "Kabupaten Lebak",
  "3603": "Kabupaten Tangerang",
  "3604": "Kabupaten Serang",
  "3671": "Kota Tangerang",
  "3672": "Kota Cilegon",
  "3673": "Kota Serang",
  "3674": "Kota Tangerang Selatan",
  // Jawa Tengah
  "3301": "Kabupaten Cilacap",
  "3302": "Kabupaten Banyumas",
  "3303": "Kabupaten Purbalingga",
  "3304": "Kabupaten Banjarnegara",
  "3305": "Kabupaten Kebumen",
  "3306": "Kabupaten Purworejo",
  "3307": "Kabupaten Wonosobo",
  "3308": "Kabupaten Magelang",
  "3309": "Kabupaten Boyolali",
  "3310": "Kabupaten Klaten",
  "3311": "Kabupaten Sukoharjo",
  "3312": "Kabupaten Wonogiri",
  "3313": "Kabupaten Karanganyar",
  "3314": "Kabupaten Sragen",
  "3315": "Kabupaten Grobogan",
  "3316": "Kabupaten Blora",
  "3317": "Kabupaten Rembang",
  "3318": "Kabupaten Pati",
  "3319": "Kabupaten Kudus",
  "3320": "Kabupaten Jepara",
  "3321": "Kabupaten Demak",
  "3322": "Kabupaten Semarang",
  "3323": "Kabupaten Temanggung",
  "3324": "Kabupaten Kendal",
  "3325": "Kabupaten Batang",
  "3326": "Kabupaten Pekalongan",
  "3327": "Kabupaten Pemalang",
  "3328": "Kabupaten Tegal",
  "3329": "Kabupaten Brebes",
  "3371": "Kota Magelang",
  "3372": "Kota Surakarta (Solo)",
  "3373": "Kota Salatiga",
  "3374": "Kota Semarang",
  "3375": "Kota Pekalongan",
  "3376": "Kota Tegal",
  // DI Yogyakarta
  "3401": "Kabupaten Kulon Progo",
  "3402": "Kabupaten Bantul",
  "3403": "Kabupaten Gunungkidul",
  "3404": "Kabupaten Sleman",
  "3471": "Kota Yogyakarta",
  // Jawa Timur
  "3501": "Kabupaten Pacitan",
  "3502": "Kabupaten Ponorogo",
  "3503": "Kabupaten Trenggalek",
  "3504": "Kabupaten Tulungagung",
  "3505": "Kabupaten Blitar",
  "3506": "Kabupaten Kediri",
  "3507": "Kabupaten Malang",
  "3508": "Kabupaten Lumajang",
  "3509": "Kabupaten Jember",
  "3510": "Kabupaten Banyuwangi",
  "3511": "Kabupaten Bondowoso",
  "3512": "Kabupaten Situbondo",
  "3513": "Kabupaten Probolinggo",
  "3514": "Kabupaten Pasuruan",
  "3515": "Kabupaten Sidoarjo",
  "3516": "Kabupaten Mojokerto",
  "3517": "Kabupaten Jombang",
  "3518": "Kabupaten Nganjuk",
  "3519": "Kabupaten Madiun",
  "3520": "Kabupaten Magetan",
  "3521": "Kabupaten Ngawi",
  "3522": "Kabupaten Bojonegoro",
  "3523": "Kabupaten Tuban",
  "3524": "Kabupaten Lamongan",
  "3525": "Kabupaten Gresik",
  "3526": "Kabupaten Bangkalan",
  "3527": "Kabupaten Sampang",
  "3528": "Kabupaten Pamekasan",
  "3529": "Kabupaten Sumenep",
  "3571": "Kota Kediri",
  "3572": "Kota Blitar",
  "3573": "Kota Malang",
  "3574": "Kota Probolinggo",
  "3575": "Kota Pasuruan",
  "3576": "Kota Mojokerto",
  "3577": "Kota Madiun",
  "3578": "Kota Surabaya",
  "3579": "Kota Batu",
  // Sumatera Utara
  "1201": "Kabupaten Nias",
  "1202": "Kabupaten Mandailing Natal",
  "1203": "Kabupaten Tapanuli Selatan",
  "1204": "Kabupaten Tapanuli Tengah",
  "1205": "Kabupaten Tapanuli Utara",
  "1206": "Kabupaten Toba Samosir",
  "1207": "Kabupaten Labuhanbatu",
  "1208": "Kabupaten Asahan",
  "1209": "Kabupaten Simalungun",
  "1210": "Kabupaten Dairi",
  "1211": "Kabupaten Karo",
  "1212": "Kabupaten Deli Serdang",
  "1213": "Kabupaten Langkat",
  "1271": "Kota Medan",
  "1272": "Kota Pematangsiantar",
  "1273": "Kota Sibolga",
  "1274": "Kota Tanjungbalai",
  "1275": "Kota Binjai",
  "1276": "Kota Tebing Tinggi",
  "1277": "Kota Padang Sidempuan",
  "1278": "Kota Gunungsitoli",
  // Sumatera Barat
  "1371": "Kota Padang",
  "1375": "Kota Bukittinggi",
  // Riau & Kepri
  "1471": "Kota Pekanbaru",
  "1472": "Kota Dumai",
  "2171": "Kota Batam",
  "2172": "Kota Tanjung Pinang",
  // Sumatera Selatan & Lampung
  "1671": "Kota Palembang",
  "1871": "Kota Bandar Lampung",
  // Bali & Nusa Tenggara
  "5171": "Kota Denpasar",
  "5103": "Kabupaten Badung",
  "5104": "Kabupaten Gianyar",
  "5271": "Kota Mataram",
  "5371": "Kota Kupang",
  // Kalimantan
  "6171": "Kota Pontianak",
  "6271": "Kota Palangka Raya",
  "6371": "Kota Banjarmasin",
  "6471": "Kota Balikpapan",
  "6472": "Kota Samarinda",
  // Sulawesi
  "7171": "Kota Manado",
  "7271": "Kota Palu",
  "7371": "Kota Makassar"
};
function analyzeNIK(rawNik) {
  const clean = rawNik.replace(/\D/g, "");
  if (clean.length !== 16) {
    return {
      valid: false,
      nik: rawNik,
      provinceCode: "",
      provinceName: "Format Tidak Valid (Wajib 16 digit)",
      regencyCode: "",
      regencyName: "Tidak Diketahui",
      districtCode: "",
      birthDate: "-",
      gender: "male",
      age: 0,
      sequenceNumber: "",
      formatCorrect: false,
      rawDetails: "NIK tidak memenuhi standar 16 digit Kementerian Dalam Negeri RI"
    };
  }
  const provCode = clean.substring(0, 2);
  const regCode = clean.substring(0, 4);
  const distCode = clean.substring(4, 6);
  const rawDayStr = clean.substring(6, 8);
  const rawMonthStr = clean.substring(8, 10);
  const rawYearStr = clean.substring(10, 12);
  const seqNumber = clean.substring(12, 16);
  const rawDay = parseInt(rawDayStr, 10);
  const rawMonth = parseInt(rawMonthStr, 10);
  let birthYearShort = parseInt(rawYearStr, 10);
  let isFemale = false;
  let actualDay = rawDay;
  if (rawDay > 40) {
    isFemale = true;
    actualDay = rawDay - 40;
  }
  const fullYear = birthYearShort > 26 ? 1900 + birthYearShort : 2e3 + birthYearShort;
  const currentYear = (/* @__PURE__ */ new Date()).getFullYear();
  const calculatedAge = currentYear - fullYear;
  const paddedDay = actualDay.toString().padStart(2, "0");
  const paddedMonth = rawMonth.toString().padStart(2, "0");
  const formattedBirthDate = `${fullYear}-${paddedMonth}-${paddedDay}`;
  const provinceName = PROVINCES[provCode] || `Provinsi ID-${provCode}`;
  const regencyName = REGENCIES[regCode] || `Kab/Kota ID-${regCode}`;
  return {
    valid: true,
    nik: clean,
    provinceCode: provCode,
    provinceName,
    regencyCode: regCode,
    regencyName,
    districtCode: distCode,
    birthDate: formattedBirthDate,
    gender: isFemale ? "female" : "male",
    age: Math.max(0, calculatedAge),
    sequenceNumber: seqNumber,
    formatCorrect: true,
    rawDetails: `${provinceName} -> ${regencyName}, Lahir ${paddedDay}/${paddedMonth}/${fullYear}, Jenis Kelamin: ${isFemale ? "Perempuan" : "Laki-laki"}`
  };
}
function extractLocationFromNik(rawNik) {
  if (!rawNik) return "(-)";
  const clean = rawNik.replace(/\D/g, "");
  if (clean.length !== 16) return "(-)";
  const analysis = analyzeNIK(clean);
  if (!analysis.valid) return "(-)";
  const reg = analysis.regencyName;
  const prov = analysis.provinceName;
  if (reg && prov && !reg.includes("Tidak Diketahui") && !prov.includes("Tidak Valid")) {
    return `${reg}, ${prov}`;
  }
  if (prov && !prov.includes("Tidak Valid")) {
    return prov;
  }
  return "(-)";
}

// src/server/datasetEngine.ts
var import_fs = __toESM(require("fs"), 1);
var import_path = __toESM(require("path"), 1);
var import_readline = __toESM(require("readline"), 1);
var import_stream = require("stream");
var import_promises = require("stream/promises");
var DATA_DIR = import_path.default.join(process.cwd(), "data");
var DEFAULT_DATASET_FILE = import_path.default.join(DATA_DIR, "dataset.txt");
var DATASETS_DIR = import_path.default.join(DATA_DIR, "datasets");
if (!import_fs.default.existsSync(DATA_DIR)) {
  import_fs.default.mkdirSync(DATA_DIR, { recursive: true });
}
if (!import_fs.default.existsSync(DATASETS_DIR)) {
  import_fs.default.mkdirSync(DATASETS_DIR, { recursive: true });
}
function formatBytes(bytes) {
  if (bytes === 0) return "0 B";
  const k = 1024;
  const sizes = ["B", "KB", "MB", "GB", "TB"];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return `${parseFloat((bytes / Math.pow(k, i)).toFixed(2))} ${sizes[i]}`;
}
async function countLines(filePath) {
  return new Promise((resolve) => {
    if (!import_fs.default.existsSync(filePath)) return resolve(0);
    let count = 0;
    const rl = import_readline.default.createInterface({
      input: import_fs.default.createReadStream(filePath),
      crlfDelay: Infinity
    });
    rl.on("line", () => {
      count++;
    });
    rl.on("close", () => {
      resolve(count);
    });
    rl.on("error", () => {
      resolve(count);
    });
  });
}
async function getAllDatasetFiles() {
  const result = [];
  const processedNames = /* @__PURE__ */ new Set();
  if (!import_fs.default.existsSync(DATA_DIR)) {
    import_fs.default.mkdirSync(DATA_DIR, { recursive: true });
  }
  if (!import_fs.default.existsSync(DATASETS_DIR)) {
    import_fs.default.mkdirSync(DATASETS_DIR, { recursive: true });
  }
  if (import_fs.default.existsSync(DEFAULT_DATASET_FILE)) {
    try {
      const stats = import_fs.default.statSync(DEFAULT_DATASET_FILE);
      const lines = await countLines(DEFAULT_DATASET_FILE);
      result.push({
        name: "dataset.txt",
        filename: "dataset.txt",
        path: DEFAULT_DATASET_FILE,
        sizeBytes: stats.size,
        size: stats.size,
        sizeFormatted: formatBytes(stats.size),
        linesCount: lines,
        lineCount: lines,
        lastModified: stats.mtime.toISOString(),
        isDefaultDataset: true,
        isDefault: true
      });
      processedNames.add("dataset.txt");
    } catch (e) {
      console.error("Error reading default dataset.txt stats:", e);
    }
  }
  if (import_fs.default.existsSync(DATASETS_DIR)) {
    try {
      const files = import_fs.default.readdirSync(DATASETS_DIR);
      for (const file of files) {
        if (file.startsWith(".") || file === "dataset.txt" && processedNames.has("dataset.txt")) {
          continue;
        }
        const fullPath = import_path.default.join(DATASETS_DIR, file);
        try {
          const stats = import_fs.default.statSync(fullPath);
          if (stats.isFile()) {
            const lines = await countLines(fullPath);
            const isDef = file.toLowerCase() === "dataset.txt";
            result.push({
              name: file,
              filename: file,
              path: fullPath,
              sizeBytes: stats.size,
              size: stats.size,
              sizeFormatted: formatBytes(stats.size),
              linesCount: lines,
              lineCount: lines,
              lastModified: stats.mtime.toISOString(),
              isDefaultDataset: isDef,
              isDefault: isDef
            });
            processedNames.add(file);
          }
        } catch (fileErr) {
          console.error(`Error reading dataset file ${file}:`, fileErr);
        }
      }
    } catch (dirErr) {
      console.error("Error scanning datasets directory:", dirErr);
    }
  }
  const systemFiles = /* @__PURE__ */ new Set([
    "bot_config.json",
    "codes.json",
    "secret_codes.json",
    "visitors.txt",
    "visitor_count.txt"
  ]);
  try {
    const rootDataFiles = import_fs.default.readdirSync(DATA_DIR);
    for (const file of rootDataFiles) {
      if (systemFiles.has(file) || processedNames.has(file) || file.startsWith(".") || file === "datasets") {
        continue;
      }
      const fullPath = import_path.default.join(DATA_DIR, file);
      try {
        const stats = import_fs.default.statSync(fullPath);
        if (stats.isFile() && (file.endsWith(".txt") || file.endsWith(".csv") || file.endsWith(".json") || file.endsWith(".tsv") || file.endsWith(".log"))) {
          const lines = await countLines(fullPath);
          const isDef = file.toLowerCase() === "dataset.txt";
          result.push({
            name: file,
            filename: file,
            path: fullPath,
            sizeBytes: stats.size,
            size: stats.size,
            sizeFormatted: formatBytes(stats.size),
            linesCount: lines,
            lineCount: lines,
            lastModified: stats.mtime.toISOString(),
            isDefaultDataset: isDef,
            isDefault: isDef
          });
          processedNames.add(file);
        }
      } catch {
      }
    }
  } catch {
  }
  result.sort((a, b) => {
    if (a.isDefaultDataset) return -1;
    if (b.isDefaultDataset) return 1;
    return a.name.localeCompare(b.name);
  });
  return result;
}
function sanitizeDatasetFilename(raw) {
  if (!raw) return "dataset.txt";
  const clean = raw.replace(/\\/g, "/");
  let base = import_path.default.basename(clean);
  base = base.replace(/^[\/\._]+/, "");
  base = base.replace(/[^a-zA-Z0-9._-]/g, "_");
  if (!base) base = "dataset.txt";
  if (!import_path.default.extname(base)) {
    base = `${base}.txt`;
  }
  return base;
}
async function readDatasetContent(filename, maxLines = 5e3) {
  const baseName = sanitizeDatasetFilename(filename);
  let targetPath = import_path.default.join(DATASETS_DIR, baseName);
  if (!import_fs.default.existsSync(targetPath)) {
    targetPath = import_path.default.join(DATA_DIR, baseName);
  }
  if (!import_fs.default.existsSync(targetPath) && baseName.toLowerCase() === "dataset.txt") {
    targetPath = DEFAULT_DATASET_FILE;
  }
  if (!import_fs.default.existsSync(targetPath)) {
    throw new Error(`File dataset '${baseName}' tidak ditemukan di sistem.`);
  }
  const stats = import_fs.default.statSync(targetPath);
  const lines = [];
  let totalLines = 0;
  let isTruncated = false;
  const rl = import_readline.default.createInterface({
    input: import_fs.default.createReadStream(targetPath, { encoding: "utf8" }),
    crlfDelay: Infinity
  });
  for await (const line of rl) {
    totalLines++;
    if (lines.length < maxLines) {
      lines.push(line);
    } else {
      isTruncated = true;
    }
  }
  return {
    filename: baseName,
    content: lines.join("\n"),
    totalLines,
    isTruncated,
    sizeBytes: stats.size
  };
}
var FORBIDDEN_DATASET_NAMES = /* @__PURE__ */ new Set([
  "bot_config.json",
  "codes.json",
  "secret_codes.json",
  "visitors.txt",
  "visitor_count.txt",
  "package.json",
  "tsconfig.json",
  "server.ts"
]);
function isForbiddenDatasetName(filename) {
  const lower = import_path.default.basename(filename).toLowerCase();
  return FORBIDDEN_DATASET_NAMES.has(lower);
}
async function writeDatasetContent(filename, content) {
  if (!import_fs.default.existsSync(DATASETS_DIR)) {
    import_fs.default.mkdirSync(DATASETS_DIR, { recursive: true });
  }
  const baseName = sanitizeDatasetFilename(filename);
  if (isForbiddenDatasetName(baseName)) {
    throw new Error(`Nama berkas '${baseName}' adalah berkas sistem internal dan tidak dapat diubah sebagai dataset.`);
  }
  let targetPath = import_path.default.join(DATASETS_DIR, baseName);
  if (baseName.toLowerCase() === "dataset.txt") {
    targetPath = DEFAULT_DATASET_FILE;
    try {
      import_fs.default.writeFileSync(import_path.default.join(DATASETS_DIR, "dataset.txt"), content, "utf8");
    } catch {
    }
  }
  import_fs.default.writeFileSync(targetPath, content, "utf8");
  const stats = import_fs.default.statSync(targetPath);
  const lines = await countLines(targetPath);
  return {
    success: true,
    sizeBytes: stats.size,
    linesCount: lines,
    path: targetPath
  };
}
async function deleteDatasetFile(filename) {
  const baseName = sanitizeDatasetFilename(filename);
  if (isForbiddenDatasetName(baseName)) {
    throw new Error(`Nama berkas '${baseName}' adalah berkas sistem dan tidak dapat dihapus.`);
  }
  let deletedAny = false;
  const path1 = import_path.default.join(DATASETS_DIR, baseName);
  if (import_fs.default.existsSync(path1)) {
    if (baseName.toLowerCase() === "dataset.txt") {
      import_fs.default.writeFileSync(
        path1,
        `# OSINT INTEL DATABASE ARCHIVE - INDONESIA DATASET
# FORMAT: NIK|FULL_NAME|BIRTH_DATE|GENDER|AGE|CITY|PROVINCE|ADDRESS|PHONE|EMAIL|OCCUPATION|THREAT_LEVEL|SOURCE_DATASET|LAST_ACTIVITY|NOTES
`,
        "utf8"
      );
    } else {
      import_fs.default.unlinkSync(path1);
    }
    deletedAny = true;
  }
  if (baseName.toLowerCase() === "dataset.txt") {
    const path22 = DEFAULT_DATASET_FILE;
    if (import_fs.default.existsSync(path22)) {
      import_fs.default.writeFileSync(
        path22,
        `# OSINT INTEL DATABASE ARCHIVE - INDONESIA DATASET
# FORMAT: NIK|FULL_NAME|BIRTH_DATE|GENDER|AGE|CITY|PROVINCE|ADDRESS|PHONE|EMAIL|OCCUPATION|THREAT_LEVEL|SOURCE_DATASET|LAST_ACTIVITY|NOTES
`,
        "utf8"
      );
      deletedAny = true;
    }
  }
  if (!deletedAny) {
    throw new Error(`File '${baseName}' tidak ditemukan.`);
  }
  return {
    success: true,
    message: baseName.toLowerCase() === "dataset.txt" ? "Isi dataset.txt telah dikosongkan." : `File ${baseName} berhasil dihapus.`
  };
}
function parseDatasetLine(line, formatHeader) {
  const cleanLine = line.trim();
  const fields = {};
  if (cleanLine.startsWith("{") && cleanLine.endsWith("}")) {
    try {
      const parsed = JSON.parse(cleanLine);
      for (const [k, v] of Object.entries(parsed)) {
        fields[k] = String(v ?? "");
      }
      return fields;
    } catch {
    }
  }
  if (cleanLine.includes("|")) {
    const parts = cleanLine.split("|").map((s) => s.trim());
    if (formatHeader && formatHeader.length > 0) {
      formatHeader.forEach((hdr, idx) => {
        if (parts[idx] !== void 0) {
          fields[hdr] = parts[idx];
        }
      });
    } else {
      const defaultCols = [
        "nik",
        "fullName",
        "birthDate",
        "gender",
        "age",
        "city",
        "province",
        "address",
        "phone",
        "email",
        "occupation",
        "threatLevel",
        "sourceDataset",
        "lastActivity",
        "notes"
      ];
      parts.forEach((val, idx) => {
        const key = defaultCols[idx] || `col_${idx + 1}`;
        fields[key] = val;
      });
    }
    return fields;
  }
  if (cleanLine.includes(",")) {
    const parts = cleanLine.split(",").map((s) => s.trim().replace(/^["']|["']$/g, ""));
    if (formatHeader && formatHeader.length > 0) {
      formatHeader.forEach((hdr, idx) => {
        if (parts[idx] !== void 0) {
          fields[hdr] = parts[idx];
        }
      });
    } else {
      parts.forEach((val, idx) => {
        fields[`col_${idx + 1}`] = val;
      });
    }
    return fields;
  }
  if (cleanLine.includes("	")) {
    const parts = cleanLine.split("	").map((s) => s.trim());
    parts.forEach((val, idx) => {
      fields[`col_${idx + 1}`] = val;
    });
    return fields;
  }
  if (cleanLine.includes(":")) {
    const parts = cleanLine.split(":").map((s) => s.trim());
    if (parts.length === 2) {
      fields["username_or_email"] = parts[0];
      fields["password_or_data"] = parts[1];
    } else {
      parts.forEach((val, idx) => {
        fields[`part_${idx + 1}`] = val;
      });
    }
    return fields;
  }
  fields["raw"] = cleanLine;
  return fields;
}
async function smartSearchDatasets(query, maxResults = 500) {
  const startTime = Date.now();
  const trimmedQuery = (query || "").trim();
  if (!trimmedQuery) {
    return {
      query: "",
      totalMatches: 0,
      searchDurationMs: 0,
      filesSearched: [],
      records: [],
      rawTextOutput: "[]",
      jsonOutput: { results: [], totalMatches: 0, count: 0 }
    };
  }
  const queryTokens = trimmedQuery.toLowerCase().split(/\s+/).filter(Boolean);
  const datasetFiles = await getAllDatasetFiles();
  const filesSearched = [];
  const records = [];
  let totalMatches = 0;
  for (const fileInfo of datasetFiles) {
    if (!import_fs.default.existsSync(fileInfo.path)) continue;
    filesSearched.push(fileInfo.name);
    let formatHeader;
    const rl = import_readline.default.createInterface({
      input: import_fs.default.createReadStream(fileInfo.path, { encoding: "utf8" }),
      crlfDelay: Infinity
    });
    let lineNumber = 0;
    for await (const line of rl) {
      lineNumber++;
      const trimmedLine = line.trim();
      if (!trimmedLine) continue;
      if (trimmedLine.startsWith("#") || trimmedLine.startsWith("//")) {
        const upper = trimmedLine.toUpperCase();
        if (upper.includes("FORMAT:")) {
          const headerPart = trimmedLine.split(/FORMAT:\s*/i)[1];
          if (headerPart) {
            const sep = headerPart.includes("|") ? "|" : headerPart.includes(",") ? "," : headerPart.includes("	") ? "	" : null;
            if (sep) {
              formatHeader = headerPart.split(sep).map((h) => h.trim().toLowerCase());
            }
          }
        }
        continue;
      }
      if (lineNumber === 1) {
        const lowerHeader = trimmedLine.toLowerCase();
        if ((lowerHeader.includes("nik") || lowerHeader.includes("nama") || lowerHeader.includes("name") || lowerHeader.includes("phone")) && (lowerHeader.includes(",") || lowerHeader.includes("|") || lowerHeader.includes("	"))) {
          const sep = lowerHeader.includes("|") ? "|" : lowerHeader.includes(",") ? "," : "	";
          formatHeader = lowerHeader.split(sep).map((h) => h.trim().replace(/^["']|["']$/g, ""));
          continue;
        }
      }
      const lowerLine = trimmedLine.toLowerCase();
      const matchesAll = queryTokens.every((t) => lowerLine.includes(t));
      if (matchesAll) {
        totalMatches++;
        if (records.length < maxResults) {
          const parsed = parseDatasetLine(trimmedLine, formatHeader);
          const recordObj = {
            fullName: parsed.name || parsed.fullName || parsed.fullname || parsed.full_name || parsed.nama || parsed.col_2 || "",
            nik: parsed.nik || parsed.col_1 || "",
            phone: parsed.phone || parsed.telepon || parsed.hp || parsed.nohp || parsed.no_hp || parsed.col_9 || "",
            email: parsed.email || parsed.surel || parsed.col_10 || "",
            city: parsed.city || parsed.kota || parsed.col_6 || "",
            province: parsed.province || parsed.provinsi || parsed.col_7 || "",
            address: parsed.address || parsed.alamat || parsed.col_8 || "",
            birthDate: parsed.birthdate || parsed.birthDate || parsed.birth_date || parsed.tgl_lahir || parsed.col_3 || "",
            age: parsed.age || parsed.usia || parsed.umur || parsed.col_5 || "",
            gender: parsed.gender || parsed.jenis_kelamin || parsed.col_4 || "",
            occupation: parsed.occupation || parsed.pekerjaan || parsed.jabatan || parsed.col_11 || "",
            threatLevel: parsed.threatLevel || parsed.threatlevel || parsed.threat_level || parsed.threat || parsed.col_12 || "Informational",
            sourceDataset: parsed.sourceDataset || parsed.sourcedataset || parsed.source_dataset || parsed.sumber || fileInfo.name,
            lastActivity: parsed.lastActivity || parsed.lastactivity || parsed.last_activity || parsed.col_14 || "",
            notes: parsed.notes || parsed.catatan || parsed.keterangan || parsed.col_15 || ""
          };
          let derivedNikLocation = "(-)";
          const cleanNik = (recordObj.nik || "").replace(/\D/g, "");
          if (cleanNik.length === 16) {
            const loc = extractLocationFromNik(cleanNik);
            if (loc && loc !== "(-)") derivedNikLocation = loc;
          } else {
            const match16 = trimmedLine.match(/\b([1-9][0-9]{15})\b/);
            if (match16) {
              const loc = extractLocationFromNik(match16[1]);
              if (loc && loc !== "(-)") {
                derivedNikLocation = loc;
                if (!recordObj.nik) recordObj.nik = match16[1];
              }
            }
          }
          recordObj.nikLocation = derivedNikLocation;
          if (!recordObj.fullName && !recordObj.nik) {
            recordObj.fullName = trimmedLine.substring(0, 40);
          }
          records.push({
            fileName: fileInfo.name,
            lineNumber,
            rawText: trimmedLine,
            parsedFields: parsed,
            record: recordObj
          });
        }
      }
    }
  }
  const durationMs = Date.now() - startTime;
  const formattedResults = records.map((r, idx) => ({
    index: idx + 1,
    fileName: r.fileName,
    sourceFile: r.fileName,
    lineNumber: r.lineNumber,
    record: r.record,
    precisionScore: 98,
    predictionType: "Exact Match",
    matchedTags: queryTokens,
    raw: r.rawText,
    rawLine: r.rawText,
    rawText: r.rawText
  }));
  const jsonOutput = {
    success: true,
    target: trimmedQuery,
    totalMatches,
    count: records.length,
    searchDurationMs: durationMs,
    filesSearched,
    results: formattedResults
  };
  const rawTextOutput = JSON.stringify(jsonOutput, null, 2);
  return {
    query: trimmedQuery,
    totalMatches,
    searchDurationMs: durationMs,
    filesSearched,
    scannedFiles: filesSearched,
    records,
    matches: records,
    results: formattedResults,
    rawTextOutput,
    jsonOutput
  };
}
function parseGithubUrl(raw) {
  let u = (raw || "").trim();
  const originalUrl = u;
  if (!u) return { rawUrl: "", originalUrl: "" };
  if (!u.startsWith("http://") && !u.startsWith("https://")) {
    u = "https://" + u;
  }
  try {
    const urlObj = new URL(u);
    if (urlObj.hostname === "github.com") {
      const parts = urlObj.pathname.split("/").filter(Boolean);
      if (parts.length >= 4 && (parts[2] === "blob" || parts[2] === "raw")) {
        const owner = parts[0];
        const repo = parts[1];
        const branch = parts[3];
        const filePath = parts.slice(4).join("/");
        return {
          rawUrl: `https://raw.githubusercontent.com/${owner}/${repo}/${branch}/${filePath}`,
          originalUrl,
          owner,
          repo,
          branch,
          path: filePath
        };
      }
      if (parts.length >= 3) {
        const owner = parts[0];
        const repo = parts[1];
        const filePath = parts.slice(2).join("/");
        return {
          rawUrl: `https://raw.githubusercontent.com/${owner}/${repo}/main/${filePath}`,
          originalUrl,
          owner,
          repo,
          branch: "main",
          path: filePath
        };
      }
    } else if (urlObj.hostname === "raw.githubusercontent.com") {
      const parts = urlObj.pathname.split("/").filter(Boolean);
      return {
        rawUrl: u,
        originalUrl,
        owner: parts[0],
        repo: parts[1],
        branch: parts[2],
        path: parts.slice(3).join("/")
      };
    }
  } catch {
  }
  return { rawUrl: u, originalUrl };
}
async function testGithubDataset(url, githubToken) {
  const parsed = parseGithubUrl(url);
  if (!parsed.rawUrl) {
    return {
      success: false,
      message: "URL GitHub tidak boleh kosong.",
      rawUrl: "",
      originalUrl: url
    };
  }
  const startTime = Date.now();
  const headers = {
    "User-Agent": "AI-Studio-Dataset-Fetcher/2.0",
    "Accept": "text/plain, text/csv, */*"
  };
  if (githubToken && githubToken.trim()) {
    headers["Authorization"] = githubToken.startsWith("Bearer ") || githubToken.startsWith("token ") ? githubToken.trim() : `token ${githubToken.trim()}`;
  }
  try {
    const rangeHeaders = { ...headers, Range: "bytes=0-16384" };
    const res = await fetch(parsed.rawUrl, {
      method: "GET",
      headers: rangeHeaders,
      signal: AbortSignal.timeout(1e4)
    });
    const latencyMs = Date.now() - startTime;
    if (!res.ok && res.status !== 206) {
      return {
        success: false,
        message: `GitHub merespon HTTP ${res.status} (${res.statusText}). Pastikan URL publik atau token akses valid.`,
        rawUrl: parsed.rawUrl,
        originalUrl: url,
        statusCode: res.status,
        latencyMs
      };
    }
    let sizeBytes = 0;
    const contentRange = res.headers.get("content-range");
    if (contentRange) {
      const match = contentRange.match(/\/(\d+)$/);
      if (match && match[1]) {
        sizeBytes = parseInt(match[1], 10);
      }
    }
    if (!sizeBytes) {
      const cl = res.headers.get("content-length");
      if (cl) sizeBytes = parseInt(cl, 10);
    }
    const previewChunk = await res.text();
    const lines = previewChunk.split(/\r?\n/).filter((l) => l.trim().length > 0);
    const previewLines = lines.slice(0, 10);
    let detectedColumns = [];
    let sampleParsed = null;
    let lineCountEstimate;
    if (lines.length > 0) {
      const headerOrFirst = lines[0];
      if (headerOrFirst.includes(",")) {
        detectedColumns = headerOrFirst.split(",").map((c) => c.trim().replace(/^["']|["']$/g, ""));
      } else if (headerOrFirst.includes("|")) {
        detectedColumns = headerOrFirst.split("|").map((c) => c.trim());
      } else if (headerOrFirst.includes("	")) {
        detectedColumns = headerOrFirst.split("	").map((c) => c.trim());
      }
      const sampleLine = lines.length > 1 ? lines[1] : lines[0];
      sampleParsed = parseDatasetLine(sampleLine);
      if (sizeBytes > 0 && previewChunk.length > 0) {
        const avgLineBytes = previewChunk.length / lines.length;
        if (avgLineBytes > 0) {
          lineCountEstimate = Math.round(sizeBytes / avgLineBytes);
        }
      }
    }
    return {
      success: true,
      message: `Koneksi ke GitHub repository berhasil terverifikasi (${latencyMs}ms)!`,
      rawUrl: parsed.rawUrl,
      originalUrl: url,
      statusCode: res.status,
      sizeBytes,
      sizeFormatted: formatBytes(sizeBytes),
      latencyMs,
      lineCountEstimate,
      previewLines,
      detectedColumns,
      sampleParsed
    };
  } catch (err) {
    return {
      success: false,
      message: `Gagal menghubungi GitHub: ${err.message || "Koneksi timeout/error"}`,
      rawUrl: parsed.rawUrl,
      originalUrl: url,
      latencyMs: Date.now() - startTime
    };
  }
}
async function syncGithubDataset(url, targetFilename = "dataset.txt", replacePrimary = true, githubToken) {
  const parsed = parseGithubUrl(url);
  if (!parsed.rawUrl) {
    throw new Error("URL GitHub tidak valid.");
  }
  const sanitized = sanitizeDatasetFilename(targetFilename || "dataset.txt");
  if (isForbiddenDatasetName(sanitized)) {
    throw new Error(`Nama berkas '${sanitized}' dilarang karena merupakan berkas konfigurasi sistem.`);
  }
  const isPrimary = replacePrimary || sanitized.toLowerCase() === "dataset.txt";
  const finalDest = isPrimary ? DEFAULT_DATASET_FILE : import_path.default.join(DATASETS_DIR, sanitized);
  const tempDest = import_path.default.join(DATA_DIR, `.tmp_sync_${Date.now()}_${sanitized}`);
  const headers = {
    "User-Agent": "AI-Studio-Dataset-Fetcher/2.0",
    "Accept": "text/plain, text/csv, application/octet-stream, */*"
  };
  if (githubToken && githubToken.trim()) {
    headers["Authorization"] = githubToken.startsWith("Bearer ") || githubToken.startsWith("token ") ? githubToken.trim() : `token ${githubToken.trim()}`;
  }
  const res = await fetch(parsed.rawUrl, {
    method: "GET",
    headers,
    signal: AbortSignal.timeout(6e4)
    // 60 seconds for large files
  });
  if (!res.ok || !res.body) {
    throw new Error(`Gagal mengunduh berkas dari GitHub (HTTP ${res.status}: ${res.statusText})`);
  }
  try {
    const nodeReadable = import_stream.Readable.fromWeb(res.body);
    const writeStream = import_fs.default.createWriteStream(tempDest);
    await (0, import_promises.pipeline)(nodeReadable, writeStream);
    if (import_fs.default.existsSync(finalDest)) {
      try {
        import_fs.default.unlinkSync(finalDest);
      } catch {
      }
    }
    import_fs.default.renameSync(tempDest, finalDest);
    if (isPrimary) {
      const mirror = import_path.default.join(DATASETS_DIR, "dataset.txt");
      try {
        import_fs.default.copyFileSync(finalDest, mirror);
      } catch {
      }
    }
    const stats = import_fs.default.statSync(finalDest);
    const linesCount = await countLines(finalDest);
    const fileInfo = {
      name: isPrimary ? "dataset.txt" : sanitized,
      filename: isPrimary ? "dataset.txt" : sanitized,
      path: finalDest,
      sizeBytes: stats.size,
      size: stats.size,
      sizeFormatted: formatBytes(stats.size),
      linesCount,
      lineCount: linesCount,
      lastModified: stats.mtime.toISOString(),
      isDefaultDataset: isPrimary,
      isDefault: isPrimary
    };
    return {
      success: true,
      message: `Dataset dari GitHub berhasil disinkronkan ke '${fileInfo.name}' (${fileInfo.sizeFormatted}, ${linesCount.toLocaleString()} baris)!`,
      fileInfo,
      downloadedBytes: stats.size,
      linesCount
    };
  } catch (err) {
    if (import_fs.default.existsSync(tempDest)) {
      try {
        import_fs.default.unlinkSync(tempDest);
      } catch {
      }
    }
    throw new Error(`Gagal menyimpan dataset: ${err.message}`);
  }
}

// server.ts
var import_meta = {};
var nodeRequire = (0, import_module.createRequire)(import_meta.url);
var archiver = nodeRequire("archiver");
var DATA_DIR2 = import_path2.default.join(process.cwd(), "data");
var CONFIG_FILE = import_path2.default.join(DATA_DIR2, "bot_config.json");
var SEARCH_CACHE_DIR = import_path2.default.join(DATA_DIR2, "search_cache");
if (!import_fs2.default.existsSync(DATA_DIR2)) {
  import_fs2.default.mkdirSync(DATA_DIR2, { recursive: true });
}
if (!import_fs2.default.existsSync(SEARCH_CACHE_DIR)) {
  import_fs2.default.mkdirSync(SEARCH_CACHE_DIR, { recursive: true });
}
var datasetUploadStorage = import_multer.default.diskStorage({
  destination: (req, file, cb) => {
    if (!import_fs2.default.existsSync(DATASETS_DIR)) {
      import_fs2.default.mkdirSync(DATASETS_DIR, { recursive: true });
    }
    cb(null, DATASETS_DIR);
  },
  filename: (req, file, cb) => {
    const sanitized = sanitizeDatasetFilename(file.originalname || "dataset.txt");
    if (isForbiddenDatasetName(sanitized)) {
      return cb(new Error(`Nama berkas '${sanitized}' adalah berkas konfigurasi sistem dan tidak dapat diunggah sebagai dataset.`), "");
    }
    cb(null, sanitized);
  }
});
var datasetUpload = (0, import_multer.default)({
  storage: datasetUploadStorage,
  limits: {
    fileSize: Infinity
    // No maximum size limit, as explicitly requested!
  }
});
var DEFAULT_OSINT_CONFIG = {
  enabled: false,
  // Default is OFF: must be explicitly turned on by owner
  ngrokUrl: "https://dd60-180-247-62-62.ngrok-free.app",
  ownerUsername: "@flood1233",
  notifyOnStatusChange: true,
  searchEngineMode: "smart_dataset",
  // Smart auto-search dataset.txt is primary!
  apiKeys: [
    {
      id: "key-default-ppp",
      key: "ppp",
      ownerNotes: "Default API Key Contoh dari Owner",
      tier: "limited",
      initialQuota: 10,
      remainingQuota: 10,
      bonusQuota: 1,
      // Bonus 1x untuk pembelian >= 10k
      totalUsed: 0,
      createdAt: (/* @__PURE__ */ new Date()).toISOString(),
      enabled: true
    },
    {
      id: "key-vip-unlimited",
      key: "vip-unlimited",
      ownerNotes: "Paket Unlimited VIP Owner",
      tier: "unlimited",
      initialQuota: 999999,
      remainingQuota: 999999,
      bonusQuota: 0,
      totalUsed: 0,
      createdAt: (/* @__PURE__ */ new Date()).toISOString(),
      enabled: true
    }
  ]
};
var DEFAULT_MODERATION_CONFIG = {
  enabled: true,
  deleteInGroups: true,
  deleteInPrivate: true,
  sendExplanationMessage: true,
  autoDeleteExplanationSeconds: 0,
  blockGamblingSlot: true,
  blockAdult18Plus: true,
  blockDrugs: true,
  blockFraudScam: true,
  blockWeaponsExplosives: true,
  allowCyberAndOsint: true,
  cyberWhitelistKeywords: [
    "cyber",
    "osint",
    "intel",
    "pentest",
    "penetration testing",
    "exploit",
    "breach",
    "leak",
    "kebocoran data",
    "hacking",
    "ethical hacking",
    "hacker",
    "security",
    "cve",
    "vulnerability",
    "payload",
    "reverse engineering",
    "malware",
    "bug bounty",
    "infosec",
    "deface",
    "soc",
    "threat intelligence",
    "nik",
    "dox",
    "doxing",
    "tracer",
    "recon",
    "kali linux",
    "shodan",
    "sql injection",
    "xss",
    "rce",
    "zeroday",
    "0day",
    "forensic",
    "darkweb"
  ],
  customBannedKeywords: DEFAULT_STRICT_BANNED_KEYWORDS,
  whitelistKeywords: [],
  recentIncidents: []
};
var DEFAULT_QUOTA_CONFIG = {
  newUserQuotaEnabled: true,
  // Bonus kuota sambutan aktif
  newUserQuotaAmount: 5,
  // Default +5x kuota pencarian gratis
  dailyQuotaEnabled: true,
  // Klaim kuota gratis harian aktif
  dailyQuotaAmount: 2,
  // Default +2x kuota harian
  dailyResetHourWib: 0,
  // Reset pukul 00:00 WIB
  deductQuotaOnlyOnFound: true,
  // Hanya kurangi kuota jika target ditemukan di dataset
  allowSearchWithoutApiKey: true,
  // Otomatis pakai kuota pribadi pengguna
  quotaCostPerSearch: 1
  // 1 kuota per pencarian berhasil
};
var DEFAULT_MENU_CONFIG = {
  welcomeMessageHeader: "\u{1F44B} *Halo! Selamat datang di axxosintbot Intelligence & Automation (Created by Ax.).*",
  showClaimButtonInMenu: true,
  showQuotaButtonInMenu: true,
  showOsintButtonInMenu: true,
  showPriceButtonInMenu: true,
  showOwnerButtonInMenu: true,
  showHelpButtonInMenu: true,
  customButtons: []
};
var DEFAULT_GITHUB_SYNC = {
  url: "https://github.com/THEOYS123/track-call/blob/main/data/dataset.txt",
  rawUrl: "https://raw.githubusercontent.com/THEOYS123/track-call/main/data/dataset.txt",
  targetFilename: "dataset.txt",
  replacePrimary: true,
  lastSyncStatus: "idle",
  autoSyncEnabled: false
};
var DEFAULT_GROUP_CONFIG = {
  allowGroups: true,
  // Izinkan bot merespon di grup Telegram
  groupAdminOnly: false,
  // Perintah dapat dijalankan semua anggota grup atau hanya admin
  silentFallbackInGroup: true,
  // Cegah spam: Abaikan obrolan santai/biasa di grup (Hanya respon /command & search:)
  allowAllCommandsInGroup: true,
  enableAntiFlood: true,
  // Anti-spam rate limiting & protection
  antiFloodCooldownSeconds: 3,
  // Jeda minimal 3 detik antar perintah per pengguna
  allowedGroupIds: [],
  blockedGroupIds: [],
  knownGroups: []
};
var DEFAULT_WELCOME_MESSAGE = `\u{1F44B} *Halo! Selamat datang di axxosintbot Intelligence & Automation.*

Saya adalah *axxosintbot*, bot intelijen & profiling otomatis yang diciptakan oleh *Ax.* (@flood1233).

Silakan gunakan tombol menu interaktif di bawah atau ketik perintah:
\u2022 /id - Cek Chat ID & status verifikasi akun
\u2022 /osint - Status & pencarian Intelijen OSINT
\u2022 /history - Riwayat pencarian OSINT pribadi Anda
\u2022 /harga - Daftar harga & kuota API Key
\u2022 /bot - Detail & spesifikasi bot
\u2022 /ping - Cek latency & status server
\u2022 /waktu - Cek jam real-time Indonesia
\u2022 /help - Bantuan & daftar perintah lengkap`;
var DEFAULT_CUSTOM_COMMANDS = [
  {
    id: "cmd-1",
    command: "kontak",
    description: "Informasi kontak resmi owner bot (@flood1233)",
    replyText: "\u{1F4DE} *KONTAK RESMI OWNER BOT*\n\nSilakan hubungi owner di Telegram:\n\u{1F464} @flood1233\n_(Bebas mau chat ataupun call, asal tidak spam)_",
    enabled: true
  },
  {
    id: "cmd-2",
    command: "fitur",
    description: "Ringkasan fitur utama bot Telegram",
    replyText: "\u26A1 *FITUR UTAMA BOT*\n\n1. Verifikasi Wajib /id Akun Pengguna\n2. Server OSINT Intelijen (Ngrok API Key)\n3. Cek Status Kuota API Key Realtime\n4. Deteksi Mata Uang Sesuai Negara (IDR/USD/MYR/SGD)\n5. Notifikasi Otomatis Broadcast Status Server\n6. Menu Rahasia Owner (ax0895)",
    enabled: true
  }
];
var DEFAULT_AUTO_REPLIES = [
  {
    id: "ar-1",
    triggerKeyword: "halo",
    matchType: "contains",
    replyText: "Halo juga! Ada yang bisa saya bantu? Ketik /menu untuk melihat opsi yang tersedia.",
    enabled: true
  },
  {
    id: "ar-2",
    triggerKeyword: "assalamualaikum",
    matchType: "contains",
    replyText: "Waalaikumsalam warahmatullahi wabarakatuh! Selamat datang, ketik /menu untuk bantuan.",
    enabled: true
  },
  {
    id: "ar-3",
    triggerKeyword: "siapa kamu",
    matchType: "contains",
    replyText: "Saya adalah Bot Telegram cerdas yang selalu aktif 24/7 dan dikontrol melalui Website Controller.",
    enabled: true
  },
  {
    id: "ar-4",
    triggerKeyword: "p",
    matchType: "exact",
    replyText: "Ya, bot online dan siap merespon! Ketik /id untuk cek Chat ID dan verifikasi akun kamu.",
    enabled: true
  }
];
var DEFAULT_CUSTOM_MENUS = [
  {
    id: "menu-promo",
    label: "\u{1F381} Info Promo & Bonus",
    type: "callback",
    responseText: "\u{1F389} *PROMOSI SPESIAL API KEY OSINT:*\n\n\u2022 Pembelian paket Rp 10.000 ke atas langsung dapat +1x BONUS pakai!\n\u2022 Pembelian paket Rp 50.000 dapat +2x BONUS pakai!\n\u2022 Paket Unlimited Rp 100.000 bebas pakai selamanya tanpa batas!\n\nHubungi Owner Telegram: @flood1233\n_(Bebas mau chat ataupun call, asal tidak spam)_",
    enabled: true
  },
  {
    id: "menu-rules",
    label: "\u{1F4DC} Ketentuan & Panduan",
    type: "callback",
    responseText: "\u{1F4DC} *KETENTUAN PENGGUNAAN BOT:*\n\n1. Semua pengguna baru wajib verifikasi awal via perintah /id.\n2. Fitur OSINT hanya dapat digunakan saat Server diaktifkan (ON) oleh Owner.\n3. Gunakan API Key resmi dari Owner @flood1233.\n4. Format pencarian: `search: <target> <apiKey>`\n5. Dilarang melakukan spamming request.",
    enabled: true
  },
  {
    id: "menu-faq",
    label: "\u2753 Tanya Jawab (FAQ)",
    type: "callback",
    responseText: "\u2753 *PERTANYAAN UMUM (FAQ):*\n\nQ: Mengapa fitur OSINT tertulis OFF?\nA: Server OSINT sedang di-offline kan oleh owner. Hubungi @flood1233 untuk meminta menyalakan server.\n\nQ: Bagaimana cara mendapatkan API Key?\nA: Silakan hubungi Owner di Telegram: @flood1233\n\nQ: Bagaimana jika server ngrok mati saat pencarian?\nA: Kuota API Key Anda TIDAK akan dipotong.",
    enabled: true
  }
];
var botConfig = {
  token: process.env.TELEGRAM_BOT_TOKEN || "",
  isActive: false,
  welcomeMessage: DEFAULT_WELCOME_MESSAGE,
  customCommands: DEFAULT_CUSTOM_COMMANDS,
  autoReplies: DEFAULT_AUTO_REPLIES,
  customMenus: DEFAULT_CUSTOM_MENUS,
  stats: {
    messagesReceived: 0,
    messagesSent: 0,
    commandsExecuted: 0,
    activeUsersCount: 0,
    osintSearchesCount: 0
  },
  activeUsers: [],
  osintConfig: DEFAULT_OSINT_CONFIG,
  searchHistories: [],
  githubSync: DEFAULT_GITHUB_SYNC,
  groupConfig: DEFAULT_GROUP_CONFIG,
  quotaConfig: DEFAULT_QUOTA_CONFIG,
  menuConfig: DEFAULT_MENU_CONFIG,
  referralConfig: DEFAULT_REFERRAL_CONFIG,
  referralRecords: [],
  referralWithdrawLogs: [],
  multiBots: [],
  rentalPlans: DEFAULT_RENTAL_PLANS,
  quotaPackages: DEFAULT_QUOTA_PACKAGES,
  ownerWebsitePasskey: "ax0895"
};
var recentLogs = [];
var messageTrafficLogs = [];
function recordMessageTraffic(entry) {
  const wibTime = getFormattedWIB().fullStr;
  const logItem = {
    id: `msg_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
    timestamp: (/* @__PURE__ */ new Date()).toISOString(),
    formattedWib: wibTime,
    botId: entry.botId || "primary",
    botUsername: entry.botUsername || currentBotInfo?.username || "axxosintbot",
    botName: entry.botName || currentBotInfo?.first_name || "Bot Utama",
    isPrimaryBot: entry.isPrimaryBot !== false,
    direction: entry.direction || "incoming",
    chatId: entry.chatId || 0,
    chatType: entry.chatType || "private",
    chatTitle: entry.chatTitle,
    userId: entry.userId,
    userName: entry.userName || "Pengguna",
    usernameTag: entry.usernameTag,
    text: entry.text || "",
    command: entry.command,
    status: entry.status || "delivered",
    filterReason: entry.filterReason,
    latencyMs: entry.latencyMs
  };
  messageTrafficLogs.unshift(logItem);
  if (messageTrafficLogs.length > 500) {
    messageTrafficLogs.pop();
  }
}
var botStartedAt = null;
var lastError = null;
var currentBotInfo = null;
var isPollingRunning = false;
var pollingAbortController = null;
var pollingOffset = 0;
var lastPollingTimestamp = null;
var activeBotContextToken = null;
var activeBotContextInfo = null;
var activeSecondaryBotWorkers = /* @__PURE__ */ new Map();
var activeClaimLocks = /* @__PURE__ */ new Set();
var CLAIMED_USERS_FILE = import_path2.default.join(DATA_DIR2, "claimed_new_users.json");
var persistentClaimedUserIds = /* @__PURE__ */ new Set();
function loadPersistentClaimedUsers() {
  try {
    if (import_fs2.default.existsSync(CLAIMED_USERS_FILE)) {
      const data = JSON.parse(import_fs2.default.readFileSync(CLAIMED_USERS_FILE, "utf8"));
      if (Array.isArray(data)) {
        persistentClaimedUserIds = new Set(data.map(Number));
      }
    }
  } catch {
  }
}
function savePersistentClaimedUsers() {
  try {
    import_fs2.default.writeFileSync(CLAIMED_USERS_FILE, JSON.stringify(Array.from(persistentClaimedUserIds)), "utf8");
  } catch {
  }
}
loadPersistentClaimedUsers();
var REFERRALS_FILE = import_path2.default.join(DATA_DIR2, "referrals.json");
function loadReferralData() {
  try {
    if (import_fs2.default.existsSync(REFERRALS_FILE)) {
      const parsed = JSON.parse(import_fs2.default.readFileSync(REFERRALS_FILE, "utf8"));
      if (parsed) {
        if (parsed.config) {
          botConfig.referralConfig = { ...DEFAULT_REFERRAL_CONFIG, ...parsed.config };
        }
        if (Array.isArray(parsed.records)) {
          botConfig.referralRecords = parsed.records;
        }
        if (Array.isArray(parsed.withdrawLogs)) {
          botConfig.referralWithdrawLogs = parsed.withdrawLogs;
        }
      }
    }
  } catch (err) {
    console.error("Error loading referral data:", err.message);
  }
}
function saveReferralData() {
  try {
    const payload = {
      config: botConfig.referralConfig || DEFAULT_REFERRAL_CONFIG,
      records: botConfig.referralRecords || [],
      withdrawLogs: botConfig.referralWithdrawLogs || []
    };
    import_fs2.default.writeFileSync(REFERRALS_FILE, JSON.stringify(payload, null, 2), "utf8");
  } catch (err) {
    console.error("Error saving referral data:", err.message);
  }
}
loadReferralData();
function getAllReferralAccounts() {
  const map = /* @__PURE__ */ new Map();
  for (const u of botConfig.activeUsers) {
    const uid = Number(u.userId || u.chatId);
    if (!uid || uid <= 0) continue;
    map.set(uid, {
      userId: uid,
      userName: [u.firstName, u.lastName].filter(Boolean).join(" ") || u.username || "Pengguna",
      usernameTag: u.username ? `@${u.username}` : void 0,
      referralCode: `ref_${uid}`,
      totalInvitedCount: u.totalReferralsCount || 0,
      confirmedCount: u.totalReferralsCount || 0,
      savedQuotaBalance: u.referralVaultBalance || 0,
      totalWithdrawnQuota: u.totalReferralQuotaClaimed || 0,
      lastInvitedAt: u.lastSeen
    });
  }
  for (const r of botConfig.referralRecords || []) {
    const invId = Number(r.inviterUserId);
    if (!invId) continue;
    let acc = map.get(invId);
    if (!acc) {
      acc = {
        userId: invId,
        userName: r.inviterName || `User ${invId}`,
        usernameTag: r.inviterUsername ? `@${r.inviterUsername}` : void 0,
        referralCode: `ref_${invId}`,
        totalInvitedCount: 0,
        confirmedCount: 0,
        savedQuotaBalance: 0,
        totalWithdrawnQuota: 0,
        lastInvitedAt: r.referredAt
      };
      map.set(invId, acc);
    }
  }
  for (const acc of map.values()) {
    const recs = (botConfig.referralRecords || []).filter((r) => Number(r.inviterUserId) === acc.userId);
    acc.totalInvitedCount = Math.max(acc.totalInvitedCount, recs.length);
    acc.confirmedCount = Math.max(acc.confirmedCount, recs.filter((r) => r.status === "confirmed").length);
  }
  return Array.from(map.values()).sort((a, b) => {
    if (b.confirmedCount !== a.confirmedCount) return b.confirmedCount - a.confirmedCount;
    return b.savedQuotaBalance - a.savedQuotaBalance;
  });
}
var processedUpdateIds = /* @__PURE__ */ new Set();
var processedMessageIds = /* @__PURE__ */ new Set();
var lastUserActionTimestamp = /* @__PURE__ */ new Map();
var floodWarningSentTimestamps = /* @__PURE__ */ new Map();
var activeDownloads = /* @__PURE__ */ new Set();
var hotSearchCache = /* @__PURE__ */ new Map();
var SEARCH_CACHE_TTL_MS = 60 * 1e3;
var recentSearchEvents = [];
var recentSpikeAlerts = [];
function recordSearchAndDetectSpike(chatId, userName, target) {
  const now = Date.now();
  recentSearchEvents.push({ timestamp: now, chatId, userName, target });
  recentSearchEvents = recentSearchEvents.filter((ev) => now - ev.timestamp <= 6e4);
  const window30s = recentSearchEvents.filter((ev) => now - ev.timestamp <= 3e4);
  const globalCount = window30s.length;
  const user10s = recentSearchEvents.filter((ev) => String(ev.chatId) === String(chatId) && now - ev.timestamp <= 1e4);
  const userCount = user10s.length;
  let alertItem = null;
  if (globalCount >= 5) {
    alertItem = {
      id: `spike_${now}_${Math.random().toString(36).substring(2, 6)}`,
      timestamp: (/* @__PURE__ */ new Date()).toISOString(),
      queryCount: globalCount,
      threshold: 5,
      windowSeconds: 30,
      triggerType: "global_surge",
      chatId,
      userName,
      targetSample: target,
      severity: globalCount >= 10 ? "critical" : "warning",
      details: `Lonjakan aktivitas global: ${globalCount} pencarian dalam 30 detik.`
    };
  } else if (userCount >= 3) {
    alertItem = {
      id: `spike_${now}_${Math.random().toString(36).substring(2, 6)}`,
      timestamp: (/* @__PURE__ */ new Date()).toISOString(),
      queryCount: userCount,
      threshold: 3,
      windowSeconds: 10,
      triggerType: "user_burst",
      chatId,
      userName,
      targetSample: target,
      severity: userCount >= 6 ? "high" : "warning",
      details: `Lonjakan cepat dari satu pengguna: ${userCount} pencarian dalam 10 detik.`
    };
  }
  if (alertItem) {
    const lastAlert = recentSpikeAlerts[0];
    if (!lastAlert || now - new Date(lastAlert.timestamp).getTime() > 12e3) {
      recentSpikeAlerts.unshift(alertItem);
      if (recentSpikeAlerts.length > 30) recentSpikeAlerts.pop();
      addLog(
        "warn",
        `\u{1F6A8} [SUSPICIOUS SEARCH SPIKE] Lonjakan terdeteksi: ${alertItem.queryCount} query dalam ${alertItem.windowSeconds}s (${userName}, ID: ${chatId}, target: "${target}")`,
        chatId,
        userName
      );
    }
    return alertItem;
  }
  return null;
}
var userBurstTracker = /* @__PURE__ */ new Map();
function checkAdaptiveSecurityBurst(fromId, chatId, senderName) {
  const key = String(fromId);
  const now = Date.now();
  const history = userBurstTracker.get(key) || [];
  const recent = history.filter((t) => now - t <= 1e4);
  recent.push(now);
  userBurstTracker.set(key, recent);
  if (recent.length > 14) {
    addLog(
      "warn",
      `\u{1F6E1}\uFE0F [SECURITY DEFENSE] Terdeteksi flood otomatis (${recent.length} req/10s) dari ${senderName} (ID: ${fromId}). Soft cooldown diaktifkan.`,
      chatId
    );
    return {
      isBlocked: true,
      message: `\u{1F6E1}\uFE0F *Keamanan Sistem (Adaptive Security Shield)*
Terdeteksi frekuensi permintaan otomatis yang terlalu cepat (${recent.length} req/10s).
Untuk menjaga stabilitas server bagi semua pengguna, silakan tunggu *15 detik* sebelum melanjutkan.`
    };
  }
  const in5s = recent.filter((t) => now - t <= 5e3);
  if (in5s.length > 4) {
    return {
      isBlocked: true,
      message: `\u23F3 *Jeda Keamanan (Anti-Burst Protection)*
Anda mengirim permintaan terlalu cepat (${in5s.length}x berturut-turut). Mohon jeda *4 detik* agar proses pencarian dataset selesai secara optimal.`
    };
  }
  return { isBlocked: false };
}
function sanitizeAndNormalizeQuery(rawQuery) {
  if (!rawQuery || typeof rawQuery !== "string") {
    return { clean: "", isValid: false, reason: "Query kosong." };
  }
  let text = rawQuery.trim();
  if (text.includes("\0") || text.includes("../") || text.includes("..\\")) {
    return { clean: "", isValid: false, reason: "Karakter terlarang (null byte / directory traversal) terdeteksi." };
  }
  if (text.length > 100) {
    text = text.substring(0, 100);
  }
  const cleanDigits = text.replace(/[\s\-_.]/g, "");
  if (/^\d{16}$/.test(cleanDigits)) {
    return { clean: cleanDigits, isValid: true };
  }
  if (/^(\+62|62|0)8[1-9][0-9]{6,11}$/.test(cleanDigits)) {
    return { clean: cleanDigits, isValid: true };
  }
  return { clean: text, isValid: true };
}
function updateKnownGroup(chat) {
  if (!chat || chat.type !== "group" && chat.type !== "supergroup") return;
  if (!botConfig.groupConfig) {
    botConfig.groupConfig = { ...DEFAULT_GROUP_CONFIG };
  }
  if (!Array.isArray(botConfig.groupConfig.knownGroups)) {
    botConfig.groupConfig.knownGroups = [];
  }
  const numericId = Number(chat.id);
  const existing = botConfig.groupConfig.knownGroups.find((g) => g.id === numericId);
  const now = (/* @__PURE__ */ new Date()).toISOString();
  if (existing) {
    existing.title = chat.title || existing.title || `Grup ${numericId}`;
    existing.lastSeen = now;
    existing.totalCommands = (existing.totalCommands || 0) + 1;
    existing.status = botConfig.groupConfig.blockedGroupIds?.includes(numericId) ? "blocked" : "active";
  } else {
    botConfig.groupConfig.knownGroups.unshift({
      id: numericId,
      title: chat.title || `Grup ${numericId}`,
      type: chat.type,
      firstSeen: now,
      lastSeen: now,
      totalCommands: 1,
      status: botConfig.groupConfig.blockedGroupIds?.includes(numericId) ? "blocked" : "active"
    });
  }
  saveBotConfig();
}
async function isTelegramGroupAdmin(token, chatId, userId) {
  try {
    const res = await callTelegramApi(token, "getChatMember", {
      chat_id: chatId,
      user_id: userId
    }, 4e3);
    if (res && res.status) {
      return res.status === "creator" || res.status === "administrator";
    }
    return false;
  } catch {
    return false;
  }
}
function syncUserApiKey(user) {
  const numericId = Number(user.userId || user.chatId);
  if (!numericId || numericId <= 0) return;
  user.userId = numericId;
  if (!user.chatId || Number(user.chatId) <= 0) {
    user.chatId = numericId;
  }
  user.personalApiKey = `usr_${numericId}`;
  const keyName = user.personalApiKey;
  let matched = botConfig.osintConfig.apiKeys.find((k) => k.key.toLowerCase() === keyName.toLowerCase());
  if (!matched) {
    matched = {
      id: `usr-key-${numericId}`,
      key: keyName,
      ownerNotes: `Kunci Kuota Pribadi: ${user.firstName} (User ID: ${numericId})`,
      tier: "limited",
      initialQuota: user.personalQuota || 0,
      remainingQuota: user.personalQuota || 0,
      bonusQuota: 0,
      totalUsed: 0,
      createdAt: user.firstSeen || (/* @__PURE__ */ new Date()).toISOString(),
      enabled: true
    };
    botConfig.osintConfig.apiKeys.push(matched);
  } else {
    matched.remainingQuota = typeof user.personalQuota === "number" ? user.personalQuota : 0;
    matched.enabled = true;
  }
}
function loadBotConfig() {
  try {
    if (import_fs2.default.existsSync(CONFIG_FILE)) {
      const raw = import_fs2.default.readFileSync(CONFIG_FILE, "utf8");
      const parsed = JSON.parse(raw);
      botConfig = {
        token: parsed.token || botConfig.token || "",
        isActive: typeof parsed.isActive === "boolean" ? parsed.isActive : false,
        welcomeMessage: parsed.welcomeMessage || DEFAULT_WELCOME_MESSAGE,
        customCommands: Array.isArray(parsed.customCommands) ? parsed.customCommands : DEFAULT_CUSTOM_COMMANDS,
        autoReplies: Array.isArray(parsed.autoReplies) ? parsed.autoReplies : DEFAULT_AUTO_REPLIES,
        customMenus: Array.isArray(parsed.customMenus) && parsed.customMenus.length > 0 ? parsed.customMenus : DEFAULT_CUSTOM_MENUS,
        stats: {
          messagesReceived: parsed.stats?.messagesReceived || 0,
          messagesSent: parsed.stats?.messagesSent || 0,
          commandsExecuted: parsed.stats?.commandsExecuted || 0,
          activeUsersCount: Array.isArray(parsed.activeUsers) ? parsed.activeUsers.length : 0,
          osintSearchesCount: parsed.stats?.osintSearchesCount || 0
        },
        activeUsers: Array.isArray(parsed.activeUsers) ? parsed.activeUsers : [],
        osintConfig: parsed.osintConfig ? {
          enabled: typeof parsed.osintConfig.enabled === "boolean" ? parsed.osintConfig.enabled : false,
          ngrokUrl: parsed.osintConfig.ngrokUrl || DEFAULT_OSINT_CONFIG.ngrokUrl,
          ownerUsername: parsed.osintConfig.ownerUsername || DEFAULT_OSINT_CONFIG.ownerUsername,
          notifyOnStatusChange: typeof parsed.osintConfig.notifyOnStatusChange === "boolean" ? parsed.osintConfig.notifyOnStatusChange : true,
          searchEngineMode: parsed.osintConfig.searchEngineMode || "smart_dataset",
          apiKeys: Array.isArray(parsed.osintConfig.apiKeys) && parsed.osintConfig.apiKeys.length > 0 ? parsed.osintConfig.apiKeys : DEFAULT_OSINT_CONFIG.apiKeys,
          lastToggledAt: parsed.osintConfig.lastToggledAt
        } : DEFAULT_OSINT_CONFIG,
        searchHistories: Array.isArray(parsed.searchHistories) ? parsed.searchHistories : [],
        githubSync: parsed.githubSync ? {
          ...DEFAULT_GITHUB_SYNC,
          ...parsed.githubSync
        } : DEFAULT_GITHUB_SYNC,
        groupConfig: parsed.groupConfig ? {
          ...DEFAULT_GROUP_CONFIG,
          ...parsed.groupConfig,
          knownGroups: Array.isArray(parsed.groupConfig.knownGroups) ? parsed.groupConfig.knownGroups : []
        } : DEFAULT_GROUP_CONFIG,
        quotaConfig: parsed.quotaConfig ? {
          ...DEFAULT_QUOTA_CONFIG,
          ...parsed.quotaConfig
        } : DEFAULT_QUOTA_CONFIG,
        menuConfig: parsed.menuConfig ? {
          ...DEFAULT_MENU_CONFIG,
          ...parsed.menuConfig,
          customButtons: Array.isArray(parsed.menuConfig.customButtons) ? parsed.menuConfig.customButtons : []
        } : DEFAULT_MENU_CONFIG,
        lastPollingOffset: typeof parsed.lastPollingOffset === "number" ? parsed.lastPollingOffset : 0
      };
      if (botConfig.lastPollingOffset && botConfig.lastPollingOffset > 0) {
        pollingOffset = botConfig.lastPollingOffset;
      }
      if (Array.isArray(botConfig.activeUsers)) {
        const userMap = /* @__PURE__ */ new Map();
        for (const u of botConfig.activeUsers) {
          const cid = Number(u.chatId);
          if (!cid || cid <= 0) continue;
          if (!userMap.has(cid)) {
            userMap.set(cid, {
              chatId: cid,
              firstName: u.firstName || "Anonymous",
              lastName: u.lastName || "",
              username: u.username || "",
              firstSeen: u.firstSeen || (/* @__PURE__ */ new Date()).toISOString(),
              lastSeen: u.lastSeen || (/* @__PURE__ */ new Date()).toISOString(),
              totalMessages: typeof u.totalMessages === "number" ? u.totalMessages : 1,
              type: "private",
              isVerified: true,
              // Permanent official verification for registered users
              verifiedAt: u.verifiedAt || u.firstSeen || (/* @__PURE__ */ new Date()).toISOString(),
              languageCode: u.languageCode || "id",
              hasClaimedNewUserQuota: Boolean(u.hasClaimedNewUserQuota),
              newUserQuotaClaimedAt: u.newUserQuotaClaimedAt,
              dailyQuotaLastClaimedDate: u.dailyQuotaLastClaimedDate,
              dailyQuotaLastClaimedAt: u.dailyQuotaLastClaimedAt,
              dailyQuotaClaimsCount: typeof u.dailyQuotaClaimsCount === "number" ? u.dailyQuotaClaimsCount : 0,
              personalQuota: typeof u.personalQuota === "number" ? u.personalQuota : 0,
              personalApiKey: u.personalApiKey || `usr_${cid}`
            });
          }
        }
        botConfig.activeUsers = Array.from(userMap.values());
        botConfig.stats.activeUsersCount = botConfig.activeUsers.length;
        if (botConfig.osintConfig && Array.isArray(botConfig.osintConfig.apiKeys)) {
          botConfig.osintConfig.apiKeys = botConfig.osintConfig.apiKeys.filter((k) => !k.key.includes("-"));
        }
        for (const u of botConfig.activeUsers) {
          syncUserApiKey(u);
          if (u.hasClaimedNewUserQuota) {
            persistentClaimedUserIds.add(Number(u.userId || u.chatId));
          }
        }
        savePersistentClaimedUsers();
      }
      try {
        if (!Array.isArray(botConfig.searchHistories)) {
          botConfig.searchHistories = [];
        }
        if (import_fs2.default.existsSync(SEARCH_CACHE_DIR)) {
          const files = import_fs2.default.readdirSync(SEARCH_CACHE_DIR).filter((f) => f.endsWith(".json"));
          for (const f of files) {
            try {
              const fileData = JSON.parse(import_fs2.default.readFileSync(import_path2.default.join(SEARCH_CACHE_DIR, f), "utf8"));
              if (fileData && fileData.id && !botConfig.searchHistories.some((h) => h.id === fileData.id)) {
                botConfig.searchHistories.push(fileData);
              }
            } catch {
            }
          }
          botConfig.searchHistories.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
        }
      } catch {
      }
      if (!botConfig.moderationConfig) {
        botConfig.moderationConfig = { ...DEFAULT_MODERATION_CONFIG };
      } else {
        botConfig.moderationConfig = {
          ...DEFAULT_MODERATION_CONFIG,
          ...botConfig.moderationConfig
        };
      }
      console.log(`[Telegram Bot] Config loaded successfully. Active: ${botConfig.isActive}, OSINT: ${botConfig.osintConfig.enabled}, Users: ${botConfig.activeUsers.length}`);
    }
  } catch (err) {
    console.error("[Telegram Bot] Error reading bot config:", err.message);
  }
}
function saveBotConfig() {
  try {
    import_fs2.default.writeFileSync(CONFIG_FILE, JSON.stringify(botConfig, null, 2), "utf8");
  } catch (err) {
    console.error("[Telegram Bot] Error saving bot config:", err.message);
  }
}
function addLog(type, text, chatId, fromUser, details) {
  const entry = {
    id: `log-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
    timestamp: (/* @__PURE__ */ new Date()).toISOString(),
    type,
    text,
    chatId,
    fromUser,
    details
  };
  recentLogs.unshift(entry);
  if (recentLogs.length > 200) {
    recentLogs.pop();
  }
}
function maskToken(token) {
  if (!token) return "";
  if (token.length <= 10) return "\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022";
  const prefix = token.substring(0, 6);
  const suffix = token.substring(token.length - 4);
  return `${prefix}...${suffix}`;
}
async function callTelegramApi(token, method, payload, timeoutMs = 25e3) {
  const url = `https://api.telegram.org/bot${token}/${method}`;
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetch(url, {
      method: payload ? "POST" : "GET",
      headers: {
        "Content-Type": "application/json"
      },
      body: payload ? JSON.stringify(payload) : void 0,
      signal: controller.signal
    });
    const data = await response.json();
    return data;
  } finally {
    clearTimeout(timer);
  }
}
async function verifyTelegramToken(token) {
  const startTime = Date.now();
  const trimmed = (token || "").trim();
  if (!trimmed) {
    return {
      valid: false,
      errorMessage: "Token Telegram tidak boleh kosong.",
      checkedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
  }
  if (!/^\d{5,20}:[A-Za-z0-9_-]{20,80}$/.test(trimmed)) {
    return {
      valid: false,
      errorMessage: "Format token tidak valid. Token bot resmi harus diawali angka ID diikuti titik dua (contoh: 123456789:AAHfkj_98...).",
      checkedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
  }
  try {
    const res = await callTelegramApi(trimmed, "getMe", void 0, 1e4);
    const latencyMs = Date.now() - startTime;
    if (res && res.ok && res.result) {
      return {
        valid: true,
        botInfo: res.result,
        latencyMs,
        checkedAt: (/* @__PURE__ */ new Date()).toISOString()
      };
    } else {
      return {
        valid: false,
        errorCode: res?.error_code || 401,
        errorMessage: res?.description || "Token tidak diterima oleh Telegram API (Unauthorized).",
        latencyMs,
        checkedAt: (/* @__PURE__ */ new Date()).toISOString()
      };
    }
  } catch (err) {
    const latencyMs = Date.now() - startTime;
    return {
      valid: false,
      errorMessage: `Gagal menghubungi server Telegram: ${err.message || "Timeout / Network error"}`,
      latencyMs,
      checkedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
  }
}
function getFormattedWIB() {
  const now = /* @__PURE__ */ new Date();
  const optionsDate = {
    timeZone: "Asia/Jakarta",
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric"
  };
  const optionsTime = {
    timeZone: "Asia/Jakarta",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: false
  };
  const dateStr = new Intl.DateTimeFormat("id-ID", optionsDate).format(now);
  const timeStr = new Intl.DateTimeFormat("id-ID", optionsTime).format(now) + " WIB";
  return { dateStr, timeStr, fullStr: `${dateStr}, ${timeStr}` };
}
function formatUptime(seconds) {
  const d = Math.floor(seconds / (3600 * 24));
  const h = Math.floor(seconds % (3600 * 24) / 3600);
  const m = Math.floor(seconds % 3600 / 60);
  const s = Math.floor(seconds % 60);
  const parts = [];
  if (d > 0) parts.push(`${d} hari`);
  if (h > 0) parts.push(`${h} jam`);
  if (m > 0) parts.push(`${m} menit`);
  parts.push(`${s} detik`);
  return parts.join(" ");
}
function getWibDateString() {
  try {
    return new Intl.DateTimeFormat("en-CA", {
      timeZone: "Asia/Jakarta",
      year: "numeric",
      month: "2-digit",
      day: "2-digit"
    }).format(/* @__PURE__ */ new Date());
  } catch {
    const now = /* @__PURE__ */ new Date();
    return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-${String(now.getDate()).padStart(2, "0")}`;
  }
}
function getTimeUntilNextWibMidnight() {
  try {
    const now = /* @__PURE__ */ new Date();
    const jakartaTimeString = now.toLocaleString("en-US", { timeZone: "Asia/Jakarta" });
    const jakartaDate = new Date(jakartaTimeString);
    const nextMidnight = new Date(jakartaDate);
    nextMidnight.setHours(24, 0, 0, 0);
    const diffMs = Math.max(0, nextMidnight.getTime() - jakartaDate.getTime());
    const hours = Math.floor(diffMs / (1e3 * 60 * 60));
    const minutes = Math.floor(diffMs % (1e3 * 60 * 60) / (1e3 * 60));
    const seconds = Math.floor(diffMs % (1e3 * 60) / 1e3);
    return {
      hours,
      minutes,
      seconds,
      formatted: `${hours} jam ${minutes} menit`
    };
  } catch {
    return { hours: 0, minutes: 0, seconds: 0, formatted: "tengah malam WIB" };
  }
}
function formatWibDate(isoString) {
  if (!isoString) return "-";
  try {
    const d = new Date(isoString);
    return new Intl.DateTimeFormat("id-ID", {
      timeZone: "Asia/Jakarta",
      dateStyle: "medium",
      timeStyle: "short"
    }).format(d) + " WIB";
  } catch {
    return isoString;
  }
}
function normalizeRentTime(t) {
  const m = t.trim().match(/^(\d{1,2})[:.](\d{1,2})/);
  if (m) {
    const hh = Math.min(23, Math.max(0, parseInt(m[1], 10))).toString().padStart(2, "0");
    const min = Math.min(59, Math.max(0, parseInt(m[2], 10))).toString().padStart(2, "0");
    return `${hh}:${min}`;
  }
  return "23:59";
}
function parseRentExpiryInput(dateStr, timeStr) {
  if (!dateStr || !dateStr.trim()) return void 0;
  const d = dateStr.trim();
  if (["permanen", "permanent", "none", "hapus", "unlimited", "lifetime", "-"].includes(d.toLowerCase())) {
    return void 0;
  }
  const durMatch = d.match(/^(\d+)\s*(d|hari|m|bulan|y|tahun)?$/i);
  if (durMatch) {
    const num = parseInt(durMatch[1], 10);
    const unit = (durMatch[2] || "d").toLowerCase();
    let days = num;
    if (unit === "m" || unit === "bulan") days = num * 30;
    if (unit === "y" || unit === "tahun") days = num * 365;
    const targetDate = new Date(Date.now() + days * 864e5);
    const yyyy = targetDate.getFullYear();
    const mm = String(targetDate.getMonth() + 1).padStart(2, "0");
    const dd = String(targetDate.getDate()).padStart(2, "0");
    const time = timeStr && timeStr.trim() ? normalizeRentTime(timeStr) : "23:59";
    return `${yyyy}-${mm}-${dd} ${time}`;
  }
  const ymdMatch = d.match(/^(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})(?:[ T](\d{1,2})[:.](\d{1,2}))?/);
  if (ymdMatch) {
    const yyyy = ymdMatch[1];
    const mm = ymdMatch[2].padStart(2, "0");
    const dd = ymdMatch[3].padStart(2, "0");
    let time = "23:59";
    if (ymdMatch[4] && ymdMatch[5]) {
      time = `${ymdMatch[4].padStart(2, "0")}:${ymdMatch[5].padStart(2, "0")}`;
    } else if (timeStr && timeStr.trim()) {
      time = normalizeRentTime(timeStr);
    }
    return `${yyyy}-${mm}-${dd} ${time}`;
  }
  const dmyMatch = d.match(/^(\d{1,2})[-/.](\d{1,2})[-/.](\d{4})(?:[ T](\d{1,2})[:.](\d{1,2}))?/);
  if (dmyMatch) {
    const dd = dmyMatch[1].padStart(2, "0");
    const mm = dmyMatch[2].padStart(2, "0");
    const yyyy = dmyMatch[3];
    let time = "23:59";
    if (dmyMatch[4] && dmyMatch[5]) {
      time = `${dmyMatch[4].padStart(2, "0")}:${dmyMatch[5].padStart(2, "0")}`;
    } else if (timeStr && timeStr.trim()) {
      time = normalizeRentTime(timeStr);
    }
    return `${yyyy}-${mm}-${dd} ${time}`;
  }
  return d;
}
function getRentExpiryStatus(expiryStr) {
  if (!expiryStr || !expiryStr.trim()) {
    return { isExpired: false, remainingText: "Permanen / Fleksibel", isSet: false };
  }
  try {
    const normalized = expiryStr.includes(" ") || expiryStr.includes("T") ? expiryStr : `${expiryStr} 23:59:59`;
    const expDate = new Date(normalized);
    const now = /* @__PURE__ */ new Date();
    const diffMs = expDate.getTime() - now.getTime();
    if (isNaN(diffMs)) {
      return { isExpired: false, remainingText: expiryStr, isSet: true };
    }
    if (diffMs <= 0) {
      return { isExpired: true, remainingText: "Masa Sewa Telah Habis!", isSet: true };
    }
    const days = Math.floor(diffMs / (1e3 * 60 * 60 * 24));
    const hours = Math.floor(diffMs % (1e3 * 60 * 60 * 24) / (1e3 * 60 * 60));
    const minutes = Math.floor(diffMs % (1e3 * 60 * 60) / (1e3 * 60));
    if (days > 0) {
      return { isExpired: false, remainingText: `Sisa ${days} hari ${hours} jam`, isSet: true };
    } else if (hours > 0) {
      return { isExpired: false, remainingText: `Sisa ${hours} jam ${minutes} menit`, isSet: true };
    } else {
      return { isExpired: false, remainingText: `Sisa ${minutes} menit`, isSet: true };
    }
  } catch {
    return { isExpired: false, remainingText: expiryStr, isSet: true };
  }
}
async function sendTelegramChatAction(chatId, action = "typing", customToken) {
  const tokenToUse = customToken || activeBotContextToken || botConfig.token;
  if (!tokenToUse) return false;
  try {
    const res = await callTelegramApi(tokenToUse, "sendChatAction", {
      chat_id: chatId,
      action
    }, 4e3);
    return !!(res && res.ok);
  } catch {
    return false;
  }
}
async function sendTelegramMessage(chatId, text, replyMarkup, parseMode = "Markdown", customToken) {
  const tokenToUse = customToken || activeBotContextToken || botConfig.token;
  if (!tokenToUse) return null;
  try {
    const payload = {
      chat_id: chatId,
      text
    };
    if (parseMode) {
      payload.parse_mode = parseMode;
    }
    if (replyMarkup) {
      payload.reply_markup = replyMarkup;
    }
    const res = await callTelegramApi(tokenToUse, "sendMessage", payload, 1e4);
    if (res && res.ok) {
      botConfig.stats.messagesSent += 1;
      saveBotConfig();
      addLog("outgoing", `Pesan terkirim: "${text.substring(0, 50)}${text.length > 50 ? "..." : ""}"`, chatId);
      const isGrp = Number(chatId) < 0;
      recordMessageTraffic({
        botId: activeBotContextToken ? "secondary_cluster" : "primary",
        botUsername: activeBotContextInfo?.username || currentBotInfo?.username || "axxosintbot",
        botName: activeBotContextInfo?.first_name || currentBotInfo?.first_name || "Bot Utama",
        isPrimaryBot: !activeBotContextToken,
        direction: "outgoing",
        chatId,
        chatType: isGrp ? "group" : "private",
        userName: isGrp ? `Grup ${chatId}` : `Pengguna ${chatId}`,
        text,
        status: "delivered"
      });
      return res.result;
    } else {
      if (parseMode && res?.description && (res.description.includes("can't parse entities") || res.description.includes("entity") || res.description.includes("parse"))) {
        addLog("warn", `Retrying message to ${chatId} as plain text due to markdown parse issue: ${res.description}`, chatId);
        const fallbackText = text.replace(/[*_`\[\]()~>#+=|{}.!-]/g, (c) => c === "`" || c === "*" ? "" : c);
        const fallbackPayload = {
          chat_id: chatId,
          text: fallbackText
        };
        if (replyMarkup) {
          fallbackPayload.reply_markup = replyMarkup;
        }
        const retryRes = await callTelegramApi(tokenToUse, "sendMessage", fallbackPayload, 1e4);
        if (retryRes && retryRes.ok) {
          botConfig.stats.messagesSent += 1;
          saveBotConfig();
          addLog("outgoing", `Pesan terkirim (fallback plain text): "${fallbackText.substring(0, 50)}..."`, chatId);
          return retryRes.result;
        }
      }
      addLog("error", `Gagal kirim pesan ke ${chatId}: ${res?.description}`, chatId);
    }
  } catch (err) {
    addLog("error", `Error sendTelegramMessage: ${err.message}`, chatId);
  }
  return null;
}
async function sendTelegramDocument(chatId, content, filename, caption, customToken) {
  const tokenToUse = customToken || activeBotContextToken || botConfig.token;
  if (!tokenToUse) return null;
  try {
    const isJson = filename.endsWith(".json");
    const mimeType = isJson ? "application/json" : "text/plain; charset=utf-8";
    const blob = new Blob([content], { type: mimeType });
    const cleanCaption = caption ? caption.replace(/[*_`\[\]]/g, "") : void 0;
    const formData = new FormData();
    formData.append("chat_id", String(chatId));
    formData.append("document", blob, filename);
    if (cleanCaption) {
      formData.append("caption", cleanCaption.substring(0, 1e3));
    }
    const res = await fetch(`https://api.telegram.org/bot${tokenToUse}/sendDocument`, {
      method: "POST",
      body: formData
    });
    const data = await res.json();
    if (data.ok) {
      botConfig.stats.messagesSent += 1;
      saveBotConfig();
      addLog("outgoing", `File dokumen terkirim: "${filename}"`, chatId);
      return data.result;
    } else {
      addLog("error", `Gagal kirim dokumen ke ${chatId}: ${data.description}`, chatId);
      console.error(`[Telegram] Gagal kirim dokumen ke ${chatId}:`, data.description);
      if (cleanCaption) {
        const retryForm = new FormData();
        retryForm.append("chat_id", String(chatId));
        retryForm.append("document", blob, filename);
        const retryRes = await fetch(`https://api.telegram.org/bot${tokenToUse}/sendDocument`, {
          method: "POST",
          body: retryForm
        });
        const retryData = await retryRes.json();
        if (retryData.ok) {
          botConfig.stats.messagesSent += 1;
          saveBotConfig();
          addLog("outgoing", `File dokumen terkirim (tanpa caption): "${filename}"`, chatId);
          return retryData.result;
        }
      }
    }
  } catch (err) {
    addLog("error", `Error sendTelegramDocument: ${err.message}`, chatId);
    console.error(`[Telegram] Error sendTelegramDocument:`, err.message);
  }
  return null;
}
function generateTxtReport(item) {
  let readable = "";
  try {
    const parsed = JSON.parse(item.rawResult);
    if (parsed && Array.isArray(parsed.results)) {
      readable = parsed.results.map((r, idx) => {
        const rec = r.record || r;
        const locNik = rec.nikLocation && rec.nikLocation !== "(-)" ? rec.nikLocation : rec.nik ? extractLocationFromNik(rec.nik) : "(-)";
        return `[DATA RECORD #${idx + 1}]
Nama Lengkap  : ${rec.fullName || "-"}
NIK           : ${rec.nik || "-"}
Lokasi (NIK)  : ${locNik || "(-)"}
Nomor Telepon : ${rec.phone || "-"}
Alamat Email  : ${rec.email || "-"}
Tanggal Lahir : ${rec.birthDate || "-"} (Usia: ${rec.age || "-"})
Jenis Kelamin : ${rec.gender || "-"}
Kota / Prov   : ${rec.city || "-"}, ${rec.province || "-"}
Tingkat Bahaya: ${rec.threatLevel || "-"}
Skor Akurasi  : ${r.precisionScore ? `${r.precisionScore}%` : "-"} (${r.predictionType || "-"})
Raw Data Line : ${rec.raw || "-"}
--------------------------------------------------------------------------------`;
      }).join("\n");
    }
  } catch {
    readable = item.rawResult;
  }
  return `================================================================================
LAPORAN HASIL PENCARIAN INTELIJEN OSINT LENGKAP
================================================================================
Target Pencarian   : ${item.target}
Kunci API          : ${item.apiKey}
Total Ditemukan    : ${item.totalMatches} data
Waktu Pencarian    : ${item.formattedWib}
Identitas Pengguna : ${item.userName || "-"} (Chat ID: ${item.chatId || "-"})
Status Berkas      : Asli & Utuh (Tanpa ada yang dipersingkat)
================================================================================

DAFTAR RECORD LENGKAP:
--------------------------------------------------------------------------------
${readable || item.rawResult}

================================================================================
RAW DUMP (JSON / RAW):
================================================================================
${item.rawResult}
================================================================================
Dicetak otomatis oleh Telegram Bot OSINT Intelligence.
`;
}
function saveSearchItemToDisk(item) {
  try {
    if (!import_fs2.default.existsSync(SEARCH_CACHE_DIR)) {
      import_fs2.default.mkdirSync(SEARCH_CACHE_DIR, { recursive: true });
    }
    const itemPath = import_path2.default.join(SEARCH_CACHE_DIR, `${item.id}.json`);
    import_fs2.default.writeFileSync(itemPath, JSON.stringify(item, null, 2), "utf8");
  } catch (err) {
    console.error("[SearchCache] Failed to save search cache to disk:", err.message);
  }
}
function findSearchHistoryItem(searchId, chatId) {
  if (!Array.isArray(botConfig.searchHistories)) {
    botConfig.searchHistories = [];
  }
  const histories = botConfig.searchHistories;
  if (searchId) {
    const direct = histories.find((h) => h.id === searchId);
    if (direct) return direct;
  }
  if (searchId) {
    const partial = histories.find((h) => h.id.includes(searchId) || searchId.includes(h.id));
    if (partial) return partial;
  }
  if (searchId) {
    try {
      const diskPath = import_path2.default.join(SEARCH_CACHE_DIR, `${searchId}.json`);
      if (import_fs2.default.existsSync(diskPath)) {
        const parsed = JSON.parse(import_fs2.default.readFileSync(diskPath, "utf8"));
        if (parsed && parsed.id) {
          if (!histories.some((h) => h.id === parsed.id)) {
            histories.unshift(parsed);
          }
          return parsed;
        }
      }
    } catch {
    }
  }
  if (chatId) {
    const userSearches = histories.filter((h) => Number(h.chatId) === Number(chatId));
    if (userSearches.length > 0) {
      return userSearches[0];
    }
    try {
      if (import_fs2.default.existsSync(SEARCH_CACHE_DIR)) {
        const files = import_fs2.default.readdirSync(SEARCH_CACHE_DIR).filter((f) => f.endsWith(".json"));
        const sortedFiles = files.sort((a, b) => {
          const sA = import_fs2.default.statSync(import_path2.default.join(SEARCH_CACHE_DIR, a)).mtimeMs;
          const sB = import_fs2.default.statSync(import_path2.default.join(SEARCH_CACHE_DIR, b)).mtimeMs;
          return sB - sA;
        });
        for (const f of sortedFiles) {
          try {
            const raw = import_fs2.default.readFileSync(import_path2.default.join(SEARCH_CACHE_DIR, f), "utf8");
            const parsed = JSON.parse(raw);
            if (parsed && Number(parsed.chatId) === Number(chatId)) {
              if (!histories.some((h) => h.id === parsed.id)) {
                histories.unshift(parsed);
              }
              return parsed;
            }
          } catch {
          }
        }
      }
    } catch {
    }
  }
  if (histories.length > 0) {
    return histories[0];
  }
  return null;
}
function formatOsintPresentation(target, apiKey, totalMatches, newRemaining, wibTime, resultText, searchId) {
  const isHuge = totalMatches > 50;
  let parsed = null;
  try {
    parsed = JSON.parse(resultText);
  } catch {
  }
  let warningSection = "";
  if (isHuge) {
    warningSection = `\u26A0\uFE0F *PERINGATAN PERANGKAT (HASIL > 50 DATA):*
Ditemukan *${totalMatches} data* hasil intelijen.
Menyalin (copy) teks puluhan ribu karakter sekaligus ke clipboard dapat menyebabkan aplikasi Telegram atau HP Anda mengalami *lag, freeze, atau crash*.
\u{1F449} *Sangat disarankan untuk mengunduh berkas lengkap via tombol \u{1F4E5} Unduh File (.txt / .json) di bawah agar aman & lancar.*
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
`;
  }
  let bodySection = "";
  if (parsed && Array.isArray(parsed.results) && parsed.results.length > 0) {
    const previewCount = Math.min(parsed.results.length, 4);
    const previews = parsed.results.slice(0, previewCount).map((r, idx) => {
      const rec = r.record || r;
      const nikVal = rec.nik || "";
      let locNik = rec.nikLocation && rec.nikLocation !== "(-)" ? rec.nikLocation : "";
      if (!locNik && nikVal) {
        locNik = extractLocationFromNik(nikVal);
      }
      if (!locNik) locNik = "(-)";
      const domisili = [rec.city, rec.province].filter(Boolean).join(", ") || rec.address || "(-)";
      return `\u{1F539} *[Data #${idx + 1}]* ${rec.fullName || "Tanpa Nama"}
   \u2022 *NIK:* \`${nikVal || "-"}\`
   \u2022 *\u{1F4CD} Lokasi (NIK):* ${locNik}
   \u2022 *HP:* \`${rec.phone || "-"}\`
   \u2022 *Email:* \`${rec.email || "-"}\`
   \u2022 *TTL / Usia:* ${rec.birthDate || "-"} (${rec.age ? `${rec.age} thn` : "-"})
   \u2022 *Domisili:* ${domisili}`;
    }).join("\n\n");
    bodySection = `\u{1F4C4} *Hasil Intelijen (${previewCount} dari ${totalMatches} Data):*

${previews}${totalMatches > previewCount ? `

\u{1F4A1} _... dan ${totalMatches - previewCount} data lainnya._
_Gunakan tombol di bawah untuk menyalin seluruh hasil atau unduh berkas lengkap!_` : ""}`;
  } else if (resultText.length <= 2500) {
    const match16 = resultText.match(/\b([1-9][0-9]{15})\b/);
    const locFromRaw = match16 ? extractLocationFromNik(match16[1]) : "(-)";
    bodySection = `\u{1F4CD} *Lokasi Terdeteksi (NIK):* ${locFromRaw}

\`\`\`json
${resultText}
\`\`\``;
  } else {
    const safeSnippet = resultText.substring(0, 1500).trim();
    const match16 = resultText.match(/\b([1-9][0-9]{15})\b/);
    const locFromRaw = match16 ? extractLocationFromNik(match16[1]) : "(-)";
    bodySection = `\u{1F4CD} *Lokasi Terdeteksi (NIK):* ${locFromRaw}

\`\`\`
${safeSnippet}
...
\`\`\`

\u{1F4A1} _Menampilkan pratinjau. Gunakan tombol di bawah untuk menyalin seluruh ${totalMatches} data atau unduh berkas lengkap!_`;
  }
  const messageText = `\u{1F3AF} *HASIL PENCARIAN INTELIJEN OSINT*
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
\u{1F3AF} *Target:* \`${target}\`
\u{1F511} *API Key:* \`${apiKey}\`
\u{1F4CA} *Total Ditemukan:* *${totalMatches} data hasil intelijen*
\u{1F4E6} *Sisa Kuota:* ${newRemaining}
\u{1F552} *Waktu:* ${wibTime.fullStr}
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
${warningSection}${bodySection}
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
\u{1F4A1} _Gunakan perintah \`api ${apiKey}\` untuk cek sisa kuota, atau \`/history\` untuk riwayat._`;
  const keyboard = [
    [
      { text: "\u{1F4E5} Download File (.txt)", callback_data: `dl_txt_${searchId}` },
      { text: "\u{1F4E5} Unduh File (.json)", callback_data: `dl_json_${searchId}` }
    ],
    [
      { text: `\u{1F4CB} Salin Seluruh Hasil (${totalMatches} Data)`, callback_data: `copy_all_${searchId}` }
    ],
    [
      { text: "\u{1F4DC} Riwayat Saya", callback_data: "user_history" },
      { text: "\u{1F3E0} Menu Utama", callback_data: "cmd_menu" }
    ]
  ];
  return { messageText, replyMarkup: { inline_keyboard: keyboard } };
}
async function handleUserHistoryCommand(chatId, senderName) {
  const userHistories = (botConfig.searchHistories || []).filter((h) => h.chatId === chatId).sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  if (userHistories.length === 0) {
    await sendTelegramMessage(
      chatId,
      `\u{1F4DC} *RIWAYAT PENCARIAN INTELIJEN SAYA*
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
\u{1F464} *Nama Pengguna:* ${senderName}
\u{1F194} *Chat ID:* \`${chatId}\`
\u{1F4CA} *Total Riwayat:* 0 pencarian
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
Belum ada riwayat pencarian OSINT untuk akun Anda.

\u{1F4D6} *Cara Mencari:*
Ketik: \`search: <target> <apiKey>\`
*Contoh:* \`search: jokowi ppp\`

\u{1F4A1} _Setiap pencarian Anda otomatis tersimpan secara privat khusus untuk Chat ID Anda._`,
      {
        inline_keyboard: [
          [{ text: "\u{1F50D} Cara Pakai OSINT", callback_data: "cmd_osint" }],
          [{ text: "\u{1F3E0} Menu Utama", callback_data: "cmd_menu" }]
        ]
      }
    );
    return;
  }
  const displayItems = userHistories.slice(0, 6);
  const listFormatted = displayItems.map(
    (h, idx) => `*${idx + 1}.* \u{1F3AF} Target: \`${h.target}\`
   \u{1F4C5} ${h.formattedWib}
   \u{1F4CA} Hasil: *${h.totalMatches} data* | Key: \`${h.apiKey}\``
  ).join("\n\n");
  const historyCard = `\u{1F4DC} *RIWAYAT PENCARIAN SAYA (CHAT ID: ${chatId})*
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
\u{1F464} *Nama Pengguna:* ${senderName}
\u{1F4CA} *Total Riwayat Tersimpan:* *${userHistories.length} pencarian*
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
${listFormatted}
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
\u{1F4A1} _Pilih tombol di bawah untuk membuka kembali hasil atau unduh berkas (GRATIS tanpa memotong kuota lagi):_`;
  const keyboard = [];
  for (let i = 0; i < Math.min(displayItems.length, 3); i++) {
    const item = displayItems[i];
    keyboard.push([
      { text: `\u{1F50D} Buka #${i + 1} (${item.target.substring(0, 10)})`, callback_data: `view_hist_${item.id}` },
      { text: `\u{1F4E5} Unduh #${i + 1} (.txt)`, callback_data: `dl_txt_${item.id}` }
    ]);
  }
  keyboard.push([
    { text: "\u{1F5D1}\uFE0F Hapus Riwayat Saya", callback_data: "confirm_clear_my_hist" },
    { text: "\u{1F3E0} Menu Utama", callback_data: "cmd_menu" }
  ]);
  await sendTelegramMessage(chatId, historyCard, { inline_keyboard: keyboard });
}
function getMainInlineMenu(isOsintOn = false) {
  const menuCfg = botConfig.menuConfig || DEFAULT_MENU_CONFIG;
  const keyboard = [];
  const rowQuota = [];
  if (menuCfg.showClaimButtonInMenu !== false) {
    rowQuota.push({ text: "\u{1F381} Klaim Kuota Gratis", callback_data: "cmd_claim_menu" });
  }
  if (menuCfg.showQuotaButtonInMenu !== false) {
    rowQuota.push({ text: "\u{1F48E} Sisa Kuota Saya", callback_data: "cmd_my_quota" });
  }
  if (rowQuota.length > 0) keyboard.push(rowQuota);
  if (menuCfg.showReferralButtonInMenu !== false) {
    keyboard.push([
      { text: "\u{1F465} Undang Teman & Tabungan Kuota", callback_data: "cmd_referral" }
    ]);
  }
  const rowOsint = [];
  if (menuCfg.showOsintButtonInMenu !== false) {
    rowOsint.push({
      text: isOsintOn ? "\u{1F7E2} OSINT Intel (AKTIF)" : "\u{1F534} OSINT Intel (OFF)",
      callback_data: "cmd_osint"
    });
  }
  if (menuCfg.showPriceButtonInMenu !== false) {
    rowOsint.push({ text: "\u{1F48E} Tarif & Cek API Key", callback_data: "cmd_pricing" });
  }
  if (rowOsint.length > 0) keyboard.push(rowOsint);
  keyboard.push([
    { text: "\u{1F194} Cek Chat ID & Profil", callback_data: "cmd_id" },
    { text: "\u{1F916} Detail & Info Bot", callback_data: "cmd_bot" }
  ]);
  keyboard.push([
    { text: "\u{1F3D3} Ping & Status Server", callback_data: "cmd_ping" },
    { text: "\u23F0 Waktu Real-Time (WIB)", callback_data: "cmd_waktu" }
  ]);
  keyboard.push([
    { text: "\u{1F916} Sewa Bot Telegram (Dedicated)", callback_data: "cmd_rental_info" },
    { text: "\u{1F310} Info Multi-Bot", callback_data: "cmd_multibot_info" }
  ]);
  const rowOwner = [{ text: "\u{1F9EE} Kalkulator Cepat", callback_data: "cmd_calc_info" }];
  if (menuCfg.showOwnerButtonInMenu !== false) {
    rowOwner.push({ text: "\u{1F4DE} Hubungi Owner (@flood1233)", callback_data: "cmd_owner" });
  }
  keyboard.push(rowOwner);
  const allCustomMenus = [
    ...botConfig.customMenus || [],
    ...menuCfg.customButtons || []
  ].filter((m, idx, self) => m.enabled && self.findIndex((x) => x.id === m.id) === idx);
  for (let i = 0; i < allCustomMenus.length; i += 2) {
    const item1 = allCustomMenus[i];
    const item2 = allCustomMenus[i + 1];
    const row = [];
    if (item1) {
      if (item1.type === "url" && item1.url) {
        row.push({ text: item1.label, url: item1.url });
      } else {
        row.push({ text: item1.label, callback_data: `cmenu_${item1.id}` });
      }
    }
    if (item2) {
      if (item2.type === "url" && item2.url) {
        row.push({ text: item2.label, url: item2.url });
      } else {
        row.push({ text: item2.label, callback_data: `cmenu_${item2.id}` });
      }
    }
    if (row.length > 0) {
      keyboard.push(row);
    }
  }
  const bottomRow = [{ text: "\u{1F4DC} Riwayat Pencarian Saya", callback_data: "user_history" }];
  if (menuCfg.showHelpButtonInMenu !== false) {
    bottomRow.push({ text: "\u{1F4D6} Daftar Perintah Lengkap", callback_data: "cmd_help" });
  }
  keyboard.push(bottomRow);
  return {
    inline_keyboard: keyboard
  };
}
function getPricingData(langCode) {
  const code = (langCode || "").toLowerCase();
  if (code.startsWith("ms") || code.startsWith("my")) {
    return {
      currency: "MYR (RM - Ringgit Malaysia)",
      formatted: `\u2022 5x Pakai: *RM 1.00*
\u2022 10x Pakai: *RM 1.80*
\u2022 15x Pakai: *RM 3.50* _(+ BONUS 1x Pakai)_
\u2022 40x Pakai: *RM 8.00* _(+ BONUS 1x Pakai)_
\u2022 100x Pakai: *RM 16.00* _(+ BONUS 2x Pakai)_
\u2022 Unlimited: *RM 32.00* _(Akses Tanpa Batas Kuota)_`,
      note: "\u{1F381} *BONUS KHUSUS:* Pembelian di atas RM 3.50 otomatis mendapatkan bonus 1x pakai ekstra!"
    };
  } else if (code.startsWith("sg")) {
    return {
      currency: "SGD (S$ - Singapore Dollar)",
      formatted: `\u2022 5x Pakai: *S$ 0.35*
\u2022 10x Pakai: *S$ 0.60*
\u2022 15x Pakai: *S$ 1.20* _(+ BONUS 1x Pakai)_
\u2022 40x Pakai: *S$ 2.80* _(+ BONUS 1x Pakai)_
\u2022 100x Pakai: *S$ 5.50* _(+ BONUS 2x Pakai)_
\u2022 Unlimited: *S$ 12.00* _(Akses Tanpa Batas Kuota)_`,
      note: "\u{1F381} *BONUS KHUSUS:* Pembelian di atas S$ 1.20 otomatis mendapatkan bonus 1x pakai ekstra!"
    };
  } else if (code.startsWith("en")) {
    return {
      currency: "USD ($ - US Dollar)",
      formatted: `\u2022 5x Usage: *$0.25*
\u2022 10x Usage: *$0.40*
\u2022 15x Usage: *$0.75* _(+ BONUS 1x Usage)_
\u2022 40x Usage: *$1.75* _(+ BONUS 1x Usage)_
\u2022 100x Usage: *$3.50* _(+ BONUS 2x Usage)_
\u2022 Unlimited: *$7.00* _(Unlimited Queries)_`,
      note: "\u{1F381} *SPECIAL BONUS:* Purchases over $0.75 automatically receive +1x free bonus usage!"
    };
  } else {
    return {
      currency: "IDR (Rp - Rupiah Indonesia)",
      formatted: `\u2022 5x Pakai: *Rp 3.000*
\u2022 10x Pakai: *Rp 5.000*
\u2022 15x Pakai: *Rp 10.000* _(+ BONUS 1x Pakai)_
\u2022 40x Pakai: *Rp 25.000* _(+ BONUS 1x Pakai)_
\u2022 100x Pakai: *Rp 50.000* _(+ BONUS 2x Pakai)_
\u2022 Unlimited: *Rp 100.000* _(Akses Sepuasnya Tanpa Batas Kuota!)_`,
      note: "\u{1F381} *BONUS KHUSUS:* Pembelian API Key di atas Rp 10.000 otomatis mendapatkan bonus 1x pakai ekstra!"
    };
  }
}
async function broadcastOsintStatusChange(isOnline) {
  const users = botConfig.activeUsers || [];
  if (users.length === 0 || !botConfig.token) return;
  const header = isOnline ? "\u{1F7E2} *PEMBERITAHUAN: SERVER DATA OSINT DIAKTIFKAN (ON)*" : "\u{1F534} *PEMBERITAHUAN: SERVER DATA OSINT DINONAKTIFKAN (OFF)*";
  const body = isOnline ? `Halo! Server Data OSINT baru saja *DINYALAKAN (ON)* oleh Owner.

Sekarang Anda sudah bisa melakukan pencarian intelijen menggunakan API Key.

\u{1F4D6} *Cara Pakai:*
\`search: <target> <apiKey>\`
*Contoh:* \`search: jokowi ppp\`

Bagi yang belum memiliki API Key atau ingin top up kuota, silakan hubungi Admin:
\u{1F4DE} *Owner Telegram:* @flood1233
_(Bebas mau chat ataupun call, asal tidak spam)_` : `Halo! Server Data OSINT saat ini telah *DIMATIKAN (OFF)* sementara oleh Owner untuk pemeliharaan server.

Fitur pencarian OSINT saat ini ditutup sementara.

Jika Anda memiliki keperluan mendesak atau ingin meminta server diaktifkan, silakan hubungi Owner:
\u{1F4DE} *Owner Telegram:* @flood1233
_(Bebas mau chat ataupun call, asal tidak spam)_`;
  const fullText = `${header}
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
${body}
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501`;
  addLog("system", `Menyiarkan notifikasi status OSINT (${isOnline ? "ON" : "OFF"}) ke ${users.length} pengguna...`);
  let count = 0;
  for (const u of users) {
    try {
      await sendTelegramMessage(u.chatId, fullText, {
        inline_keyboard: [
          [{ text: "\u{1F4DE} Hubungi Owner @flood1233", url: "https://t.me/flood1233" }],
          [{ text: "\u{1F3E0} Buka Menu Bot", callback_data: "cmd_menu" }]
        ]
      });
      count++;
    } catch {
    }
    await new Promise((resolve) => setTimeout(resolve, 50));
  }
  addLog("system", `Siaran status OSINT selesai: ${count} pengguna berhasil menerima notifikasi.`);
}
function registerOrUpdateUser(fromUser, chat) {
  const userId = Number(fromUser.id);
  const isPrivate = chat.type === "private";
  const numericChatId = isPrivate ? userId : Number(chat.id);
  const now = (/* @__PURE__ */ new Date()).toISOString();
  let existing = botConfig.activeUsers.find(
    (u) => u.userId && Number(u.userId) === userId || Number(u.chatId) === userId
  );
  if (existing) {
    existing.userId = userId;
    existing.chatId = userId;
    existing.firstName = fromUser.first_name || existing.firstName;
    existing.lastName = fromUser.last_name || existing.lastName;
    existing.username = fromUser.username || existing.username;
    existing.lastSeen = now;
    existing.totalMessages += 1;
    existing.isVerified = true;
    if (fromUser.language_code) {
      existing.languageCode = fromUser.language_code;
    }
    existing.personalApiKey = `usr_${userId}`;
    if (typeof existing.personalQuota !== "number") {
      existing.personalQuota = 0;
    }
    if (typeof existing.referralVaultBalance !== "number") {
      existing.referralVaultBalance = 0;
    }
    if (typeof existing.totalReferralsCount !== "number") {
      existing.totalReferralsCount = 0;
    }
    if (typeof existing.totalReferralQuotaClaimed !== "number") {
      existing.totalReferralQuotaClaimed = 0;
    }
    if (persistentClaimedUserIds.has(userId)) {
      existing.hasClaimedNewUserQuota = true;
    } else if (typeof existing.hasClaimedNewUserQuota !== "boolean") {
      existing.hasClaimedNewUserQuota = false;
    }
    if (typeof existing.dailyQuotaClaimsCount !== "number") {
      existing.dailyQuotaClaimsCount = 0;
    }
    syncUserApiKey(existing);
    saveBotConfig();
    return existing;
  } else {
    const isClaimedNew = persistentClaimedUserIds.has(userId);
    const newUser = {
      chatId: userId,
      userId,
      firstName: fromUser.first_name || "Anonymous",
      lastName: fromUser.last_name || "",
      username: fromUser.username || "",
      firstSeen: now,
      lastSeen: now,
      totalMessages: 1,
      type: isPrivate ? "private" : chat.type,
      isVerified: true,
      // Permanent verified status
      verifiedAt: now,
      languageCode: fromUser.language_code || "id",
      hasClaimedNewUserQuota: isClaimedNew,
      dailyQuotaClaimsCount: 0,
      personalQuota: 0,
      referralVaultBalance: 0,
      totalReferralsCount: 0,
      totalReferralQuotaClaimed: 0,
      personalApiKey: `usr_${userId}`
    };
    botConfig.activeUsers.unshift(newUser);
    botConfig.stats.activeUsersCount = botConfig.activeUsers.length;
    syncUserApiKey(newUser);
    saveBotConfig();
    return newUser;
  }
}
async function handleClaimNewUserQuota(userId, replyChatId, senderName) {
  const numericUserId = Number(userId);
  const targetReplyChatId = Number(replyChatId);
  const lockKey = `claim_new_${numericUserId}`;
  if (activeClaimLocks.has(lockKey)) {
    return;
  }
  activeClaimLocks.add(lockKey);
  try {
    const user = botConfig.activeUsers.find(
      (u) => u.userId && Number(u.userId) === numericUserId || Number(u.chatId) === numericUserId
    );
    if (!user) {
      await sendTelegramMessage(targetReplyChatId, "\u26A0\uFE0F Data akun Anda tidak ditemukan. Silakan kirim pesan /start terlebih dahulu.");
      return;
    }
    const quotaCfg = botConfig.quotaConfig || DEFAULT_QUOTA_CONFIG;
    if (!quotaCfg.newUserQuotaEnabled) {
      await sendTelegramMessage(
        targetReplyChatId,
        `\u26A0\uFE0F *KLAIM DINONAKTIFKAN*

Program bonus kuota sambutan pengguna baru saat ini sedang dinonaktifkan oleh administrator.
Silakan gunakan menu Klaim Harian atau hubungi owner @flood1233.`
      );
      return;
    }
    if (user.hasClaimedNewUserQuota || persistentClaimedUserIds.has(numericUserId)) {
      user.hasClaimedNewUserQuota = true;
      persistentClaimedUserIds.add(numericUserId);
      savePersistentClaimedUsers();
      saveBotConfig();
      const claimDateStr = formatWibDate(user.newUserQuotaClaimedAt);
      const todayWib = getWibDateString();
      const isDailyClaimed = user.dailyQuotaLastClaimedDate === todayWib;
      const countdown = getTimeUntilNextWibMidnight();
      const rejectCard = `\u{1F6E1}\uFE0F *KLAIM DITOLAK: VULNERABILITY SHIELD AKTIF*
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
\u26A0\uFE0F *Pemberitahuan Keamanan:*
Akun Anda (*User ID:* \`${numericUserId}\`) *SUDAH PERNAH* mengklaim Kuota Pengguna Baru sebelumnya pada:
\u{1F552} *${claimDateStr}*

\u{1F512} *Ketentuan Anti-Exploit:*
\u2022 Kuota Pengguna Baru *HANYA DAPAT DIKLAIM 1X SEUMUR HIDUP* per akun Telegram.
\u2022 Menggunakan grup berbeda, menghapus chat, ataupun mendaftar ulang TIDAK AKAN mereset jatah ini.
\u2022 Sistem secara ketat mendeteksi dan menolak eksploitasi ganda.

\u{1F48E} *Status Kuota Anda Saat Ini:*
\u2022 Sisa Kuota Pribadi: *${user.personalQuota || 0}x Pencarian*
\u2022 API Key Pribadi: \`${user.personalApiKey || `usr_${numericUserId}`}\`
\u2022 Kuota Harian Hari Ini: ${isDailyClaimed ? `\u2705 Sudah Diambil (Reset: ${countdown.formatted})` : "\u2728 *Tersedia untuk Diklaim!*"}

\u{1F4A1} *Solusi Tambah Kuota Gratis:*
Anda dapat mengklaim *Kuota Harian Gratis (+${quotaCfg.dailyQuotaAmount}x)* setiap 24 jam sekali (pukul 00:00 WIB) atau hubungi Owner @flood1233 untuk top up.`;
      await sendTelegramMessage(targetReplyChatId, rejectCard, {
        inline_keyboard: [
          [{ text: `\u{1F4C5} Klaim Kuota Harian (+${quotaCfg.dailyQuotaAmount}x)`, callback_data: "claim_daily" }],
          [{ text: "\u{1F48E} Cek Sisa Kuota Saya", callback_data: "cmd_my_quota" }],
          [{ text: "\u{1F3E0} Kembali ke Menu Utama", callback_data: "cmd_menu" }]
        ]
      });
      return;
    }
    const BONUS_AMOUNT = quotaCfg.newUserQuotaAmount || 5;
    user.hasClaimedNewUserQuota = true;
    user.newUserQuotaClaimedAt = (/* @__PURE__ */ new Date()).toISOString();
    user.personalQuota = (user.personalQuota || 0) + BONUS_AMOUNT;
    user.personalApiKey = `usr_${numericUserId}`;
    persistentClaimedUserIds.add(numericUserId);
    savePersistentClaimedUsers();
    syncUserApiKey(user);
    saveBotConfig();
    addLog("system", `Pengguna ${numericUserId} (${senderName}) berhasil klaim Kuota Pengguna Baru (+${BONUS_AMOUNT} kuota). Total: ${user.personalQuota}x`);
    const successCard = `\u{1F389} *SELAMAT! KLAIM KUOTA PENGGUNA BARU BERHASIL*
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
\u{1F464} *Pengguna:* ${senderName}
\u{1F194} *User ID:* \`${numericUserId}\`
\u{1F381} *Hadiah Sambutan:* *+${BONUS_AMOUNT}x Kuota Pencarian OSINT*
\u{1F48E} *Total Sisa Kuota Pribadi:* *${user.personalQuota}x Pemakaian*
\u{1F511} *API Key Pribadi Anda:* \`${user.personalApiKey}\`
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
\u{1F4D6} *PANDUAN PENGGUNAAN KUOTA (LANGSUNG AKTIF!):*
1\uFE0F\u20E3 *Format Otomatis (Langsung Tanpa API Key):*
   Ketik: \`search: <target>\` atau \`/search <target>\` atau \`cari: <target>\`
   _Contoh:_ \`search: jokowi\` atau \`cari: slamet\`
   _Bot akan langsung mencari di berkas arsip 1.000.000 data dan otomatis memotong 1 kuota pribadi Anda!_

2\uFE0F\u20E3 *Format Manual:*
   \`search: <target> ${user.personalApiKey}\`

\u{1F4A1} *Tips:* Sisa kuota HANYA berkurang jika data target berhasil ditemukan di dataset!`;
    await sendTelegramMessage(targetReplyChatId, successCard, {
      inline_keyboard: [
        [{ text: `\u{1F4C5} Klaim Kuota Harian Juga (+${quotaCfg.dailyQuotaAmount}x)`, callback_data: "claim_daily" }],
        [{ text: "\u{1F48E} Cek Kuota & Profil", callback_data: "cmd_my_quota" }],
        [{ text: "\u{1F3E0} Buka Menu Utama", callback_data: "cmd_menu" }]
      ]
    });
  } finally {
    activeClaimLocks.delete(lockKey);
  }
}
async function handleClaimDailyQuota(userId, replyChatId, senderName) {
  const numericUserId = Number(userId);
  const targetReplyChatId = Number(replyChatId);
  const lockKey = `claim_daily_${numericUserId}`;
  if (activeClaimLocks.has(lockKey)) {
    return;
  }
  activeClaimLocks.add(lockKey);
  try {
    const user = botConfig.activeUsers.find(
      (u) => u.userId && Number(u.userId) === numericUserId || Number(u.chatId) === numericUserId
    );
    if (!user) {
      await sendTelegramMessage(targetReplyChatId, "\u26A0\uFE0F Data akun Anda tidak ditemukan. Silakan kirim pesan /start terlebih dahulu.");
      return;
    }
    const quotaCfg = botConfig.quotaConfig || DEFAULT_QUOTA_CONFIG;
    if (!quotaCfg.dailyQuotaEnabled) {
      await sendTelegramMessage(
        targetReplyChatId,
        `\u26A0\uFE0F *KLAIM HARIAN DINONAKTIFKAN*

Program klaim kuota harian gratis saat ini sedang dinonaktifkan oleh administrator.
Silakan hubungi owner @flood1233.`
      );
      return;
    }
    const todayWib = getWibDateString();
    const countdown = getTimeUntilNextWibMidnight();
    if (user.dailyQuotaLastClaimedDate === todayWib) {
      const rejectCard = `\u{1F6E1}\uFE0F *KLAIM DITOLAK: JATAH HARIAN SUDAH DIAMBIL*
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
\u{1F464} *Pengguna:* ${senderName}
\u{1F194} *User ID:* \`${numericUserId}\`
\u{1F4C5} *Tanggal Hari Ini:* ${todayWib} WIB

\u26A0\uFE0F *Pemberitahuan Sistem:*
Anda *SUDAH MENGKLAIM* jatah Kuota Harian untuk hari ini. Kuota harian dibatasi *1x per hari kalender WIB*.

\u23F3 *Reset Kuota Harian Berikutnya:*
\u2022 Waktu Reset: Pukul 00:00 WIB (Tengah Malam)
\u2022 Sisa Waktu: *${countdown.hours} jam ${countdown.minutes} menit lagi*

\u{1F48E} *Sisa Kuota Pribadi Anda:* *${user.personalQuota || 0}x Pemakaian*
\u{1F511} *API Key Pribadi:* \`${user.personalApiKey || `usr_${numericUserId}`}\`

\u{1F6E1}\uFE0F _Sistem perlindungan anti-exploit aktif melindungi integritas kuota._`;
      await sendTelegramMessage(targetReplyChatId, rejectCard, {
        inline_keyboard: [
          [{ text: "\u{1F48E} Cek Kuota Saya", callback_data: "cmd_my_quota" }],
          [{ text: "\u{1F4DE} Top Up via Owner", callback_data: "cmd_owner" }],
          [{ text: "\u{1F3E0} Kembali ke Menu", callback_data: "cmd_menu" }]
        ]
      });
      return;
    }
    const DAILY_AMOUNT = quotaCfg.dailyQuotaAmount || 2;
    user.dailyQuotaLastClaimedDate = todayWib;
    user.dailyQuotaLastClaimedAt = (/* @__PURE__ */ new Date()).toISOString();
    user.dailyQuotaClaimsCount = (user.dailyQuotaClaimsCount || 0) + 1;
    user.personalQuota = (user.personalQuota || 0) + DAILY_AMOUNT;
    if (!user.personalApiKey) {
      user.personalApiKey = `usr_${numericUserId}`;
    }
    syncUserApiKey(user);
    saveBotConfig();
    addLog("system", `Pengguna ${numericUserId} (${senderName}) berhasil klaim Kuota Harian (+${DAILY_AMOUNT} kuota). Total: ${user.personalQuota}x`);
    const successCard = `\u2728 *ALHAMDULILLAH! KLAIM KUOTA HARIAN BERHASIL*
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
\u{1F464} *Pengguna:* ${senderName}
\u{1F4C5} *Tanggal Klaim:* ${todayWib} WIB
\u{1F381} *Bonus Kuota Harian:* *+${DAILY_AMOUNT}x Kuota OSINT Gratis*
\u{1F48E} *Total Sisa Kuota Pribadi:* *${user.personalQuota}x Pemakaian*
\u{1F511} *API Key Pribadi Anda:* \`${user.personalApiKey}\`
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
\u{1F552} *Informasi Reset:*
Jatah harian berikutnya akan aktif kembali besok setelah pukul 00:00 WIB.

\u{1F4D6} *Cara Pakai Kuota:*
Ketik: \`search: <target>\` atau \`/search <target>\` atau \`cari: <target>\``;
    await sendTelegramMessage(targetReplyChatId, successCard, {
      inline_keyboard: [
        [{ text: "\u{1F50D} Cara Pakai OSINT", callback_data: "cmd_osint" }],
        [{ text: "\u{1F48E} Cek Sisa Kuota", callback_data: "cmd_my_quota" }],
        [{ text: "\u{1F3E0} Buka Menu Utama", callback_data: "cmd_menu" }]
      ]
    });
  } finally {
    activeClaimLocks.delete(lockKey);
  }
}
async function sendClaimQuotaDashboard(userId, replyChatId, senderName) {
  const numericUserId = Number(userId);
  const targetReplyChatId = Number(replyChatId);
  const user = botConfig.activeUsers.find(
    (u) => u.userId && Number(u.userId) === numericUserId || Number(u.chatId) === numericUserId
  );
  const quotaCfg = botConfig.quotaConfig || DEFAULT_QUOTA_CONFIG;
  const todayWib = getWibDateString();
  const countdown = getTimeUntilNextWibMidnight();
  const isNewClaimed = Boolean(user?.hasClaimedNewUserQuota);
  const isDailyClaimed = user?.dailyQuotaLastClaimedDate === todayWib;
  const personalQuota = user?.personalQuota || 0;
  const personalKey = user?.personalApiKey || `usr_${numericUserId}`;
  const dashboardText = `\u{1F381} *DASHBOARD KLAIM KUOTA GRATIS*
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
\u{1F464} *Pengguna:* ${senderName}
\u{1F194} *User ID:* \`${numericUserId}\`
\u{1F48E} *Saldo Kuota Pribadi:* *${personalQuota}x Pencarian*
\u{1F511} *API Key Pribadi:* \`${personalKey}\`
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
\u{1F4CB} *STATUS KLAIM ANDA:*

1\uFE0F\u20E3 *KUOTA PENGGUNA BARU (+${quotaCfg.newUserQuotaAmount}x Kuota)*
\u2022 Status: ${isNewClaimed ? "\u2705 *SUDAH DIKLAIM* (1x seumur hidup)" : quotaCfg.newUserQuotaEnabled ? "\u{1F381} *TERSEDIA! (Belum Diklaim)*" : "\u23F8\uFE0F *Dinonaktifkan Admin*"}
\u2022 Keterangan: Bonus selamat datang khusus pengguna bot.

2\uFE0F\u20E3 *KUOTA HARIAN (+${quotaCfg.dailyQuotaAmount}x Kuota)*
\u2022 Status: ${isDailyClaimed ? `\u2705 *SUDAH DIKLAIM HARI INI*
  \u23F3 Reset: *${countdown.hours}j ${countdown.minutes}m lagi* (00:00 WIB)` : quotaCfg.dailyQuotaEnabled ? "\u2728 *SIAP DIKLAIM HARI INI!*" : "\u23F8\uFE0F *Dinonaktifkan Admin*"}
\u2022 Keterangan: Kuota gratis yang bisa diklaim setiap 24 jam kalender WIB.
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
\u{1F6E1}\uFE0F *Sistem Keamanan Anti-Vulnerability Aktif:*
Setiap klaim diverifikasi secara ketat berdasarkan User ID terdaftar. Perintah /id tidak akan mereset status klaim Anda.`;
  const keyboard = [];
  if (!isNewClaimed && quotaCfg.newUserQuotaEnabled) {
    keyboard.push([{ text: `\u{1F381} Klaim Kuota Pengguna Baru (+${quotaCfg.newUserQuotaAmount}x)`, callback_data: "claim_new_user" }]);
  }
  if (!isDailyClaimed && quotaCfg.dailyQuotaEnabled) {
    keyboard.push([{ text: `\u{1F4C5} Klaim Kuota Harian (+${quotaCfg.dailyQuotaAmount}x)`, callback_data: "claim_daily" }]);
  } else if (quotaCfg.dailyQuotaEnabled) {
    keyboard.push([{ text: `\u23F3 Kuota Harian Sudah Diambil (${countdown.hours}j ${countdown.minutes}m lagi)`, callback_data: "claim_daily" }]);
  }
  keyboard.push([
    { text: "\u{1F48E} Cek Kuota Saya", callback_data: "cmd_my_quota" },
    { text: "\u{1F3E0} Menu Utama", callback_data: "cmd_menu" }
  ]);
  await sendTelegramMessage(targetReplyChatId, dashboardText, { inline_keyboard: keyboard });
}
async function sendUserQuotaStatus(userId, replyChatId, senderName) {
  const numericUserId = Number(userId);
  const targetReplyChatId = Number(replyChatId);
  const user = botConfig.activeUsers.find(
    (u) => u.userId && Number(u.userId) === numericUserId || Number(u.chatId) === numericUserId
  );
  const quotaCfg = botConfig.quotaConfig || DEFAULT_QUOTA_CONFIG;
  const todayWib = getWibDateString();
  const countdown = getTimeUntilNextWibMidnight();
  const personalQuota = user?.personalQuota || 0;
  const personalKey = user?.personalApiKey || `usr_${numericUserId}`;
  const statusCard = `\u{1F48E} *INFORMASI KUOTA & PROFIL PRIBADI*
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
\u{1F464} *Nama Pengguna:* ${senderName}
\u{1F194} *User ID:* \`${numericUserId}\`
\u{1F512} *Status Akun:* ${user?.isVerified ? "\u2705 *Terverifikasi Resmi*" : "\u26A0\uFE0F *Belum Verifikasi*"}
\u{1F4C5} *Terdaftar Sejak:* ${formatWibDate(user?.firstSeen)}
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
\u{1F4CA} *RINCIAN KUOTA PRIBADI:*
\u2022 *Sisa Kuota Aktif:* *${personalQuota}x Pencarian OSINT*
\u2022 *\u{1F4BC} Saldo Tabungan Kuota:* *${user?.referralVaultBalance || 0}x Kuota*
\u2022 *API Key Pribadi:* \`${personalKey}\`

\u{1F381} *STATUS JATAH KLAIM:*
\u2022 *Kuota Pengguna Baru (${quotaCfg.newUserQuotaAmount}x):* ${user?.hasClaimedNewUserQuota ? "\u2705 Sudah Diklaim (1x seumur hidup)" : "\u{1F381} *Belum Diklaim (Siap Ambil)*"}
\u2022 *Kuota Harian (${quotaCfg.dailyQuotaAmount}x):* ${user?.dailyQuotaLastClaimedDate === todayWib ? `\u2705 Sudah Diklaim (Reset: ${countdown.hours}j ${countdown.minutes}m lagi)` : "\u2728 *Tersedia Hari Ini!*"}
\u2022 *Referral & Tabungan:* ${(user?.referralVaultBalance || 0) > 0 ? `\u{1F4BC} *Ada ${user?.referralVaultBalance || 0}x Kuota di Tabungan (Siap Ditarik)*` : "\u{1F517} Bagikan link untuk menambah tabungan"}
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
\u{1F4A1} *Cara Menggunakan Kuota:*
Ketik perintah pencarian langsung:
\u2022 \`search: <target>\`
\u2022 \`/search <target>\`
\u2022 \`cari: <target>\`

Contoh: \`search: jokowi\` atau \`cari: slamet\`
_Kuota HANYA berkurang jika data target ditemukan di dataset!_`;
  const keyboard = [
    [
      { text: "\u{1F381} Ambil Kuota Gratis", callback_data: "cmd_claim_menu" },
      { text: "\u{1F465} Tabungan & Referral", callback_data: "cmd_referral" }
    ],
    [
      { text: "\u{1F48E} Top Up API Key", callback_data: "cmd_pricing" },
      { text: "\u{1F4DE} Hubungi Owner (@flood1233)", callback_data: "cmd_owner" }
    ],
    [
      { text: "\u{1F3E0} Menu Utama", callback_data: "cmd_menu" }
    ]
  ];
  await sendTelegramMessage(targetReplyChatId, statusCard, { inline_keyboard: keyboard });
}
async function sendReferralDashboard(userId, replyChatId, senderName) {
  const numericUserId = Number(userId);
  const targetReplyChatId = Number(replyChatId);
  const user = botConfig.activeUsers.find(
    (u) => u.userId && Number(u.userId) === numericUserId || Number(u.chatId) === numericUserId
  );
  const botUser = currentBotInfo?.username || "axxosintbot";
  const cleanBot = botUser.replace(/^@/, "");
  const referralLink = `https://t.me/${cleanBot}?start=ref_${numericUserId}`;
  const savedBalance = user?.referralVaultBalance || 0;
  const activeQuota = user?.personalQuota || 0;
  const totalWithdrawn = user?.totalReferralQuotaClaimed || 0;
  const myReferrals = (botConfig.referralRecords || []).filter(
    (r) => Number(r.inviterUserId) === numericUserId && r.status === "confirmed"
  );
  const totalFriends = myReferrals.length;
  const refConfig = botConfig.referralConfig || DEFAULT_REFERRAL_CONFIG;
  const rewardAmount = refConfig.quotaPerInvite || 1;
  const dashboardText = `\u{1F465} *DASHBOARD REFERRAL & TABUNGAN KUOTA*
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
\u{1F464} *Pengguna:* ${senderName}
\u{1F194} *User ID Anda:* \`${numericUserId}\`
\u{1F4BC} *Saldo Tabungan Kuota (Tersimpan):* *${savedBalance}x Kuota*
\u{1F48E} *Saldo Kuota Pencarian Aktif:* *${activeQuota}x Kuota*
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
\u{1F4CA} *STATISTIK UNDANGAN ANDA:*
\u2022 *Teman Terkonfirmasi Resmi (/start):* *${totalFriends} orang*
\u2022 *Hadiah per Undangan:* *+${rewardAmount} Kuota per Teman*
\u2022 *Total Kuota yang Sudah Ditarik:* *${totalWithdrawn}x Kuota*
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
\u{1F517} *LINK REFERRAL UNIK ANDA:*
\`${referralLink}\`
_(Sentuh tautan di atas untuk menyalin langsung)_

\u{1F4B0} *TENTANG FITUR MENABUNG KUOTA:*
Setiap teman yang bergabung menggunakan link Anda dan mengirim */start* akan otomatis memberikan +${rewardAmount} kuota ke *Saldo Tabungan* Anda.
Anda bebas menabungkannya atau mencairkannya ke *Saldo Kuota Aktif* kapan saja!

\u{1F449} *PILIH OPSI PENARIKAN KUOTA TABUNGAN:*`;
  const keyboard = [];
  if (savedBalance > 0) {
    keyboard.push([
      { text: `\u{1F4B0} Tarik Semua (${savedBalance}x Kuota)`, callback_data: "ref_withdraw_all" }
    ]);
    const partialRow = [];
    if (savedBalance >= 1) partialRow.push({ text: "1x Kuota", callback_data: "ref_withdraw_1" });
    if (savedBalance >= 2) partialRow.push({ text: "2x Kuota", callback_data: "ref_withdraw_2" });
    if (savedBalance >= 5) partialRow.push({ text: "5x Kuota", callback_data: "ref_withdraw_5" });
    if (partialRow.length > 0) {
      keyboard.push(partialRow);
    }
    keyboard.push([
      { text: "\u{1F522} Tarik Jumlah Kustom (/tarik <jumlah>)", callback_data: "ref_withdraw_custom" }
    ]);
  } else {
    keyboard.push([
      { text: "\u{1F4BC} Saldo Tabungan Kosong (0x)", callback_data: "ref_withdraw_custom" }
    ]);
  }
  keyboard.push([
    { text: "\u{1F517} Bagikan Link Undangan", callback_data: "ref_share_info" },
    { text: `\u{1F465} Daftar Teman (${totalFriends})`, callback_data: "ref_my_friends" }
  ]);
  keyboard.push([
    { text: "\u{1F48E} Cek Kuota & Profil", callback_data: "cmd_my_quota" },
    { text: "\u{1F3E0} Menu Utama", callback_data: "cmd_menu" }
  ]);
  await sendTelegramMessage(targetReplyChatId, dashboardText, { inline_keyboard: keyboard });
}
async function handleWithdrawReferralQuota(userId, replyChatId, senderName, amountToWithdraw) {
  const numericUserId = Number(userId);
  const targetReplyChatId = Number(replyChatId);
  const lockKey = `withdraw_ref_${numericUserId}`;
  if (activeClaimLocks.has(lockKey)) {
    return;
  }
  activeClaimLocks.add(lockKey);
  try {
    const user = botConfig.activeUsers.find(
      (u) => u.userId && Number(u.userId) === numericUserId || Number(u.chatId) === numericUserId
    );
    if (!user) {
      await sendTelegramMessage(targetReplyChatId, "\u26A0\uFE0F Akun Anda belum terdaftar. Silakan kirim /start.");
      return;
    }
    const currentSavings = user.referralVaultBalance || 0;
    if (currentSavings <= 0) {
      await sendTelegramMessage(
        targetReplyChatId,
        `\u26A0\uFE0F *SALDO TABUNGAN KUOTA KOSONG (0x)*

Anda belum memiliki saldo tabungan dari hasil undang teman.

\u{1F517} Bagikan link referral Anda untuk mulai mengumpulkan kuota tabungan!`,
        {
          inline_keyboard: [
            [{ text: "\u{1F465} Buka Menu Referral & Link", callback_data: "cmd_referral" }],
            [{ text: "\u{1F381} Ambil Kuota Harian Gratis", callback_data: "cmd_claim_menu" }],
            [{ text: "\u{1F3E0} Menu Utama", callback_data: "cmd_menu" }]
          ]
        }
      );
      return;
    }
    let withdrawAmount = 0;
    if (amountToWithdraw === "all" || !amountToWithdraw) {
      withdrawAmount = currentSavings;
    } else {
      withdrawAmount = Math.floor(Number(amountToWithdraw));
    }
    if (withdrawAmount <= 0) {
      await sendTelegramMessage(
        targetReplyChatId,
        `\u274C Jumlah penarikan harus minimal 1 kuota.

Contoh penggunaan:
\u2022 \`/tarik 1\`
\u2022 \`/tarik 5\`
\u2022 \`/tarik semua\``
      );
      return;
    }
    if (withdrawAmount > currentSavings) {
      await sendTelegramMessage(
        targetReplyChatId,
        `\u26A0\uFE0F *SALDO TABUNGAN TIDAK CUKUP*

Anda ingin menarik *${withdrawAmount}x kuota*, tetapi saldo tabungan Anda saat ini hanya *${currentSavings}x kuota*.

Ketik \`/tarik semua\` atau \`/tarik ${currentSavings}\` untuk menarik seluruh saldo Anda.`
      );
      return;
    }
    user.referralVaultBalance = currentSavings - withdrawAmount;
    user.personalQuota = (user.personalQuota || 0) + withdrawAmount;
    user.totalReferralQuotaClaimed = (user.totalReferralQuotaClaimed || 0) + withdrawAmount;
    syncUserApiKey(user);
    const wibTime = getFormattedWIB();
    const txId = `wd_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
    const txLog = {
      id: txId,
      userId: numericUserId,
      userName: senderName,
      amount: withdrawAmount,
      previousBalance: currentSavings,
      newBalance: user.referralVaultBalance,
      newPersonalQuota: user.personalQuota,
      timestamp: (/* @__PURE__ */ new Date()).toISOString(),
      formattedWib: wibTime.fullStr
    };
    if (!Array.isArray(botConfig.referralWithdrawLogs)) {
      botConfig.referralWithdrawLogs = [];
    }
    botConfig.referralWithdrawLogs.unshift(txLog);
    if (botConfig.referralWithdrawLogs.length > 200) {
      botConfig.referralWithdrawLogs.pop();
    }
    saveReferralData();
    saveBotConfig();
    addLog(
      "system",
      `Pengguna ${numericUserId} (${senderName}) mencairkan ${withdrawAmount}x kuota tabungan referral. Sisa tabungan: ${user.referralVaultBalance}x, Kuota aktif: ${user.personalQuota}x`
    );
    const successCard = `\u{1F389} *PENARIKAN TABUNGAN KUOTA BERHASIL!*
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
\u{1F464} *Pengguna:* ${senderName}
\u{1F194} *User ID:* \`${numericUserId}\`
\u{1F552} *Waktu Transaksi:* ${wibTime.fullStr}
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
\u{1F4B0} *Jumlah Kuota Ditarik:* *+${withdrawAmount}x Kuota*
\u{1F4BC} *Sisa Saldo di Tabungan:* *${user.referralVaultBalance}x Kuota*
\u{1F48E} *Saldo Kuota Pencarian Aktif Baru:* *${user.personalQuota}x Pencarian*
\u{1F511} *API Key Pribadi:* \`${user.personalApiKey}\`
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
\u26A1 *KUOTA SIAP DIGUNAKAN!*
Anda dapat langsung mencari data intelijen sekarang:
\`search: <target>\` atau \`/search <target>\`

_Contoh:_ \`search: jokowi\` atau \`cari: slamet\``;
    await sendTelegramMessage(targetReplyChatId, successCard, {
      inline_keyboard: [
        [{ text: "\u{1F50D} Mulai Cari OSINT", callback_data: "cmd_osint" }],
        [{ text: "\u{1F4BC} Buka Dashboard Tabungan", callback_data: "cmd_referral" }],
        [{ text: "\u{1F3E0} Menu Utama", callback_data: "cmd_menu" }]
      ]
    });
  } finally {
    activeClaimLocks.delete(lockKey);
  }
}
async function sendReferralFriendsList(userId, replyChatId, senderName) {
  const numericUserId = Number(userId);
  const myFriends = (botConfig.referralRecords || []).filter(
    (r) => Number(r.inviterUserId) === numericUserId && r.status === "confirmed"
  );
  if (myFriends.length === 0) {
    await sendTelegramMessage(
      replyChatId,
      `\u{1F465} *DAFTAR TEMAN DIUNDANG (0 ORANG)*

Anda belum memiliki teman yang terdaftar melalui link referral Anda.

\u{1F517} Bagikan link Anda sekarang untuk mendapatkan kuota gratis!`,
      {
        inline_keyboard: [
          [{ text: "\u{1F517} Ambil Link Referral Saya", callback_data: "ref_share_info" }],
          [{ text: "\u{1F4BC} Buka Tabungan Kuota", callback_data: "cmd_referral" }]
        ]
      }
    );
    return;
  }
  const listStr = myFriends.slice(0, 20).map((f, i) => {
    const d = new Date(f.referredAt).toLocaleDateString("id-ID");
    const uTag = f.referredUsername ? `@${f.referredUsername}` : `ID ${f.referredUserId}`;
    return `${i + 1}. *${f.referredName}* (${uTag})
   \u2022 Status: \u2705 Terdaftar Resmi | \u{1F4C5} ${d} | +${f.rewardQuota} Kuota`;
  }).join("\n\n");
  const friendsCard = `\u{1F465} *DAFTAR TEMAN RESMI TERDAFTAR (${myFriends.length} ORANG)*
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
${listStr}
${myFriends.length > 20 ? `
_...dan ${myFriends.length - 20} teman lainnya._` : ""}
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
\u{1F4A1} _Semua reward kuota otomatis masuk ke Saldo Tabungan Anda._`;
  await sendTelegramMessage(replyChatId, friendsCard, {
    inline_keyboard: [
      [{ text: "\u{1F4BC} Buka Tabungan Kuota", callback_data: "cmd_referral" }],
      [{ text: "\u{1F3E0} Menu Utama", callback_data: "cmd_menu" }]
    ]
  });
}
async function sendReferralShareCard(userId, replyChatId, senderName) {
  const botUser = currentBotInfo?.username || "axxosintbot";
  const cleanBot = botUser.replace(/^@/, "");
  const refLink = `https://t.me/${cleanBot}?start=ref_${userId}`;
  const shareCard = `\u{1F517} *BAGIKAN LINK REFERRAL ANDA*
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
Halo *${senderName}*! Salin pesan undangan di bawah ini dan bagikan ke teman, grup, atau channel Telegram Anda:

\`\`\`
Halo! Gunakan bot intelijen OSINT & profiling otomatis axxosintbot di Telegram. 
Dapatkan kuota pencarian data gratis dengan mendaftar melalui tautan ini:
${refLink}
\`\`\`

\u{1F381} *Hadiah Untuk Anda:*
Setiap teman yang mengklik link dan mengirim */start* akan memberikan Anda *+1 Kuota Tabungan* yang bisa dicairkan kapan saja!`;
  await sendTelegramMessage(replyChatId, shareCard, {
    inline_keyboard: [
      [{ text: "\u{1F4BC} Buka Tabungan Kuota", callback_data: "cmd_referral" }],
      [{ text: "\u{1F3E0} Menu Utama", callback_data: "cmd_menu" }]
    ]
  });
}
var MODERATION_GAMBLING_KEYWORDS = [
  "slot",
  "sl0t",
  "judol",
  "judi online",
  "judi bola",
  "gacor",
  "scatter",
  "maxwin",
  "pragmatic",
  "zeus slot",
  "kakek zeus",
  "olympus",
  "sweet bonanza",
  "mahjong ways",
  "bandar togel",
  "togel online",
  "toto gelap",
  "togel sgp",
  "togel hk",
  "toto macau",
  "casino online",
  "live casino",
  "sbobet",
  "agen judi",
  "daftar slot",
  "link slot",
  "link gacor",
  "situs slot",
  "situs judi",
  "depo pulsa",
  "depo 10k",
  "depo 25k",
  "depo 50k",
  "wd kilat",
  "freebet",
  "bocoran slot",
  "pola gacor",
  "jackpot slot",
  "slot88",
  "slot777",
  "rtp slot",
  "rtp live",
  "rolet online",
  "baccarat online",
  "domino qiu",
  "judi slot",
  "agen slot",
  "situs gacor",
  "menang slot",
  "gates of olympus",
  "starlight princess",
  "spxslot",
  "mposlot",
  "hoki slot",
  "sensational slot",
  "pola slot",
  "cheat slot",
  "scatter hitam",
  "chip domino",
  "chip higgs",
  "anti rungkat",
  "anti rungkad",
  "garansi kekalahan",
  "bonus new member",
  "gacor88",
  "zeus88",
  "mahjong88",
  "slot dana",
  "pola petir",
  "depo receh",
  "link alternatif slot"
];
var MODERATION_ADULT_KEYWORDS = [
  "bokep",
  "b0kep",
  "porn",
  "porno",
  "pornografi",
  "18+",
  "vcs",
  "open bo",
  "bo cod",
  "av sub indo",
  "video viral bokep",
  "desah",
  "sange",
  "sangean",
  "bugil",
  "toket",
  "croot",
  "crot",
  "prostitusi",
  "becek",
  "mesum",
  "seks",
  "sex gratis",
  "masturbasi",
  "ngentot",
  "memek",
  "kontol",
  "jav sub",
  "onlyfans bocor",
  "video mesum",
  "doodstream",
  "terabox bokep",
  "vcs murah",
  "pepek",
  "ngocok",
  "lonte",
  "perek",
  "tetek",
  "colmek",
  "colik",
  "hentai",
  "bokep viral",
  "lendir",
  "pap tt",
  "pap bugil",
  "pap toket",
  "pap memek",
  "pap nude",
  "bacol",
  "bahan coli",
  "cewek sange",
  "michat bo",
  "bo include",
  "cs mesum",
  "videy",
  "lulustream",
  "gofile bokep",
  "dildo",
  "kondom",
  "blowjob",
  "ngocok kontol",
  "hisap toket",
  "remas toket",
  "sex chat",
  "pedofil",
  "child porn",
  "lolicon",
  "shotacon",
  "incest",
  "ngaceng",
  "cairan mani",
  "sperma",
  "psk",
  "mucikari",
  "germo",
  "tante girang",
  "pelacur",
  "sundal",
  "jablay",
  "kimcil",
  "cabe cabean",
  "skandal selebgram",
  "kebaya merah",
  "chindo viral",
  "video syur",
  "doodla",
  "doodli",
  "terabox"
];
var MODERATION_DRUGS_KEYWORDS = [
  "narkoba",
  "sabu",
  "sabu-sabu",
  "ekstasi",
  "inex",
  "inek",
  "ganja",
  "tembakau gorila",
  "tembakau sintetis",
  "sinte",
  "pil koplo",
  "tramadol",
  "trihex",
  "alprazolam",
  "dumolid",
  "kokain",
  "heroin",
  "psikotropika",
  "jual sabu",
  "beli ganja",
  "bong sabu",
  "shabu",
  "cimahi sinte",
  "obat keras daftar g",
  "narkotika",
  "pil anjing",
  "methamphetamine",
  "amfetamin",
  "hexymer",
  "riklona",
  "calmlet",
  "zypraz",
  "putaw",
  "bong kaca",
  "pahe sabu"
];
var MODERATION_FRAUD_KEYWORDS = [
  "pinjol ilegal",
  "pengganda uang",
  "pesugihan uang gaib",
  "dana kaget palsu",
  "jasa hack saldo dana",
  "apk pembobol rekening",
  "saldo dana gratis tipu",
  "jual beli rekening",
  "rekening penampung",
  "jual akun e-wallet bodong",
  "arisan bodong",
  "investasi bodong",
  "kloning atm",
  "jasa gestun ilegal",
  "joki pinjol",
  "surat tilang apk",
  "undangan pernikahan apk",
  "jual uang palsu",
  "upal"
];
var MODERATION_WEAPONS_KEYWORDS = [
  "jual senpi",
  "senjata api rakitan",
  "jual celurit begal",
  "bom ikan",
  "bahan peledak rakitan",
  "jual pistol rakitan",
  "senjata tajam tawuran",
  "celurit corbek"
];
function checkMessageModeration(rawText) {
  const cfg = botConfig.moderationConfig || DEFAULT_MODERATION_CONFIG;
  if (!cfg.enabled) {
    return { isBanned: false };
  }
  const text = (rawText || "").trim();
  if (!text) return { isBanned: false };
  const lower = text.toLowerCase();
  const normalized = lower.replace(/[0o]/g, "o").replace(/[1l|!]/g, "i").replace(/3/g, "e").replace(/4/g, "a").replace(/5/g, "s").replace(/\$/g, "s").replace(/@/g, "a");
  const collapsed = normalized.replace(/[\s\-_.,/\\*#+@!~|]+/g, "");
  if (Array.isArray(cfg.whitelistKeywords) && cfg.whitelistKeywords.length > 0) {
    for (const wl of cfg.whitelistKeywords) {
      const wClean = wl.trim().toLowerCase();
      if (wClean && (lower.includes(wClean) || normalized.includes(wClean) || collapsed.includes(wClean.replace(/\s+/g, "")))) {
        return { isBanned: false };
      }
    }
  }
  if (cfg.allowCyberAndOsint !== false) {
    const cyberTerms = cfg.cyberWhitelistKeywords || DEFAULT_MODERATION_CONFIG.cyberWhitelistKeywords;
    const hasCyberContext = cyberTerms.some((ct) => {
      const term = ct.toLowerCase().trim();
      return term && (lower.includes(term) || normalized.includes(term));
    });
    if (hasCyberContext) {
      const isBlatantCommercialSpam = /(link\s*slot|daftar\s*slot|depo\s*pulsa|open\s*bo|vcs\s*real|jual\s*sabu)/i.test(lower) || /(linkslot|daftarslot|depopulsa|openbo|vcsreal|jualsabu)/i.test(collapsed);
      if (!isBlatantCommercialSpam) {
        return { isBanned: false };
      }
    }
  }
  if (cfg.blockGamblingSlot !== false) {
    for (const kw of MODERATION_GAMBLING_KEYWORDS) {
      const kwCollapsed = kw.replace(/[\s\-_.]+/g, "");
      const regex = new RegExp(`(^|\\s|[^a-zA-Z0-9])${kw.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}($|\\s|[^a-zA-Z0-9])`, "i");
      if (regex.test(lower) || lower.includes(kw) || normalized.includes(kw) || kwCollapsed.length >= 4 && collapsed.includes(kwCollapsed)) {
        return {
          isBanned: true,
          category: "\u{1F3B0} Judi Online / Slot / Kasino / Togel",
          matchedKeyword: kw,
          explanation: "Pesan mengandung promosi, tautan, atau istilah perjudian online / slot yang dilarang undang-undang serta aturan ruang obrolan."
        };
      }
    }
  }
  if (cfg.blockAdult18Plus !== false) {
    for (const kw of MODERATION_ADULT_KEYWORDS) {
      const kwCollapsed = kw.replace(/[\s\-_.]+/g, "");
      const regex = new RegExp(`(^|\\s|[^a-zA-Z0-9])${kw.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}($|\\s|[^a-zA-Z0-9])`, "i");
      if (regex.test(lower) || lower.includes(kw) || normalized.includes(kw) || kwCollapsed.length >= 3 && collapsed.includes(kwCollapsed)) {
        return {
          isBanned: true,
          category: "\u{1F51E} Konten Dewasa / 18+ / Pornografi / VCS",
          matchedKeyword: kw,
          explanation: "Pesan mengandung materi pornografi, ketidaksenonohan, VCS, prostitusi, atau materi 18+ terlarang."
        };
      }
    }
  }
  if (cfg.blockDrugs !== false) {
    for (const kw of MODERATION_DRUGS_KEYWORDS) {
      const kwCollapsed = kw.replace(/[\s\-_.]+/g, "");
      const regex = new RegExp(`(^|\\s|[^a-zA-Z0-9])${kw.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}($|\\s|[^a-zA-Z0-9])`, "i");
      if (regex.test(lower) || lower.includes(kw) || normalized.includes(kw) || kwCollapsed.length >= 4 && collapsed.includes(kwCollapsed)) {
        return {
          isBanned: true,
          category: "\u{1F48A} Narkoba & Zat / Obat Terlarang",
          matchedKeyword: kw,
          explanation: "Pesan mengandung indikasi penawaran, jual-beli, atau promosi narkotika dan obat-obatan terlarang."
        };
      }
    }
  }
  if (cfg.blockFraudScam !== false) {
    for (const kw of MODERATION_FRAUD_KEYWORDS) {
      const kwCollapsed = kw.replace(/[\s\-_.]+/g, "");
      if (lower.includes(kw) || normalized.includes(kw) || kwCollapsed.length >= 6 && collapsed.includes(kwCollapsed)) {
        return {
          isBanned: true,
          category: "\u{1F4B3} Penipuan Finansial / Phishing / Scam",
          matchedKeyword: kw,
          explanation: "Pesan mengandung modus penipuan keuangan, pinjol bodong ilegal, atau tautan phishing perbankan."
        };
      }
    }
  }
  if (cfg.blockWeaponsExplosives !== false) {
    for (const kw of MODERATION_WEAPONS_KEYWORDS) {
      const kwCollapsed = kw.replace(/[\s\-_.]+/g, "");
      if (lower.includes(kw) || normalized.includes(kw) || kwCollapsed.length >= 6 && collapsed.includes(kwCollapsed)) {
        return {
          isBanned: true,
          category: "\u{1F4A3} Senjata Ilegal & Bahan Berbahaya",
          matchedKeyword: kw,
          explanation: "Pesan memuat transaksi senjata api rakitan atau bahan peledak ilegal yang mengancam keselamatan."
        };
      }
    }
  }
  if (Array.isArray(cfg.customBannedKeywords)) {
    for (const kw of cfg.customBannedKeywords) {
      const cleanKw = kw.trim().toLowerCase();
      const kwCollapsed = cleanKw.replace(/[\s\-_.]+/g, "");
      if (cleanKw && (lower.includes(cleanKw) || normalized.includes(cleanKw) || kwCollapsed.length >= 3 && collapsed.includes(kwCollapsed))) {
        return {
          isBanned: true,
          category: "\u{1F6AB} Kata Kunci Terlarang (Kustom Pengelola)",
          matchedKeyword: kw,
          explanation: "Pesan memuat kata kunci terlarang khusus yang telah diatur oleh pengelola bot."
        };
      }
    }
  }
  return { isBanned: false };
}
async function handleBannedMessage(message, checkResult) {
  const chat = message.chat;
  const chatId = chat.id;
  const from = message.from || chat;
  const messageId = message.message_id;
  const senderName = [from.first_name, from.last_name].filter(Boolean).join(" ") || from.username || "Pengguna";
  const usernameTag = from.username ? `@${from.username}` : "-";
  const rawText = (message.text || message.caption || "").trim();
  const isGroup = chat.type === "group" || chat.type === "supergroup";
  const wibTime = getFormattedWIB().fullStr;
  let deleteSuccess = false;
  let deleteError;
  try {
    const delRes = await callTelegramApi(
      botConfig.token,
      "deleteMessage",
      { chat_id: chatId, message_id: messageId },
      8e3
    );
    if (delRes && delRes.ok) {
      deleteSuccess = true;
    } else {
      deleteError = delRes?.description || "Gagal menghapus pesan (Pastikan bot adalah Admin dengan izin Delete Messages).";
    }
  } catch (err) {
    deleteError = err.message;
  }
  addLog(
    "system",
    `[Auto-Moderasi] Pesan dari ${senderName} (${usernameTag}) ${deleteSuccess ? "berhasil dihapus" : "gagal dihapus"}. Kategori: ${checkResult.category} | Kata: "${checkResult.matchedKeyword}"`,
    chatId
  );
  const safeQuotedMessage = rawText.length > 500 ? rawText.substring(0, 500) + "... (dipersingkat)" : rawText;
  const warningMessage = `\u{1F6AB} *PESAN OTOMATIS DIHAPUS OLEH SISTEM KEAMANAN*
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
\u{1F464} *Pengirim:* ${senderName} (${usernameTag})
\u{1F194} *User ID:* \`${from.id}\`
\u{1F552} *Waktu Tindakan:* ${wibTime}
\u{1F3DB}\uFE0F *Ruang Obrolan:* ${chat.title ? `*${chat.title}*` : "Chat Pribadi"}

\u26A0\uFE0F *DETAIL KESALAHAN & PELANGGARAN:*
\u2022 *Kategori Terlarang:* ${checkResult.category}
\u2022 *Kata Kunci Terdeteksi:* \`${checkResult.matchedKeyword}\`
\u2022 *Keterangan Aturan:* ${checkResult.explanation}

\u{1F4DD} *SALINAN PESAN ASLI PENGIRIM:*
\`\`\`
${safeQuotedMessage}
\`\`\`

\u{1F6E1}\uFE0F *KEBIJAKAN KETERTIBAN SISTEM:*
Bot *axxosintbot* menerapkan penyaringan otomatis tanpa kompromi terhadap:
1. \u{1F3B0} *Judi Online, Slot Gacor, Kasino & Togel*
2. \u{1F51E} *Konten Dewasa, Bokep, VCS & Prostitusi*
3. \u{1F48A} *Narkoba, Psikotropika & Zat/Obat Terlarang*
4. \u{1F4B3} *Penipuan Finansial, Phishing & Scam Rekening*

\u2139\uFE0F *PENGECUALIAN RESMI (CYBER & OSINT):*
Seluruh topik edukasi, investigasi, analisis, dan diskusi seputar *Cyber Security, OSINT, Exploit, Penetration Testing, Kebocoran Data (Data Leak) & Forensik* tetap *100% BEBAS & DIPERBOLEHKAN*.
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
\u{1F4A1} _Pesan pelanggaran telah dimusnahkan demi kenyamanan dan keamanan bersama._`;
  const cfg = botConfig.moderationConfig || DEFAULT_MODERATION_CONFIG;
  if (cfg.sendExplanationMessage !== false) {
    const sentMsg = await sendTelegramMessage(chatId, warningMessage);
    if (sentMsg && sentMsg.message_id && cfg.autoDeleteExplanationSeconds && cfg.autoDeleteExplanationSeconds > 0) {
      setTimeout(async () => {
        try {
          await callTelegramApi(
            botConfig.token,
            "deleteMessage",
            { chat_id: chatId, message_id: sentMsg.message_id },
            5e3
          );
        } catch {
        }
      }, cfg.autoDeleteExplanationSeconds * 1e3);
    }
  }
  if (!botConfig.moderationConfig) {
    botConfig.moderationConfig = { ...DEFAULT_MODERATION_CONFIG };
  }
  if (!Array.isArray(botConfig.moderationConfig.recentIncidents)) {
    botConfig.moderationConfig.recentIncidents = [];
  }
  const incident = {
    id: `mod_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
    chatId: Number(chatId),
    chatTitle: isGroup ? chat.title : void 0,
    userId: Number(from.id),
    userName: senderName,
    usernameTag,
    category: checkResult.category || "Konten Terlarang",
    matchedKeyword: checkResult.matchedKeyword || "-",
    originalMessage: rawText,
    timestamp: (/* @__PURE__ */ new Date()).toISOString(),
    actionTaken: deleteSuccess ? "deleted_and_warned" : "delete_failed",
    errorMessage: deleteError
  };
  botConfig.moderationConfig.recentIncidents.unshift(incident);
  if (botConfig.moderationConfig.recentIncidents.length > 60) {
    botConfig.moderationConfig.recentIncidents.pop();
  }
  saveBotConfig();
  recordMessageTraffic({
    direction: "incoming",
    chatId,
    chatType: isGroup ? "group" : "private",
    chatTitle: isGroup ? chat.title : void 0,
    userId: Number(from.id),
    userName: senderName,
    usernameTag,
    text: rawText,
    status: "filtered",
    filterReason: `${checkResult.category} (${checkResult.matchedKeyword})`
  });
}
async function handleIncomingMessage(message, sourceBot) {
  if (!message || !message.chat) return;
  const chat = message.chat;
  const from = message.from || chat;
  if (from.is_bot) return;
  if (chat.type === "channel") return;
  const chatId = chat.id;
  const isGroup = chat.type === "group" || chat.type === "supergroup";
  const senderName = [from.first_name, from.last_name].filter(Boolean).join(" ") || from.username || "Pengguna";
  const usernameTag = from.username ? `@${from.username}` : "-";
  const msgDedupKey = `${chatId}_${message.message_id}`;
  if (processedMessageIds.has(msgDedupKey)) {
    return;
  }
  processedMessageIds.add(msgDedupKey);
  if (processedMessageIds.size > 3e3) {
    const firstKey = processedMessageIds.values().next().value;
    if (firstKey) processedMessageIds.delete(firstKey);
  }
  if (isGroup) {
    updateKnownGroup(chat);
    if (botConfig.groupConfig && !botConfig.groupConfig.allowGroups) {
      return;
    }
    if (botConfig.groupConfig?.blockedGroupIds?.includes(Number(chatId))) {
      return;
    }
    if (botConfig.groupConfig?.allowedGroupIds && botConfig.groupConfig.allowedGroupIds.length > 0 && !botConfig.groupConfig.allowedGroupIds.includes(Number(chatId))) {
      return;
    }
  }
  const rawText = (message.text || message.caption || "").trim();
  botConfig.stats.messagesReceived += 1;
  const currentUser = registerOrUpdateUser(from, chat);
  recordMessageTraffic({
    botId: sourceBot?.id || "primary",
    botUsername: sourceBot?.botInfo?.username || currentBotInfo?.username || "axxosintbot",
    botName: sourceBot?.botInfo?.first_name || currentBotInfo?.first_name || "Bot Utama",
    isPrimaryBot: !sourceBot,
    direction: "incoming",
    chatId,
    chatType: isGroup ? "group" : "private",
    chatTitle: isGroup ? chat.title : void 0,
    userId: Number(from.id),
    userName: senderName,
    usernameTag,
    text: rawText || (message.photo ? "[Foto]" : message.document ? "[Dokumen]" : "[Media]"),
    status: "delivered"
  });
  if (rawText) {
    const moderationResult = checkMessageModeration(rawText);
    if (moderationResult.isBanned) {
      const shouldDelete = isGroup && botConfig.moderationConfig?.deleteInGroups !== false || !isGroup && botConfig.moderationConfig?.deleteInPrivate !== false;
      if (shouldDelete) {
        await handleBannedMessage(message, moderationResult);
        return;
      }
    }
  }
  if (!rawText) {
    if (message.photo || message.document || message.sticker) {
      if (!isGroup) {
        await sendTelegramMessage(
          chatId,
          `\u{1F4E5} Berkas media diterima dari *${senderName}*.
Ketik /id untuk cek Chat ID atau /menu untuk membuka opsi.`
        );
      }
    }
    return;
  }
  const botUsername = (sourceBot?.botInfo?.username || currentBotInfo?.username || "").toLowerCase();
  let text = rawText;
  let isExplicitMention = false;
  if (text.startsWith("/")) {
    const cmdMatch = text.match(/^\/([a-zA-Z0-9_]+)@([a-zA-Z0-9_]+)/i);
    if (cmdMatch) {
      const targetBot = cmdMatch[2].toLowerCase();
      if (botUsername && targetBot !== botUsername) {
        return;
      }
      text = "/" + cmdMatch[1] + text.substring(cmdMatch[0].length);
    }
  }
  if (botUsername && text.toLowerCase().includes(`@${botUsername}`)) {
    isExplicitMention = true;
    text = text.replace(new RegExp(`@${botUsername}\\b`, "gi"), "").trim();
  }
  const lowerText = text.toLowerCase();
  const isCommandLike = text.startsWith("/") || lowerText.startsWith("search:") || lowerText.startsWith("search ") || lowerText.startsWith("osint:") || lowerText.startsWith("cari:") || lowerText.startsWith("cari ") || lowerText.startsWith("cek:") || lowerText.startsWith("cek ") || lowerText.startsWith("track:") || lowerText.startsWith("track ") || lowerText.startsWith("api ") || lowerText.startsWith("ax0895") || isExplicitMention;
  const isAntiFloodOn = botConfig.groupConfig?.enableAntiFlood !== false;
  if (isAntiFloodOn) {
    const floodKey = `user_${from.id}`;
    const nowMs = Date.now();
    const cooldownMs = Math.max(1, botConfig.groupConfig?.antiFloodCooldownSeconds || 3) * 1e3;
    const lastAction = lastUserActionTimestamp.get(floodKey) || 0;
    if (isCommandLike) {
      const burstCheck = checkAdaptiveSecurityBurst(from.id, chatId, senderName);
      if (burstCheck.isBlocked && burstCheck.message) {
        await sendTelegramMessage(chatId, burstCheck.message);
        return;
      }
    }
    if (nowMs - lastAction < cooldownMs) {
      const lastWarn = floodWarningSentTimestamps.get(floodKey) || 0;
      if (nowMs - lastWarn > 6e3) {
        floodWarningSentTimestamps.set(floodKey, nowMs);
        await sendTelegramMessage(
          chatId,
          `\u23F3 *Anti-Flood & Anti-Spam Protection*
Mohon tunggu *${botConfig.groupConfig?.antiFloodCooldownSeconds || 3} detik* sebelum mengirim pesan atau perintah berikutnya.`
        );
      }
      return;
    }
    lastUserActionTimestamp.set(floodKey, nowMs);
  }
  if (isGroup && botConfig.groupConfig?.groupAdminOnly && isCommandLike) {
    const isAdmin = await isTelegramGroupAdmin(botConfig.token, chatId, from.id);
    if (!isAdmin) {
      await sendTelegramMessage(
        chatId,
        `\u26A0\uFE0F *Izin Ditolak:* Perintah bot di grup ini hanya diizinkan untuk Admin / Pemilik Grup.`
      );
      return;
    }
  }
  addLog("incoming", `"${text}"`, chatId, `${senderName} (${usernameTag})`);
  const wibTime = getFormattedWIB();
  const pricing = getPricingData(currentUser.languageCode);
  let referralInviterId = null;
  const startMatch = text.match(/^\/start(?:@\w+)?(?:\s+(.*))?$/i);
  if (startMatch && startMatch[1]) {
    const rawPayload = startMatch[1].trim();
    const idMatch = rawPayload.match(/^(?:ref_)?([0-9]{5,15})/i);
    if (idMatch) {
      referralInviterId = Number(idMatch[1]);
    }
  }
  let referredInviterName = null;
  if (referralInviterId && referralInviterId !== Number(from.id) && !currentUser.referredByUserId && botConfig.referralConfig?.enabled !== false) {
    const alreadyReferred = (botConfig.referralRecords || []).some(
      (r) => Number(r.referredUserId) === Number(from.id)
    );
    if (!alreadyReferred) {
      const inviterUser = botConfig.activeUsers.find(
        (u) => Number(u.userId || u.chatId) === referralInviterId
      );
      const inviterName = inviterUser ? [inviterUser.firstName, inviterUser.lastName].filter(Boolean).join(" ") || inviterUser.username || `User ${referralInviterId}` : `User ${referralInviterId}`;
      referredInviterName = inviterName;
      const rewardQuota = botConfig.referralConfig?.quotaPerInvite || 1;
      currentUser.referredByUserId = referralInviterId;
      currentUser.referredAt = (/* @__PURE__ */ new Date()).toISOString();
      currentUser.isVerified = true;
      currentUser.verifiedAt = (/* @__PURE__ */ new Date()).toISOString();
      const refRecord = {
        id: `ref_${Date.now()}_${from.id}`,
        inviterUserId: referralInviterId,
        inviterUsername: inviterUser?.username,
        inviterName,
        referredUserId: Number(from.id),
        referredUsername: from.username,
        referredName: senderName,
        referredAt: (/* @__PURE__ */ new Date()).toISOString(),
        confirmedAt: (/* @__PURE__ */ new Date()).toISOString(),
        status: "confirmed",
        rewardQuota
      };
      if (!Array.isArray(botConfig.referralRecords)) {
        botConfig.referralRecords = [];
      }
      botConfig.referralRecords.unshift(refRecord);
      if (inviterUser) {
        inviterUser.referralVaultBalance = (inviterUser.referralVaultBalance || 0) + rewardQuota;
        inviterUser.totalReferralsCount = (inviterUser.totalReferralsCount || 0) + 1;
      }
      saveReferralData();
      saveBotConfig();
      addLog(
        "system",
        `\u{1F389} Referral Resmi Terdaftar: ${senderName} (${from.id}) terdaftar via ${inviterName} (${referralInviterId}). +${rewardQuota} Kuota ditambahkan ke Tabungan inviter.`,
        chatId
      );
      if (botConfig.referralConfig?.notifyInviterOnRegister !== false && inviterUser) {
        const inviterChatId = inviterUser.chatId || inviterUser.userId;
        const inviterNotify = `\u{1F389} *SELAMAT! TEMAN ANDA RESMI TERDAFTAR!*
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
\u{1F464} *Teman Baru:* ${senderName} (${usernameTag})
\u{1F194} *User ID Teman:* \`${from.id}\`
\u{1F552} *Waktu Pendaftaran:* ${wibTime.fullStr}
\u{1F381} *Hadiah Referral:* *+${rewardQuota} Kuota OSINT*

\u{1F4BC} *Saldo Tabungan Kuota Anda Sekarang:* *${inviterUser.referralVaultBalance}x Kuota*
*(Tersimpan di Tabungan & Siap Ditarik Kapan Saja)*

\u{1F4A1} _Ketik /tabungan atau /tarik untuk mencairkan saldo tabungan ke kuota pencarian aktif Anda!_`;
        sendTelegramMessage(inviterChatId, inviterNotify, {
          inline_keyboard: [
            [{ text: "\u{1F4BC} Buka Tabungan Kuota", callback_data: "cmd_referral" }],
            [{ text: "\u{1F4B0} Tarik Semua Kuota", callback_data: "ref_withdraw_all" }]
          ]
        }).catch(() => {
        });
      }
    }
  }
  const configuredOwnerPasskey = (botConfig.ownerWebsitePasskey || "ax0895").trim().toLowerCase();
  const isOwnerSecretTrigger = lowerText === "ax0895" || lowerText.startsWith("ax0895 ") || lowerText === "/ax0895" || lowerText.startsWith("/ax0895 ") || configuredOwnerPasskey && (lowerText === configuredOwnerPasskey || lowerText.startsWith(`${configuredOwnerPasskey} `) || lowerText === `/${configuredOwnerPasskey}` || lowerText.startsWith(`/${configuredOwnerPasskey} `));
  const isDirectOwnerSlashCmd = lowerText.startsWith("/addbot") || lowerText.startsWith("/delbot") || lowerText.startsWith("/setexpiry") || lowerText === "/listbot" || lowerText.startsWith("/listbot ") || lowerText === "/multibot" || lowerText.startsWith("/multibot ");
  if (isOwnerSecretTrigger || isDirectOwnerSlashCmd) {
    botConfig.stats.commandsExecuted += 1;
    saveBotConfig();
    const parts = text.split(/\s+/);
    let subCmd = "";
    let argOffset = 2;
    if (isDirectOwnerSlashCmd) {
      subCmd = parts[0].replace(/^\//, "").toLowerCase();
      argOffset = 1;
    } else {
      subCmd = (parts[1] || "").toLowerCase();
      argOffset = 2;
    }
    if (subCmd === "on") {
      botConfig.osintConfig.enabled = true;
      botConfig.osintConfig.lastToggledAt = (/* @__PURE__ */ new Date()).toISOString();
      saveBotConfig();
      addLog("system", `Owner mengaktifkan server OSINT via Telegram.`);
      await sendTelegramMessage(chatId, `\u{1F7E2} *SERVER OSINT BERHASIL DIAKTIFKAN (ON)*

Server Ngrok: \`${botConfig.osintConfig.ngrokUrl}\`

Menyiarkan notifikasi status ON ke seluruh pengguna...`);
      if (botConfig.osintConfig.notifyOnStatusChange) {
        broadcastOsintStatusChange(true).catch(console.error);
      }
      return;
    }
    if (subCmd === "off") {
      botConfig.osintConfig.enabled = false;
      botConfig.osintConfig.lastToggledAt = (/* @__PURE__ */ new Date()).toISOString();
      saveBotConfig();
      addLog("system", `Owner menonaktifkan server OSINT via Telegram.`);
      await sendTelegramMessage(chatId, `\u{1F534} *SERVER OSINT BERHASIL DINONAKTIFKAN (OFF)*

Menyiarkan notifikasi status OFF ke seluruh pengguna...`);
      if (botConfig.osintConfig.notifyOnStatusChange) {
        broadcastOsintStatusChange(false).catch(console.error);
      }
      return;
    }
    if (subCmd === "ngrok") {
      const newUrl = parts.slice(argOffset).join(" ").trim();
      if (!newUrl.startsWith("http://") && !newUrl.startsWith("https://")) {
        await sendTelegramMessage(chatId, `\u274C *Format Salah!*

Contoh: \`${configuredOwnerPasskey} ngrok https://dd60-180-247-62-62.ngrok-free.app\``);
        return;
      }
      botConfig.osintConfig.ngrokUrl = newUrl;
      saveBotConfig();
      addLog("system", `Owner memperbarui Ngrok URL via Telegram ke: ${newUrl}`);
      await sendTelegramMessage(chatId, `\u2705 *URL NGROK DIPERBARUI!*

\u{1F310} URL Baru: \`${newUrl}\`
Status OSINT: ${botConfig.osintConfig.enabled ? "\u{1F7E2} ON" : "\u{1F534} OFF"}`);
      return;
    }
    if (subCmd === "addkey") {
      const newKey = parts[argOffset];
      const quotaStr = parts[argOffset + 1];
      const notes = parts.slice(argOffset + 2).join(" ") || "Dibuat via Telegram Owner";
      if (!newKey || !quotaStr) {
        await sendTelegramMessage(chatId, `\u274C *Format Salah!*

Contoh:
\u2022 \`${configuredOwnerPasskey} addkey user1 15 Paket 10k\`
\u2022 \`${configuredOwnerPasskey} addkey user2 unlimited Paket 100k\``);
        return;
      }
      const isUnlimited = quotaStr.toLowerCase() === "unlimited" || quotaStr === "999999";
      const quotaNum = isUnlimited ? 999999 : parseInt(quotaStr, 10) || 5;
      const bonus = isUnlimited ? 0 : quotaNum >= 15 ? 1 : 0;
      const newApiKey = {
        id: `key-${Date.now()}`,
        key: newKey,
        ownerNotes: notes,
        tier: isUnlimited ? "unlimited" : "limited",
        initialQuota: quotaNum,
        remainingQuota: quotaNum,
        bonusQuota: bonus,
        totalUsed: 0,
        createdAt: (/* @__PURE__ */ new Date()).toISOString(),
        enabled: true
      };
      botConfig.osintConfig.apiKeys = botConfig.osintConfig.apiKeys.filter((k) => k.key.toLowerCase() !== newKey.toLowerCase());
      botConfig.osintConfig.apiKeys.unshift(newApiKey);
      saveBotConfig();
      addLog("system", `Owner membuat API Key baru: "${newKey}" (${quotaNum}x + ${bonus} bonus).`);
      await sendTelegramMessage(
        chatId,
        `\u2705 *API KEY BERHASIL DIBUAT!*

\u{1F511} *Key:* \`${newKey}\`
\u{1F4CA} *Tipe:* ${isUnlimited ? "Unlimited" : `${quotaNum}x pakai`}
\u{1F381} *Bonus Ekstra:* ${bonus}x
\u{1F4DD} *Catatan:* ${notes}

_Pengguna dapat mengecek kuota dengan mengetik:_ \`api ${newKey}\``
      );
      return;
    }
    if (subCmd === "delkey") {
      const targetKey = parts[argOffset];
      if (!targetKey) {
        await sendTelegramMessage(chatId, `\u274C Ketik: \`${configuredOwnerPasskey} delkey <key>\``);
        return;
      }
      const beforeCount = botConfig.osintConfig.apiKeys.length;
      botConfig.osintConfig.apiKeys = botConfig.osintConfig.apiKeys.filter((k) => k.key.toLowerCase() !== targetKey.toLowerCase());
      saveBotConfig();
      if (botConfig.osintConfig.apiKeys.length < beforeCount) {
        await sendTelegramMessage(chatId, `\u2705 API Key \`${targetKey}\` berhasil dihapus.`);
      } else {
        await sendTelegramMessage(chatId, `\u26A0\uFE0F API Key \`${targetKey}\` tidak ditemukan.`);
      }
      return;
    }
    if (subCmd === "keys") {
      const keys = botConfig.osintConfig.apiKeys;
      if (keys.length === 0) {
        await sendTelegramMessage(chatId, `\u{1F4ED} Belum ada API Key yang tersimpan.`);
        return;
      }
      const listStr = keys.map((k, i) => {
        const quota = k.tier === "unlimited" ? "Unlimited" : `${k.remainingQuota} sisa (+${k.bonusQuota} bonus)`;
        return `${i + 1}. \`${k.key}\` [${k.enabled ? "Aktif" : "Nonaktif"}]
   \u2022 Kuota: ${quota}
   \u2022 Terpakai: ${k.totalUsed}x
   \u2022 Catatan: ${k.ownerNotes}`;
      }).join("\n\n");
      await sendTelegramMessage(chatId, `\u{1F511} *DAFTAR API KEY AKTIF (${keys.length}):*
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
${listStr}`);
      return;
    }
    if (subCmd === "test") {
      await sendTelegramMessage(chatId, `\u{1F504} Mengetes koneksi ke Ngrok: \`${botConfig.osintConfig.ngrokUrl}\`...`);
      try {
        const testTarget = `${botConfig.osintConfig.ngrokUrl.replace(/\/$/, "")}/api/v1/search?q=ping&apiKey=test`;
        const testRes = await fetch(testTarget, { method: "GET", headers: { "User-Agent": "TelegramBot/1.0" } });
        await sendTelegramMessage(chatId, `\u2705 *RESPON NGROK OK!*

Status HTTP: *${testRes.status} ${testRes.statusText}*
URL: \`${testTarget}\``);
      } catch (err) {
        await sendTelegramMessage(chatId, `\u274C *NGROK OFFLINE / GAGAL!*

Error: \`${err.message}\`
Pastikan tunnel ngrok sedang running.`);
      }
      return;
    }
    if (subCmd === "addbot") {
      const targetToken = parts[argOffset];
      const tailArgs = parts.slice(argOffset + 1);
      if (!targetToken) {
        await sendTelegramMessage(
          chatId,
          `\u274C *Format Penggunaan addbot:*
\`${configuredOwnerPasskey} addbot <TOKEN> [CATATAN] [TANGGAL/DURASI] [WAKTU]\`
atau \`/addbot <TOKEN> [CATATAN] [TANGGAL] [WAKTU]\`

*Contoh:*
\u2022 \`/addbot 78912345:AAHfkj_9823 Sewa_Komunitas 2026-12-31\` (otomatis s/d 23:59 WIB)
\u2022 \`/addbot 78912345:AAHfkj_9823 Sewa_VIP 2026-12-31 18:30\` (atur jam kustom)
\u2022 \`/addbot 78912345:AAHfkj_9823 Sewa_John 30d\` (otomatis 30 hari ke depan)
\u2022 \`/addbot 78912345:AAHfkj_9823 Bot_Utama permanen\` (sewa tanpa batas waktu)`
        );
        return;
      }
      let parsedExpiry = void 0;
      let notes = "Ditambahkan via Telegram Owner";
      if (tailArgs.length > 0) {
        const last1 = tailArgs[tailArgs.length - 1];
        const last2 = tailArgs.length >= 2 ? tailArgs[tailArgs.length - 2] : null;
        if (last2 && /^\d{1,2}[:.]\d{1,2}$/.test(last1) && /^(\d{4}[-/.]\d{1,2}[-/.]\d{1,2}|\d{1,2}[-/.]\d{1,2}[-/.]\d{4})$/.test(last2)) {
          parsedExpiry = parseRentExpiryInput(last2, last1);
          notes = tailArgs.slice(0, -2).join(" ") || notes;
        } else if (/^(\d+)\s*(?:d|hari|m|bulan|y|tahun)$/i.test(last1) || /^(\d{4}[-/.]\d{1,2}[-/.]\d{1,2}|\d{1,2}[-/.]\d{1,2}[-/.]\d{4})/.test(last1) || ["permanen", "permanent", "lifetime", "none", "-"].includes(last1.toLowerCase())) {
          parsedExpiry = parseRentExpiryInput(last1);
          notes = tailArgs.slice(0, -1).join(" ") || notes;
        } else {
          notes = tailArgs.join(" ");
        }
      }
      await sendTelegramMessage(chatId, `\u23F3 *MEMVERIFIKASI TOKEN KE TELEGRAM API...*`);
      const val = await verifyTelegramToken(targetToken);
      if (!val.valid || !val.botInfo) {
        await sendTelegramMessage(chatId, `\u274C *TOKEN TIDAK VALID:* ${val.errorMessage || "Unauthorized"}`);
        return;
      }
      const expiryStatus = getRentExpiryStatus(parsedExpiry);
      const newBot = {
        id: `bot_${val.botInfo.id}`,
        token: targetToken,
        maskedToken: maskToken(targetToken),
        isActive: true,
        botInfo: val.botInfo,
        addedAt: (/* @__PURE__ */ new Date()).toISOString(),
        startedAt: (/* @__PURE__ */ new Date()).toISOString(),
        latencyMs: val.latencyMs,
        notes,
        rentExpiryDate: parsedExpiry,
        stats: { messagesReceived: 0, messagesSent: 0, commandsExecuted: 0 }
      };
      if (!Array.isArray(botConfig.multiBots)) botConfig.multiBots = [];
      botConfig.multiBots = botConfig.multiBots.filter((b) => b.token !== targetToken && b.id !== newBot.id);
      botConfig.multiBots.unshift(newBot);
      saveBotConfig();
      runSingleSecondaryBotWorker(newBot).catch(console.error);
      await sendTelegramMessage(
        chatId,
        `\u2705 *BOT BARU TERHUBUNG KE CLUSTER!*
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
\u{1F916} *Nama Bot:* ${val.botInfo.first_name}
\u{1F3F7} *Username:* @${val.botInfo.username}
\u{1F194} *Bot ID:* \`${val.botInfo.id}\`
\u26A1 *Latensi Ping:* ${val.latencyMs} ms
\u{1F4DD} *Catatan:* ${notes}
\u{1F4C5} *Masa Sewa:* ${parsedExpiry ? `${parsedExpiry} WIB (${expiryStatus.remainingText})` : "\u267E\uFE0F Permanen"}
\u{1F7E2} *Status Mesin:* *ONLINE (Always-ON Polling)*
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
\u{1F4A1} _Bot langsung aktif dan dapat menerima perintah OSINT secara instan._`
      );
      return;
    }
    if (subCmd === "setexpiry") {
      const target = (parts[argOffset] || "").toLowerCase().replace(/^@/, "");
      const rawDate = parts[argOffset + 1];
      const rawTime = parts[argOffset + 2];
      if (!target || !rawDate) {
        await sendTelegramMessage(
          chatId,
          `\u274C *Format Penggunaan setexpiry:*
\`${configuredOwnerPasskey} setexpiry <ID_ATAU_USERNAME> <TANGGAL/DURASI> [WAKTU]\`
atau \`/setexpiry <ID_ATAU_USERNAME> <TANGGAL/DURASI> [WAKTU]\`

*Contoh:*
\u2022 \`/setexpiry @bot_ku 2026-12-31\` (otomatis s/d 23:59 WIB)
\u2022 \`/setexpiry @bot_ku 2026-12-31 15:00\` (atur jam kustom)
\u2022 \`/setexpiry @bot_ku 30d\` (tambah 30 hari ke depan)
\u2022 \`/setexpiry @bot_ku permanen\` (hapus batas sewa)`
        );
        return;
      }
      if (!Array.isArray(botConfig.multiBots)) botConfig.multiBots = [];
      const matched = botConfig.multiBots.find(
        (b) => b.id.toLowerCase() === target || b.botInfo?.username && b.botInfo.username.toLowerCase() === target
      );
      if (!matched) {
        await sendTelegramMessage(chatId, `\u26A0\uFE0F Bot "${target}" tidak ditemukan di cluster.`);
        return;
      }
      const newExpiry = parseRentExpiryInput(rawDate, rawTime);
      matched.rentExpiryDate = newExpiry;
      saveBotConfig();
      const expStatus = getRentExpiryStatus(newExpiry);
      await sendTelegramMessage(
        chatId,
        `\u2705 *MASA SEWA BOT DIPERBARUI!*
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
\u{1F916} *Bot:* ${matched.botInfo?.first_name || matched.id} (@${matched.botInfo?.username || "-"})
\u{1F4C5} *Masa Sewa Baru:* ${newExpiry ? `${newExpiry} WIB` : "\u267E\uFE0F Permanen"}
\u23F3 *Status Sisa:* ${expStatus.remainingText}
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501`
      );
      return;
    }
    if (subCmd === "delbot") {
      const target = (parts[argOffset] || "").toLowerCase().replace(/^@/, "");
      if (!target) {
        await sendTelegramMessage(chatId, `\u274C Ketik: \`${configuredOwnerPasskey} delbot <id_atau_username_bot>\` atau \`/delbot <username>\``);
        return;
      }
      if (!Array.isArray(botConfig.multiBots)) botConfig.multiBots = [];
      const matched = botConfig.multiBots.find(
        (b) => b.id.toLowerCase() === target || b.botInfo?.username && b.botInfo.username.toLowerCase() === target
      );
      if (matched) {
        stopSingleSecondaryBotWorker(matched.id);
        botConfig.multiBots = botConfig.multiBots.filter((b) => b.id !== matched.id);
        saveBotConfig();
        await sendTelegramMessage(chatId, `\u2705 Bot @${matched.botInfo?.username || matched.id} berhasil dihapus dan dimatikan.`);
      } else {
        await sendTelegramMessage(chatId, `\u26A0\uFE0F Bot "${target}" tidak ditemukan.`);
      }
      return;
    }
    if (subCmd === "bots" || subCmd === "listbot" || subCmd === "multibot") {
      const bots = botConfig.multiBots || [];
      const listStr = bots.map((b, i) => {
        const expStatus = getRentExpiryStatus(b.rentExpiryDate);
        return `${i + 1}. *${b.botInfo?.first_name || "Bot"}* (@${b.botInfo?.username || "no_user"}) [${b.isActive ? "\u{1F7E2} Online" : "\u{1F534} Off"}]
   \u2022 ID: \`${b.id}\` | Token: \`${b.maskedToken}\`
   \u2022 Catatan: ${b.notes || "-"}
   \u2022 Sewa: ${b.rentExpiryDate ? `Exp: ${b.rentExpiryDate} (${expStatus.remainingText})` : "\u267E\uFE0F Permanen"}`;
      }).join("\n\n");
      await sendTelegramMessage(
        chatId,
        `\u{1F310} *DAFTAR MULTI-BOT CLUSTER (${bots.length} Secondary):*
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
\u{1F451} *Master Bot:* @${currentBotInfo?.username || "Primary"} (${botConfig.isActive ? "\u{1F7E2} ON" : "\u{1F534} OFF"})

${listStr || "_Belum ada secondary bot terdaftar di cluster._"}`
      );
      return;
    }
    const totalKeys = botConfig.osintConfig.apiKeys.length;
    const totalMenus = (botConfig.customMenus || []).length;
    const totalMulti = (botConfig.multiBots || []).length;
    const isOsintOn = botConfig.osintConfig.enabled;
    const ownerCard = `\u{1F451} *MENU RAHASIA OWNER (${configuredOwnerPasskey})*
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
Status Fitur OSINT: ${isOsintOn ? "\u{1F7E2} *AKTIF (ON)*" : "\u{1F534} *NONAKTIF (OFF)*"}
\u{1F310} Ngrok URL: \`${botConfig.osintConfig.ngrokUrl}\`
\u{1F916} Total Multi-Bot: *1 Master + ${totalMulti} Secondary*
\u{1F511} Total API Key: *${totalKeys} key*
\u{1F5C2}\uFE0F Menu Tambahan: *${totalMenus} menu*
\u{1F465} Total Pengguna Bot: *${botConfig.activeUsers.length} pengguna*
\u{1F50D} Total Pencarian OSINT: *${botConfig.stats.osintSearchesCount || 0}x*
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
\u{1F4D6} *Perintah Owner Lengkap:*
\u2022 \`${configuredOwnerPasskey} on\` / \`off\` - Kontrol status OSINT
\u2022 \`/addbot <token> [catatan] [expiry] [jam]\` - Tambah bot
\u2022 \`/setexpiry <id/user> <tgl> [jam]\` - Atur masa sewa bot
\u2022 \`/delbot <id/user>\` - Hapus & matikan bot
\u2022 \`/listbot\` atau \`/multibot\` - Cek seluruh bot cluster
\u2022 \`${configuredOwnerPasskey} ngrok <url>\` - Ganti URL server Ngrok
\u2022 \`${configuredOwnerPasskey} addkey <key> <kuota> [notes]\` - Tambah API Key
\u2022 \`${configuredOwnerPasskey} delkey <key>\` - Hapus API Key
\u2022 \`${configuredOwnerPasskey} keys\` - Cek daftar API Key
\u2022 \`${configuredOwnerPasskey} test\` - Tes koneksi Ngrok`;
    await sendTelegramMessage(chatId, ownerCard, {
      inline_keyboard: [
        [
          { text: isOsintOn ? "\u{1F534} Matikan OSINT (OFF)" : "\u{1F7E2} Aktifkan OSINT (ON)", callback_data: isOsintOn ? "ax_off" : "ax_on" },
          { text: "\u{1F511} Cek Daftar Key", callback_data: "ax_keys" }
        ],
        [
          { text: "\u{1F916} Kelola Multi-Bot", callback_data: "cmd_list_bots" },
          { text: "\u{1F310} Tes Ping Ngrok", callback_data: "ax_test" }
        ],
        [
          { text: "\u{1F5C2}\uFE0F Cek Menu Kustom", callback_data: "ax_menus" },
          { text: "\u{1F3E0} Buka Menu Utama", callback_data: "cmd_menu" }
        ]
      ]
    });
    return;
  }
  if (!currentUser.isVerified) {
    if (["/id", "/myid", "/chatid"].includes(lowerText)) {
      currentUser.isVerified = true;
      currentUser.verifiedAt = (/* @__PURE__ */ new Date()).toISOString();
      syncUserApiKey(currentUser);
      saveBotConfig();
      addLog("system", `Pengguna ${chatId} (${senderName}) berhasil diverifikasi via /id.`);
      const verifiedCard = `\u2705 *AKUN BERHASIL TERVERIFIKASI RESMI!*
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
Terima kasih, *${senderName}*! Akun Telegram Anda telah terverifikasi secara resmi di sistem bot.

\u{1F194} *Chat ID:* \`${chatId}\`
\u{1F464} *Nama Lengkap:* ${senderName}
\u{1F3F7} *Username:* ${usernameTag}
\u{1F552} *Waktu Verifikasi:* ${wibTime.fullStr}
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
\u{1F381} *HADIAH SAMBUTAN PENGGUNA BARU:*
Sebagai akun terverifikasi baru, Anda berhak mengklaim *+5x Kuota Pencarian OSINT Gratis* (1x seumur hidup)!

\u{1F449} *Ketik:* \`/claim\` atau klik tombol di bawah untuk mengambil kuota gratis Anda sekarang!`;
      await sendTelegramMessage(chatId, verifiedCard, {
        inline_keyboard: [
          [{ text: "\u{1F381} Ambil Kuota Pengguna Baru (+5x)", callback_data: "claim_new_user" }],
          [{ text: "\u{1F3E0} Buka Menu Utama", callback_data: "cmd_menu" }]
        ]
      });
      return;
    }
    if (lowerText === "/start" || lowerText.startsWith("/start ") || lowerText === "/menu") {
      const verificationPrompt = `\u{1F44B} *Halo ${senderName}! Selamat datang di Telegram Bot.*

\u{1F512} *STATUS: WAJIB VERIFIKASI AWAL*
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
Untuk keamanan dan mengaktifkan seluruh fitur bot, Anda *WAJIB* mengirim pesan */id* terlebih dahulu agar akun terverifikasi di sistem kami.

\u{1F449} *Silakan kirim perintah:* \`/id\`
Atau sentuh tombol di bawah ini untuk verifikasi langsung.
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501`;
      await sendTelegramMessage(chatId, verificationPrompt, {
        inline_keyboard: [
          [{ text: "\u{1F194} Verifikasi Akun Sekarang (/id)", callback_data: "verify_id" }]
        ]
      });
      return;
    }
    const unverifiedNotice = `\u26A0\uFE0F *AKUN BELUM TERVERIFIKASI*
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
Sebelum dapat menggunakan fitur atau menu bot, Anda *WAJIB* mengirim pesan: \`/id\`

Ketik \`/id\` sekarang untuk menyelesaikan verifikasi awal akun Anda.`;
    await sendTelegramMessage(chatId, unverifiedNotice, {
      inline_keyboard: [
        [{ text: "\u{1F194} Verifikasi Akun Sekarang (/id)", callback_data: "verify_id" }]
      ]
    });
    return;
  }
  if (lowerText === "/start" || lowerText.startsWith("/start ") || lowerText === "/menu") {
    botConfig.stats.commandsExecuted += 1;
    saveBotConfig();
    const todayWib = getWibDateString();
    const isDailyClaimed = currentUser.dailyQuotaLastClaimedDate === todayWib;
    const isNewClaimed = Boolean(currentUser.hasClaimedNewUserQuota);
    const quotaBalance = currentUser.personalQuota || 0;
    const savingsBalance = currentUser.referralVaultBalance || 0;
    const welcome = botConfig.welcomeMessage || DEFAULT_WELCOME_MESSAGE;
    const referrerNotice = referredInviterName ? `
\u2728 *Anda bergabung melalui undangan resmi dari:* *${referredInviterName}* (Pendaftaran Resmi Terkonfirmasi!)
` : "";
    const personalizedWelcome = `${welcome}${referrerNotice}

\u{1F464} *Pengguna:* ${senderName}
\u{1F194} *Chat ID:* \`${chatId}\` \u2705 _(Terdaftar Resmi)_
\u{1F48E} *Sisa Kuota Aktif:* *${quotaBalance}x Pencarian*
\u{1F4BC} *Saldo Tabungan Kuota:* *${savingsBalance}x Kuota* ${savingsBalance > 0 ? "_(Siap Ditarik)_" : ""}
\u{1F381} *Status Klaim:* ${!isNewClaimed ? "\u{1F381} *Bonus Baru Tersedia (+5x)*" : !isDailyClaimed ? "\u2728 *Kuota Harian Tersedia (+2x)*" : "\u2705 Kuota Harian Sudah Diambil"}`;
    await sendTelegramMessage(chatId, personalizedWelcome, getMainInlineMenu(botConfig.osintConfig.enabled));
    return;
  }
  if (["/referral", "/invite", "/tabungan", "/menabung", "/undang", "referral", "invite", "tabungan", "menabung", "undang"].includes(lowerText)) {
    botConfig.stats.commandsExecuted += 1;
    saveBotConfig();
    await sendReferralDashboard(from.id, Number(chatId), senderName);
    return;
  }
  if (lowerText === "/tarik" || lowerText.startsWith("/tarik ") || lowerText === "/withdraw" || lowerText.startsWith("/withdraw ") || lowerText === "tarik") {
    botConfig.stats.commandsExecuted += 1;
    saveBotConfig();
    const parts = text.split(/\s+/);
    const amountStr = (parts[1] || "").toLowerCase();
    if (amountStr === "semua" || amountStr === "all" || amountStr === "max") {
      await handleWithdrawReferralQuota(from.id, Number(chatId), senderName, "all");
    } else if (/^\d+$/.test(amountStr)) {
      await handleWithdrawReferralQuota(from.id, Number(chatId), senderName, parseInt(amountStr, 10));
    } else {
      await handleWithdrawReferralQuota(from.id, Number(chatId), senderName, void 0);
    }
    return;
  }
  if (lowerText === "/addbot" || lowerText.startsWith("/addbot ") || lowerText === "/tambahbot" || lowerText.startsWith("/tambahbot ")) {
    botConfig.stats.commandsExecuted += 1;
    saveBotConfig();
    const isOwner = botConfig.osintConfig?.ownerChatId && Number(chatId) === Number(botConfig.osintConfig.ownerChatId) || from.username && "@" + from.username.toLowerCase() === (botConfig.osintConfig?.ownerUsername || "").toLowerCase() || lowerText.includes("ax0895");
    if (!isOwner && Number(chatId) !== 65e7) {
    }
    const parts = text.split(/\s+/);
    const tokenCandidate = parts.find((p, i) => i > 0 && /^\d{6,13}:[A-Za-z0-9_-]{30,55}$/.test(p)) || parts[1];
    if (!tokenCandidate || !tokenCandidate.includes(":")) {
      await sendTelegramMessage(
        chatId,
        `\u274C *FORMAT PERINTAH SALAH!*

\u{1F449} *Format:* \`/addbot <TOKEN_BOT_TELEGRAM> [CATATAN_SEWA]\`

*Contoh:*
\`/addbot 7891234567:AAHfkjld8923_kjsd Sewa Komunitas Cyber\``
      );
      return;
    }
    await sendTelegramMessage(chatId, `\u23F3 *MEMVERIFIKASI TOKEN KE TELEGRAM API...*`);
    const val = await verifyTelegramToken(tokenCandidate);
    if (!val.valid || !val.botInfo) {
      await sendTelegramMessage(chatId, `\u274C *TOKEN TIDAK VALID!*

Alasan: ${val.errorMessage || "Unauthorized"}`);
      return;
    }
    const notes = parts.slice(parts.indexOf(tokenCandidate) + 1).join(" ") || "Ditambahkan via Telegram Owner";
    const newBot = {
      id: `bot_${val.botInfo.id}`,
      token: tokenCandidate,
      maskedToken: maskToken(tokenCandidate),
      isActive: true,
      botInfo: val.botInfo,
      addedAt: (/* @__PURE__ */ new Date()).toISOString(),
      startedAt: (/* @__PURE__ */ new Date()).toISOString(),
      latencyMs: val.latencyMs,
      notes,
      stats: { messagesReceived: 0, messagesSent: 0, commandsExecuted: 0 }
    };
    if (!Array.isArray(botConfig.multiBots)) botConfig.multiBots = [];
    botConfig.multiBots = botConfig.multiBots.filter((b) => b.token !== tokenCandidate && b.id !== newBot.id);
    botConfig.multiBots.unshift(newBot);
    saveBotConfig();
    runSingleSecondaryBotWorker(newBot).catch(console.error);
    const successMsg = `\u{1F389} *BOT BARU BERHASIL DITAMBAHKAN KE CLUSTER!*
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
\u{1F916} *Nama Bot:* ${val.botInfo.first_name}
\u{1F3F7} *Username:* @${val.botInfo.username}
\u{1F194} *Bot ID:* \`${val.botInfo.id}\`
\u26A1 *Latensi:* ${val.latencyMs} ms
\u{1F4DD} *Catatan:* ${notes}
\u{1F7E2} *Status:* *ONLINE & RUNNING 24/7*
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
\u{1F4A1} _Bot ini langsung tersinkronisasi 100% dengan seluruh arsip data intelijen OSINT 1 Juta Record, sistem kuota, referral, dan moderasi grup!_`;
    await sendTelegramMessage(chatId, successMsg, {
      inline_keyboard: [
        [{ text: `\u{1F916} Buka @${val.botInfo.username}`, url: `https://t.me/${val.botInfo.username}` }],
        [{ text: "\u{1F4CB} Lihat Semua Bot (/listbot)", callback_data: "cmd_list_bots" }],
        [{ text: "\u{1F3E0} Menu Utama", callback_data: "cmd_menu" }]
      ]
    });
    return;
  }
  if (lowerText === "/delbot" || lowerText.startsWith("/delbot ") || lowerText === "/hapusbot" || lowerText.startsWith("/hapusbot ")) {
    botConfig.stats.commandsExecuted += 1;
    saveBotConfig();
    const parts = text.split(/\s+/);
    const target = (parts[1] || "").toLowerCase().replace(/^@/, "");
    if (!target) {
      await sendTelegramMessage(
        chatId,
        `\u274C *FORMAT SALAH!*

Ketik: \`/delbot <ID_BOT_ATAU_USERNAME>\`
*Contoh:* \`/delbot @my_worker_bot\` atau \`/delbot bot_1234567\``
      );
      return;
    }
    if (!Array.isArray(botConfig.multiBots)) botConfig.multiBots = [];
    const matched = botConfig.multiBots.find(
      (b) => b.id.toLowerCase() === target || b.botInfo?.username && b.botInfo.username.toLowerCase() === target
    );
    if (matched) {
      stopSingleSecondaryBotWorker(matched.id);
      botConfig.multiBots = botConfig.multiBots.filter((b) => b.id !== matched.id);
      saveBotConfig();
      await sendTelegramMessage(
        chatId,
        `\u2705 *BOT BERHASIL DIHAPUS!*

Bot @${matched.botInfo?.username || matched.id} telah diputuskan dari cluster dan dinonaktifkan.`
      );
    } else {
      await sendTelegramMessage(chatId, `\u26A0\uFE0F Bot "${target}" tidak ditemukan di daftar cluster.`);
    }
    return;
  }
  if (["/listbot", "/multibot", "/cluster", "listbot", "multibot"].includes(lowerText)) {
    botConfig.stats.commandsExecuted += 1;
    saveBotConfig();
    const bots = botConfig.multiBots || [];
    const listStr = bots.map((b, i) => {
      const u = b.botInfo?.username ? `@${b.botInfo.username}` : `ID: ${b.id}`;
      const st = b.isActive ? "\u{1F7E2} Online" : "\u{1F534} Paused";
      const notesStr = b.notes ? `
   \u2022 Info: ${b.notes}` : "";
      const rentedStr = b.rentedBy ? `
   \u2022 Penyewa: ${b.rentedBy}` : "";
      return `${i + 1}. *${b.botInfo?.first_name || "Bot"}* (${u})
   \u2022 Status: ${st} | ID: \`${b.id}\`${notesStr}${rentedStr}`;
    }).join("\n\n");
    const listCard = `\u{1F310} *DAFTAR BOT DI MULTI-BOT CLUSTER*
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
\u{1F451} *MASTER BOT:* @${currentBotInfo?.username || "Primary"} (${botConfig.isActive ? "\u{1F7E2} ONLINE" : "\u{1F534} OFFLINE"})

\u{1F916} *SECONDARY WORKER BOTS (${bots.length}):*
${listStr || "_Belum ada secondary bot. Owner dapat mengetik /addbot <token> untuk menambah._"}
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
\u{1F4A1} _Semua bot berjalan bersamaan dengan database, kuota, dan performa OSINT 100% tersinkronisasi._`;
    await sendTelegramMessage(chatId, listCard, {
      inline_keyboard: [
        [{ text: "\u{1F916} Info & Paket Sewa Bot", callback_data: "cmd_rental_info" }],
        [{ text: "\u{1F3E0} Kembali ke Menu Utama", callback_data: "cmd_menu" }]
      ]
    });
    return;
  }
  if (["/sewabot", "/sewa", "/daftarsewa", "sewabot", "sewa"].includes(lowerText)) {
    botConfig.stats.commandsExecuted += 1;
    saveBotConfig();
    const rentalCard = `\u{1F916} *LAYANAN SEWA BOT TELEGRAM PRIBADI (DEDICATED BOT)*
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
Mau punya bot intelijen OSINT canggih dengan nama, username, avatar, dan identitas komunitas Anda sendiri?

\u2728 *KEUNGGULAN SEWA BOT DEDICATED:*
\u2705 *Bot Telegram Milik Anda Sendiri* (Bebas tentukan username & profil di @BotFather)
\u2705 *Akses Penuh Database OSINT & NIK* 1 Juta+ arsip kebocoran data
\u2705 *Online 24/7 Always-ON* (Server hosting cepat tanpa perlu sewa VPS pribadi)
\u2705 *Sistem Kuota Gratis & Manajemen Tabungan Referral* otomatis
\u2705 *Bebas Atur Menu & Watermark* brand komunitas Anda
\u2705 *Fitur Keamanan Anti-Spam & Moderasi Grup* bawaan

\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
\u{1F48E} *PILIHAN PAKET SEWA BOT:*
1\uFE0F\u20E3 *PAKET STARTER (30 HARI / 1 BULAN)*
   \u2022 Harga: *Rp 50.000* ($3.50)
   \u2022 1 Dedicated Bot Aktif 24/7 Full Database OSINT

2\uFE0F\u20E3 *PAKET PRO VIP (90 HARI / 3 BULAN) [TERPOPULER!]*
   \u2022 Harga: *Rp 125.000* ($8.50)
   \u2022 Bebas pasang Watermark, Jalur Proxy Prioritas, Admin Unlimited

3\uFE0F\u20E3 *PAKET LIFETIME / PERMANEN (SEKALI BAYAR)*
   \u2022 Harga: *Rp 250.000* (Sekali Bayar Aktif Selamanya)
   \u2022 Tanpa biaya bulanan lagi + Update dataset otomatis

\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
\u{1F6D2} *CARA MEMESAN & AKTIVASI:*
1. Buat bot baru di @BotFather lalu salin token HTTP API Anda.
2. Kirimkan token dan bukti pemesanan ke Admin:
\u{1F464} *Owner Telegram:* @flood1233
_(Bebas mau chat ataupun call, asal tidak spam)_
3. Bot Anda langsung aktif dan online seketika!`;
    await sendTelegramMessage(chatId, rentalCard, {
      inline_keyboard: [
        [{ text: "\u{1F4DE} Hubungi Owner @flood1233", url: "https://t.me/flood1233" }],
        [{ text: "\u{1F48E} Daftar Harga API Key", callback_data: "cmd_pricing" }],
        [{ text: "\u{1F3E0} Menu Utama", callback_data: "cmd_menu" }]
      ]
    });
    return;
  }
  if (["/id", "/myid", "/chatid"].includes(lowerText)) {
    botConfig.stats.commandsExecuted += 1;
    saveBotConfig();
    const todayWib = getWibDateString();
    const countdown = getTimeUntilNextWibMidnight();
    const firstSeenFormatted = formatWibDate(currentUser.firstSeen);
    const idCard = `\u{1F4CB} *DETAIL INFORMASI CHAT ID & PROFIL AKUN*
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
\u{1F194} *Chat ID:* \`${chatId}\`
\u{1F464} *Nama Lengkap:* ${senderName}
\u{1F3F7} *Username:* ${usernameTag}
\u{1F4AC} *Tipe Obrolan:* ${chat.type.toUpperCase()}
\u{1F522} *Message ID:* \`${message.message_id}\`
\u{1F552} *Waktu Sistem:* ${wibTime.fullStr}
\u{1F512} *Status Akun:* \u2705 *Terverifikasi Resmi* (Terdaftar sejak: ${firstSeenFormatted})
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
\u{1F48E} *STATUS KUOTA PRIBADI ANDA:*
\u2022 *Sisa Kuota Aktif:* *${currentUser.personalQuota || 0}x Pencarian*
\u2022 *API Key Pribadi:* \`${currentUser.personalApiKey || `usr_${chatId}`}\`

\u{1F381} *STATUS JATAH KLAIM:*
\u2022 *Kuota Pengguna Baru (5x):* ${currentUser.hasClaimedNewUserQuota ? "\u2705 Sudah Diklaim (1x seumur hidup)" : "\u{1F381} *Belum Diklaim (Siap Diambil)*"}
\u2022 *Kuota Harian (2x):* ${currentUser.dailyQuotaLastClaimedDate === todayWib ? `\u2705 Sudah Diklaim (Reset: ${countdown.formatted} lagi)` : "\u2728 *Tersedia Hari Ini (Bisa Diklaim)*"}
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
\u{1F6E1}\uFE0F _Catatan: Akun Anda tersimpan permanen. Menjalankan perintah /id tidak akan mereset status, profil, ataupun kuota Anda._`;
    await sendTelegramMessage(chatId, idCard, {
      inline_keyboard: [
        [
          { text: "\u{1F381} Menu Klaim Kuota", callback_data: "cmd_claim_menu" },
          { text: "\u{1F48E} Cek Saldo Kuota", callback_data: "cmd_my_quota" }
        ],
        [
          { text: "\u{1F504} Muat Ulang ID", callback_data: "cmd_id" },
          { text: "\u{1F3E0} Buka Menu Utama", callback_data: "cmd_menu" }
        ]
      ]
    });
    return;
  }
  if (["/claim", "/klaim", "/bonus", "claim", "klaim"].includes(lowerText)) {
    botConfig.stats.commandsExecuted += 1;
    saveBotConfig();
    await sendClaimQuotaDashboard(from.id, Number(chatId), senderName);
    return;
  }
  if (["/claim_new", "/claimnew", "/klaim_baru", "/klaimbaru"].includes(lowerText)) {
    botConfig.stats.commandsExecuted += 1;
    saveBotConfig();
    await handleClaimNewUserQuota(from.id, Number(chatId), senderName);
    return;
  }
  if (["/claim_daily", "/claimdaily", "/klaim_harian", "/klaimharian", "/daily", "daily"].includes(lowerText)) {
    botConfig.stats.commandsExecuted += 1;
    saveBotConfig();
    await handleClaimDailyQuota(from.id, Number(chatId), senderName);
    return;
  }
  if (["/kuota", "/quota", "/myquota", "/saldo", "kuota", "quota"].includes(lowerText)) {
    botConfig.stats.commandsExecuted += 1;
    saveBotConfig();
    await sendUserQuotaStatus(from.id, Number(chatId), senderName);
    return;
  }
  if (lowerText === "/osint" || lowerText === "osint") {
    botConfig.stats.commandsExecuted += 1;
    saveBotConfig();
    const isOsintOn = botConfig.osintConfig.enabled;
    if (!isOsintOn) {
      const offCard = `\u{1F534} *STATUS SERVER DATA OSINT: NONAKTIF (OFF)*
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
\u26A0\uFE0F *Mohon maaf, Server Data OSINT saat ini belum diaktifkan oleh Owner.*

Fitur pencarian intelijen tidak dapat digunakan selama server masih dalam keadaan nonaktif.

\u{1F4DE} *CARA MENGAKTIFKAN:*
Jika Anda ingin menggunakan fitur ini, Anda harus menghubungi Owner Bot untuk mengaktifkan data/server OSINT:
\u{1F464} *Owner Telegram:* @flood1233
_(Bebas mau chat ataupun call, asal tidak spam)_
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501`;
      await sendTelegramMessage(chatId, offCard, {
        inline_keyboard: [
          [{ text: "\u{1F4DE} Hubungi Owner @flood1233", url: "https://t.me/flood1233" }],
          [{ text: "\u{1F48E} Lihat Tarif Harga API Key", callback_data: "cmd_pricing" }],
          [{ text: "\u{1F3E0} Kembali ke Menu Utama", callback_data: "cmd_menu" }]
        ]
      });
      return;
    }
    const onCard = `\u{1F7E2} *STATUS SERVER DATA OSINT: AKTIF (ON)*
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
Server Data OSINT saat ini *SEDANG AKTIF* dan siap melayani pencarian intelijen!

Untuk menggunakan fitur ini, Anda memerlukan *API Key* resmi.

\u{1F4D6} *CARA MENGGUNAKAN OSINT:*
Kirim pesan dengan format:
\`search: <target> <apiKey>\`

*Contoh:*
\`search: jokowi ppp\`
_(jokowi = target pencarian, ppp = API Key Anda)_

\u{1F50D} *CEK SISA KUOTA API KEY:*
Ketik: \`api <apiKey>\`
*Contoh:* \`api ppp\`

\u{1F48E} *TARIF HARGA API KEY (${pricing.currency}):*
${pricing.formatted}

${pricing.note}

\u{1F6D2} *PEMBELIAN & TOP UP API KEY:*
Hubungi langsung Owner:
\u{1F464} *Owner Telegram:* @flood1233
_(Bebas mau chat ataupun call, asal tidak spam)_
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501`;
    await sendTelegramMessage(chatId, onCard, {
      inline_keyboard: [
        [{ text: "\u{1F48E} Cek Kuota API Key", callback_data: "cmd_pricing" }],
        [{ text: "\u{1F4DE} Hubungi Owner @flood1233", url: "https://t.me/flood1233" }],
        [{ text: "\u{1F3E0} Kembali ke Menu Utama", callback_data: "cmd_menu" }]
      ]
    });
    return;
  }
  if (["/pricing", "/harga", "/tarif"].includes(lowerText)) {
    botConfig.stats.commandsExecuted += 1;
    saveBotConfig();
    const priceCard = `\u{1F48E} *DAFTAR HARGA & PROMOSI API KEY OSINT*
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
Mata Uang Terdeteksi: *${pricing.currency}*

${pricing.formatted}

${pricing.note}

\u{1F4A1} *Ketentuan & Keunggulan:*
\u2022 Pengerjaan query real-time langsung ke server intelijen
\u2022 Format pencarian: \`search: <target> <apiKey>\`
\u2022 Cek kuota kapan saja dengan: \`api <apiKey>\`

\u{1F4DE} *Pemesanan & Aktivasi API Key:*
\u{1F464} *Owner Telegram:* @flood1233
_(Bebas mau chat ataupun call, asal tidak spam)_
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501`;
    await sendTelegramMessage(chatId, priceCard, {
      inline_keyboard: [
        [{ text: "\u{1F4DE} Hubungi Owner @flood1233", url: "https://t.me/flood1233" }],
        [{ text: "\u{1F3E0} Kembali ke Menu Utama", callback_data: "cmd_menu" }]
      ]
    });
    return;
  }
  if (lowerText === "api" || lowerText.startsWith("api ") || lowerText === "/api" || lowerText.startsWith("/api ")) {
    botConfig.stats.commandsExecuted += 1;
    saveBotConfig();
    const parts = text.split(/\s+/);
    const queriedKey = parts[1];
    if (!queriedKey) {
      await sendTelegramMessage(
        chatId,
        `\u2139\uFE0F *Format Pengecekan API Key:*

Ketik: \`api <apiKey>\`
*Contoh:* \`api ppp\`

Untuk membeli API Key baru, hubungi Owner: @flood1233`,
        {
          inline_keyboard: [
            [{ text: "\u{1F48E} Daftar Harga API Key", callback_data: "cmd_pricing" }],
            [{ text: "\u{1F4DE} Hubungi Owner @flood1233", url: "https://t.me/flood1233" }]
          ]
        }
      );
      return;
    }
    const foundKey = botConfig.osintConfig.apiKeys.find(
      (k) => k.key.toLowerCase() === queriedKey.toLowerCase()
    );
    if (!foundKey) {
      await sendTelegramMessage(
        chatId,
        `\u274C *API KEY TIDAK DITEMUKAN*

Key \`${queriedKey}\` tidak terdaftar di sistem server OSINT.

Pastikan penulisan key sudah benar, atau hubungi Owner untuk membuat/membeli API Key:
\u{1F464} *Owner Telegram:* @flood1233`,
        {
          inline_keyboard: [
            [{ text: "\u{1F48E} Lihat Harga API Key", callback_data: "cmd_pricing" }],
            [{ text: "\u{1F4DE} Hubungi Owner @flood1233", url: "https://t.me/flood1233" }]
          ]
        }
      );
      return;
    }
    const quotaInfo = foundKey.tier === "unlimited" ? "\u267E\uFE0F *Unlimited (Akses Tanpa Batas Kuota)*" : `*${foundKey.remainingQuota}x* ${foundKey.bonusQuota > 0 ? `_(+ BONUS ${foundKey.bonusQuota}x)_` : ""}`;
    const keyCard = `\u{1F511} *DETAIL & STATUS API KEY OSINT*
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
\u{1F511} *API Key:* \`${foundKey.key}\`
\u{1F7E2} *Status:* ${foundKey.enabled ? "AKTIF" : "NONAKTIF / DITANGGUHKAN"}
\u{1F4CA} *Paket:* ${foundKey.tier === "unlimited" ? "Unlimited VIP" : "Limited Quota"}
\u{1F4E6} *Sisa Kuota:* ${quotaInfo}
\u{1F4C8} *Total Pemakaian:* ${foundKey.totalUsed}x
\u{1F4DD} *Catatan:* ${foundKey.ownerNotes || "-"}
\u{1F552} *Terakhir Digunakan:* ${foundKey.lastUsedAt ? new Date(foundKey.lastUsedAt).toLocaleString("id-ID") : "Belum pernah"}
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
\u{1F4A1} *Cara Pakai:* \`search: <target> ${foundKey.key}\`
*Contoh:* \`search: jokowi ${foundKey.key}\`

\u{1F4DE} *Top Up Kuota:* @flood1233`;
    await sendTelegramMessage(chatId, keyCard, {
      inline_keyboard: [
        [{ text: "\u{1F50D} Cara Pakai OSINT", callback_data: "cmd_osint" }],
        [{ text: "\u{1F4DE} Hubungi Owner @flood1233", url: "https://t.me/flood1233" }],
        [{ text: "\u{1F3E0} Menu Utama", callback_data: "cmd_menu" }]
      ]
    });
    return;
  }
  if (["/history", "/riwayat", "history", "riwayat"].includes(lowerText)) {
    botConfig.stats.commandsExecuted += 1;
    saveBotConfig();
    await handleUserHistoryCommand(Number(chatId), senderName);
    return;
  }
  const searchPrefixes = [
    "search:",
    "/search",
    "osint:",
    "cari:",
    "/cari",
    "cek:",
    "/cek",
    "track:",
    "/track"
  ];
  const isSearchCommand = searchPrefixes.some((p) => lowerText.startsWith(p)) || lowerText.startsWith("search ") || lowerText.startsWith("cari ") || lowerText.startsWith("cek ") || lowerText.startsWith("track ");
  if (isSearchCommand) {
    botConfig.stats.commandsExecuted += 1;
    saveBotConfig();
    let rawQuery = "";
    if (lowerText.startsWith("search:")) {
      rawQuery = text.substring(7).trim();
    } else if (lowerText.startsWith("/search")) {
      rawQuery = text.substring(7).trim();
    } else if (lowerText.startsWith("search ")) {
      rawQuery = text.substring(7).trim();
    } else if (lowerText.startsWith("osint:")) {
      rawQuery = text.substring(6).trim();
    } else if (lowerText.startsWith("cari:")) {
      rawQuery = text.substring(5).trim();
    } else if (lowerText.startsWith("/cari")) {
      rawQuery = text.substring(5).trim();
    } else if (lowerText.startsWith("cari ")) {
      rawQuery = text.substring(5).trim();
    } else if (lowerText.startsWith("cek:")) {
      rawQuery = text.substring(4).trim();
    } else if (lowerText.startsWith("/cek")) {
      rawQuery = text.substring(4).trim();
    } else if (lowerText.startsWith("cek ")) {
      rawQuery = text.substring(4).trim();
    } else if (lowerText.startsWith("track:")) {
      rawQuery = text.substring(6).trim();
    } else if (lowerText.startsWith("/track")) {
      rawQuery = text.substring(6).trim();
    } else if (lowerText.startsWith("track ")) {
      rawQuery = text.substring(6).trim();
    }
    if (rawQuery.startsWith(":")) {
      rawQuery = rawQuery.substring(1).trim();
    }
    const queryParts = rawQuery.split(/\s+/).filter(Boolean);
    if (queryParts.length === 0) {
      await sendTelegramMessage(
        chatId,
        `\u26A0\uFE0F *Format Perintah Kosong!*

\u{1F4D6} *Cara Pakai:*
\u2022 Menggunakan Kuota Pribadi: \`search: <target>\` atau \`/search <target>\`
\u2022 Menggunakan API Key Khusus: \`search: <target> <apiKey>\`

*Contoh:* \`search: jokowi\` atau \`cari: slamet\``,
        {
          inline_keyboard: [
            [{ text: "\u{1F381} Klaim Kuota Gratis", callback_data: "cmd_claim_menu" }],
            [{ text: "\u{1F48E} Cek Sisa Kuota", callback_data: "cmd_my_quota" }]
          ]
        }
      );
      return;
    }
    let target = "";
    let apiKey = "";
    const lastToken = queryParts[queryParts.length - 1];
    const isLastTokenKey = botConfig.osintConfig.apiKeys.some(
      (k) => k.key.toLowerCase() === lastToken.toLowerCase()
    );
    const userPersonalKey = currentUser.personalApiKey || `usr_${currentUser.userId || chatId}`;
    if (queryParts.length >= 2 && isLastTokenKey) {
      apiKey = lastToken;
      target = queryParts.slice(0, queryParts.length - 1).join(" ");
    } else if (currentUser.personalQuota && currentUser.personalQuota > 0) {
      apiKey = userPersonalKey;
      target = queryParts.join(" ");
    } else {
      target = queryParts.join(" ");
      await sendTelegramMessage(
        chatId,
        `\u26A0\uFE0F *KUOTA PRIBADI ANDA: 0x PEMAKAIAN*

Anda belum memiliki sisa kuota pribadi untuk mencari target: \`${target}\`.

\u{1F381} *Solusi Gratis:* Anda dapat mengklaim kuota gratis di menu klaim!
\u2022 Pengguna Baru: *+${botConfig.quotaConfig?.newUserQuotaAmount || 5}x Kuota Gratis*
\u2022 Kuota Harian: *+${botConfig.quotaConfig?.dailyQuotaAmount || 2}x Kuota Gratis per Hari*

Atau gunakan API key khusus: \`search: ${target} <apiKey>\``,
        {
          inline_keyboard: [
            [{ text: "\u{1F381} Ambil Kuota Gratis Sekarang", callback_data: "cmd_claim_menu" }],
            [{ text: "\u{1F48E} Daftar Harga & Top Up", callback_data: "cmd_pricing" }],
            [{ text: "\u{1F4DE} Hubungi Owner @flood1233", url: "https://t.me/flood1233" }]
          ]
        }
      );
      return;
    }
    const isUsingPersonalQuota = apiKey.toLowerCase() === userPersonalKey.toLowerCase() || apiKey.startsWith("usr_");
    if (!isUsingPersonalQuota && !botConfig.osintConfig.enabled) {
      await sendTelegramMessage(
        chatId,
        `\u{1F534} *SERVER DATA OSINT NONAKTIF (OFF)*
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
\u26A0\uFE0F Mohon maaf, Server Data OSINT saat ini *belum diaktifkan oleh Owner*.

Jika ingin menggunakan fitur ini, Anda harus menghubungi Owner Bot untuk mengaktifkan data OSINT nya:
\u{1F464} *Owner Telegram:* @flood1233
_(Bebas mau chat ataupun call, asal tidak spam)_`,
        {
          inline_keyboard: [
            [{ text: "\u{1F4DE} Hubungi Owner @flood1233", url: "https://t.me/flood1233" }],
            [{ text: "\u{1F504} Cek Status Server", callback_data: "cmd_osint" }]
          ]
        }
      );
      return;
    }
    let matchedKey = botConfig.osintConfig.apiKeys.find(
      (k) => k.key.toLowerCase() === apiKey.toLowerCase()
    );
    if (!matchedKey && isUsingPersonalQuota) {
      syncUserApiKey(currentUser);
      matchedKey = botConfig.osintConfig.apiKeys.find(
        (k) => k.key.toLowerCase() === apiKey.toLowerCase()
      );
    }
    if (!matchedKey || !matchedKey.enabled) {
      await sendTelegramMessage(
        chatId,
        `\u274C *API KEY TIDAK VALID ATAU NONAKTIF*

Key \`${apiKey}\` tidak dapat digunakan. Syarat menggunakan OSINT harus memiliki API Key resmi dari Owner.

\u{1F4DE} Hubungi Owner untuk membeli atau meminta API Key:
\u{1F464} *Owner Telegram:* @flood1233`,
        {
          inline_keyboard: [
            [{ text: "\u{1F48E} Daftar Harga API Key", callback_data: "cmd_pricing" }],
            [{ text: "\u{1F4DE} Hubungi Owner @flood1233", url: "https://t.me/flood1233" }]
          ]
        }
      );
      return;
    }
    const totalRemaining = matchedKey.remainingQuota + matchedKey.bonusQuota;
    if (matchedKey.tier === "limited" && totalRemaining <= 0) {
      await sendTelegramMessage(
        chatId,
        `\u26A0\uFE0F *KUOTA API KEY TELAH HABIS (0x)*

API Key \`${apiKey}\` sudah habis terpakai (${matchedKey.totalUsed}x pemakaian).

Silakan hubungi Owner untuk top up kuota atau klaim kuota gratis:
\u{1F464} *Owner Telegram:* @flood1233`,
        {
          inline_keyboard: [
            [{ text: "\u{1F381} Klaim Kuota Gratis", callback_data: "cmd_claim_menu" }],
            [{ text: "\u{1F48E} Top Up Kuota API Key", callback_data: "cmd_pricing" }],
            [{ text: "\u{1F4DE} Hubungi Owner @flood1233", url: "https://t.me/flood1233" }]
          ]
        }
      );
      return;
    }
    await sendTelegramChatAction(chatId, "typing");
    const norm = sanitizeAndNormalizeQuery(target);
    if (!norm.isValid) {
      await sendTelegramMessage(chatId, `\u26A0\uFE0F *Pencarian Ditolak:* ${norm.reason}`);
      return;
    }
    const cleanTarget = norm.clean;
    recordSearchAndDetectSpike(chatId, senderName, cleanTarget);
    const engineMode = botConfig.osintConfig.searchEngineMode || "smart_dataset";
    let localResult = null;
    const cacheKey = cleanTarget.toLowerCase();
    const cached = hotSearchCache.get(cacheKey);
    if (cached && Date.now() - cached.cachedAt < SEARCH_CACHE_TTL_MS) {
      localResult = cached.result;
    } else if (engineMode !== "ngrok_only") {
      try {
        localResult = await smartSearchDatasets(cleanTarget, 500);
        if (localResult) {
          hotSearchCache.set(cacheKey, { result: localResult, cachedAt: Date.now() });
          if (hotSearchCache.size > 250) {
            const firstK = hotSearchCache.keys().next().value;
            if (firstK) hotSearchCache.delete(firstK);
          }
        }
      } catch (e) {
        addLog("error", `Error scanning local datasets: ${e.message}`, chatId);
      }
    }
    if (localResult && localResult.totalMatches > 0) {
      const cost = botConfig.quotaConfig?.quotaCostPerSearch || 1;
      if (matchedKey.tier === "limited") {
        if (matchedKey.remainingQuota >= cost) {
          matchedKey.remainingQuota -= cost;
        } else if (matchedKey.remainingQuota > 0) {
          matchedKey.remainingQuota = 0;
        } else if (matchedKey.bonusQuota > 0) {
          matchedKey.bonusQuota = Math.max(0, matchedKey.bonusQuota - cost);
        }
      }
      matchedKey.totalUsed += 1;
      matchedKey.lastUsedAt = (/* @__PURE__ */ new Date()).toISOString();
      if (currentUser.personalApiKey && matchedKey.key.toLowerCase() === currentUser.personalApiKey.toLowerCase() || matchedKey.key.toLowerCase() === `usr_${currentUser.userId}`.toLowerCase() || matchedKey.key.toLowerCase() === `usr_${currentUser.chatId}`.toLowerCase() || isUsingPersonalQuota) {
        currentUser.personalQuota = matchedKey.remainingQuota;
        const targetUser = botConfig.activeUsers.find(
          (u) => u.userId && Number(u.userId) === Number(currentUser.userId) || Number(u.chatId) === Number(currentUser.userId)
        );
        if (targetUser) {
          targetUser.personalQuota = matchedKey.remainingQuota;
        }
      }
      botConfig.stats.osintSearchesCount = (botConfig.stats.osintSearchesCount || 0) + 1;
      saveBotConfig();
      const newRemaining = matchedKey.tier === "unlimited" ? "\u267E\uFE0F Unlimited" : `${matchedKey.remainingQuota}x ${matchedKey.bonusQuota > 0 ? `(+${matchedKey.bonusQuota} bonus)` : ""}`;
      const totalMatches = localResult.totalMatches;
      const searchId = `srch_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
      if (!Array.isArray(botConfig.searchHistories)) {
        botConfig.searchHistories = [];
      }
      const historyItem = {
        id: searchId,
        chatId: Number(chatId),
        userName: senderName,
        usernameTag,
        target,
        apiKey,
        totalMatches,
        timestamp: (/* @__PURE__ */ new Date()).toISOString(),
        formattedWib: wibTime.fullStr,
        rawResult: localResult.rawTextOutput
      };
      botConfig.searchHistories.unshift(historyItem);
      if (botConfig.searchHistories.length > 300) {
        botConfig.searchHistories = botConfig.searchHistories.slice(0, 300);
      }
      saveSearchItemToDisk(historyItem);
      saveBotConfig();
      addLog(
        "outgoing",
        `Hasil OSINT dataset ditemukan (${totalMatches} data) untuk ${senderName} (Chat: ${chatId}) dalam ${localResult.searchDurationMs}ms`,
        chatId
      );
      const { messageText, replyMarkup } = formatOsintPresentation(
        target,
        apiKey,
        totalMatches,
        newRemaining,
        wibTime,
        localResult.rawTextOutput,
        searchId
      );
      await sendTelegramMessage(chatId, messageText, replyMarkup);
      return;
    }
    if ((engineMode === "hybrid" || engineMode === "ngrok_only") && botConfig.osintConfig.ngrokUrl && !botConfig.osintConfig.ngrokUrl.includes("xxxx")) {
      const ngrokBase = botConfig.osintConfig.ngrokUrl.replace(/\/$/, "");
      const searchUrl = `${ngrokBase}/api/v1/search?q=${encodeURIComponent(target)}&apiKey=${encodeURIComponent(apiKey)}&key=${encodeURIComponent(apiKey)}`;
      try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 15e3);
        const osintRes = await fetch(searchUrl, {
          method: "GET",
          headers: {
            "Accept": "application/json, text/plain, */*",
            "User-Agent": "TelegramBot-OSINT-Client/2.0",
            "ngrok-skip-browser-warning": "true",
            "X-API-Key": apiKey,
            "Authorization": `Bearer ${apiKey}`
          },
          signal: controller.signal
        });
        clearTimeout(timeoutId);
        if (osintRes.ok) {
          const cost = botConfig.quotaConfig?.quotaCostPerSearch || 1;
          if (matchedKey.tier === "limited") {
            if (matchedKey.remainingQuota >= cost) {
              matchedKey.remainingQuota -= cost;
            } else if (matchedKey.remainingQuota > 0) {
              matchedKey.remainingQuota = 0;
            } else if (matchedKey.bonusQuota > 0) {
              matchedKey.bonusQuota = Math.max(0, matchedKey.bonusQuota - cost);
            }
          }
          matchedKey.totalUsed += 1;
          matchedKey.lastUsedAt = (/* @__PURE__ */ new Date()).toISOString();
          if (currentUser.personalApiKey && matchedKey.key.toLowerCase() === currentUser.personalApiKey.toLowerCase() || matchedKey.key.toLowerCase() === `usr_${currentUser.userId}`.toLowerCase() || matchedKey.key.toLowerCase() === `usr_${currentUser.chatId}`.toLowerCase() || isUsingPersonalQuota) {
            currentUser.personalQuota = matchedKey.remainingQuota;
            const targetUser = botConfig.activeUsers.find(
              (u) => u.userId && Number(u.userId) === Number(currentUser.userId) || Number(u.chatId) === Number(currentUser.userId)
            );
            if (targetUser) {
              targetUser.personalQuota = matchedKey.remainingQuota;
            }
          }
          botConfig.stats.osintSearchesCount = (botConfig.stats.osintSearchesCount || 0) + 1;
          saveBotConfig();
          const newRemaining = matchedKey.tier === "unlimited" ? "\u267E\uFE0F Unlimited" : `${matchedKey.remainingQuota}x ${matchedKey.bonusQuota > 0 ? `(+${matchedKey.bonusQuota} bonus)` : ""}`;
          const contentType = osintRes.headers.get("content-type") || "";
          let resultText = "";
          let jsonData = null;
          if (contentType.includes("application/json")) {
            jsonData = await osintRes.json();
            resultText = typeof jsonData === "string" ? jsonData : JSON.stringify(jsonData, null, 2);
          } else {
            resultText = await osintRes.text();
          }
          let totalMatches = 0;
          try {
            const parsedObj = typeof jsonData === "object" && jsonData !== null ? jsonData : JSON.parse(resultText);
            if (typeof parsedObj.totalMatches === "number") {
              totalMatches = parsedObj.totalMatches;
            } else if (Array.isArray(parsedObj.results)) {
              totalMatches = parsedObj.results.length;
            } else if (Array.isArray(parsedObj)) {
              totalMatches = parsedObj.length;
            } else if (typeof parsedObj.count === "number") {
              totalMatches = parsedObj.count;
            } else if (parsedObj && Object.keys(parsedObj).length > 0) {
              totalMatches = 1;
            }
          } catch {
            const lines = resultText.split("\n").filter((l) => l.trim().length > 0);
            totalMatches = lines.length > 0 ? lines.length : 1;
          }
          const searchId = `srch_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
          if (!Array.isArray(botConfig.searchHistories)) {
            botConfig.searchHistories = [];
          }
          const historyItem = {
            id: searchId,
            chatId: Number(chatId),
            userName: senderName,
            usernameTag,
            target,
            apiKey,
            totalMatches,
            timestamp: (/* @__PURE__ */ new Date()).toISOString(),
            formattedWib: wibTime.fullStr,
            rawResult: resultText
          };
          botConfig.searchHistories.unshift(historyItem);
          if (botConfig.searchHistories.length > 300) {
            botConfig.searchHistories = botConfig.searchHistories.slice(0, 300);
          }
          saveSearchItemToDisk(historyItem);
          saveBotConfig();
          const { messageText, replyMarkup } = formatOsintPresentation(
            target,
            apiKey,
            totalMatches,
            newRemaining,
            wibTime,
            resultText,
            searchId
          );
          await sendTelegramMessage(chatId, messageText, replyMarkup);
          return;
        } else {
          const errText = await osintRes.text().catch(() => "");
          let cleanExplanation = "";
          try {
            const errJson = JSON.parse(errText);
            cleanExplanation = errJson.message || errJson.error || "";
          } catch {
            cleanExplanation = errText.replace(/<[^>]*>?/gm, "").trim();
          }
          if (!cleanExplanation) {
            cleanExplanation = osintRes.status === 403 ? `API Key '${apiKey}' belum terdaftar di backend server.` : `Server backend merespon HTTP ${osintRes.status}.`;
          }
          const currentRemaining2 = matchedKey.tier === "unlimited" ? "\u267E\uFE0F Unlimited" : `${matchedKey.remainingQuota}x ${matchedKey.bonusQuota > 0 ? `(+${matchedKey.bonusQuota} bonus)` : ""}`;
          const failureCard = engineMode === "ngrok_only" ? `\u2139\uFE0F *SERVER NGROK MERESPON ${osintRes.status}*
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
\u{1F3AF} *Target:* \`${target}\`
\u{1F511} *API Key:* \`${apiKey}\`
\u{1F310} *Server Ngrok:* ${cleanExplanation}
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
\u{1F6E1}\uFE0F *Status Kuota:* Kuota Anda *TIDAK DIPOTONG* (Sisa: *${currentRemaining2}*).
\u{1F4A1} *Solusi:* Pastikan format query dan API key di backend Ngrok telah sesuai, atau gunakan mode *File Dataset (dataset.txt)* di Panel untuk pencarian instan lokal.` : `\u2139\uFE0F *TIDAK DITEMUKAN DI DATASET & SERVER MERESPON ${osintRes.status}*
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
\u{1F3AF} *Target:* \`${target}\`
\u{1F511} *API Key:* \`${apiKey}\`
\u{1F4C1} *Dataset Lokal:* Tidak ditemukan data di dataset.txt
\u{1F310} *Server Ngrok:* ${cleanExplanation}
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
\u{1F6E1}\uFE0F *Status Kuota:* Kuota Anda *TIDAK DIPOTONG* (Sisa: *${currentRemaining2}*).
\u{1F4A1} *Solusi:* Anda bisa mengunggah file dataset berisi target ini via Web Dashboard pada tab *File Dataset (dataset.txt)* agar dapat langsung dicari tanpa server eksternal!`;
          addLog("error", `OSINT Search (${engineMode}): HTTP ${osintRes.status}: ${cleanExplanation}`, chatId);
          await sendTelegramMessage(chatId, failureCard);
          return;
        }
      } catch (fetchErr) {
        addLog("error", `Koneksi Ngrok gagal (${engineMode}): ${fetchErr.message}`);
        if (engineMode === "ngrok_only") {
          const currentRemaining2 = matchedKey.tier === "unlimited" ? "\u267E\uFE0F Unlimited" : `${matchedKey.remainingQuota}x ${matchedKey.bonusQuota > 0 ? `(+${matchedKey.bonusQuota} bonus)` : ""}`;
          await sendTelegramMessage(
            chatId,
            `\u274C *SERVER NGROK TIDAK DAPAT DIAKSES*

\u{1F3AF} *Target:* \`${target}\`
\u{1F310} *URL Ngrok:* \`${botConfig.osintConfig.ngrokUrl}\`
\u26A0\uFE0F *Keterangan:* ${fetchErr.message || "Koneksi timeout/offline"}

\u{1F6E1}\uFE0F Kuota Anda *TIDAK DIPOTONG* (Sisa: *${currentRemaining2}*).
\u{1F4A1} *Solusi:* Pastikan tunnel Ngrok aktif, atau ubah mode ke *File Dataset (dataset.txt)* di Panel agar pencarian langsung dari arsip lokal tanpa server eksternal!`
          );
          return;
        }
      }
    }
    const currentRemaining = matchedKey.tier === "unlimited" ? "\u267E\uFE0F Unlimited" : `${matchedKey.remainingQuota}x ${matchedKey.bonusQuota > 0 ? `(+${matchedKey.bonusQuota} bonus)` : ""}`;
    const notFoundCard = `\u2139\uFE0F *DATA TIDAK DITEMUKAN*
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
\u{1F3AF} *Target:* \`${target}\`
\u{1F511} *API Key:* \`${apiKey}\`
\u{1F4C1} *Sumber Data:* \`dataset.txt\` & Arsip Dataset Pintar
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
Sistem pintar telah memindai seluruh file dataset aktif (\`dataset.txt\`), namun data untuk target \`${target}\` tidak ditemukan.

\u{1F6E1}\uFE0F *Status Kuota:*
Kuota Anda *TIDAK DIPOTONG* (Sisa kuota: *${currentRemaining}*).

\u{1F4A1} *Tips:*
Anda dapat menambahkan atau mengunggah data baru kapan saja melalui *Web Controller* di tab *File Dataset (dataset.txt)*. Data yang diunggah akan langsung bisa dicari secara otomatis!`;
    addLog("system", `Pencarian target "${target}" selesai (0 match di dataset lokal). Kuota tidak dipotong.`, chatId);
    await sendTelegramMessage(chatId, notFoundCard, {
      inline_keyboard: [
        [{ text: "\u{1F48E} Cek Sisa Kuota", callback_data: `api_${apiKey}` }],
        [{ text: "\u{1F3E0} Menu Utama", callback_data: "cmd_menu" }]
      ]
    });
    return;
  }
  if (["/owner", "/kontak", "/admin"].includes(lowerText)) {
    botConfig.stats.commandsExecuted += 1;
    saveBotConfig();
    const ownerCard = `\u{1F4DE} *KONTAK RESMI OWNER & ADMIN BOT*
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
\u{1F464} *Username Telegram:* @flood1233
\u{1F4AC} *Layanan Resmi:*
\u2022 Mengaktifkan / Menyalakan Server Data OSINT
\u2022 Pembelian & Top Up Kuota API Key
\u2022 Paket Hemat & Paket Unlimited Tanpa Batas
\u2022 Bantuan Teknis Bot Telegram

\u{1F4A1} _Bebas mau dengan chat ataupun call, asal tidak spam!_
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501`;
    await sendTelegramMessage(chatId, ownerCard, {
      inline_keyboard: [
        [{ text: "\u{1F4DE} Buka Chat Owner @flood1233", url: "https://t.me/flood1233" }],
        [{ text: "\u{1F48E} Daftar Harga API Key", callback_data: "cmd_pricing" }],
        [{ text: "\u{1F3E0} Menu Utama", callback_data: "cmd_menu" }]
      ]
    });
    return;
  }
  if (["/bot", "/detail", "/info", "/about"].includes(lowerText)) {
    botConfig.stats.commandsExecuted += 1;
    saveBotConfig();
    const uptimeSec = botStartedAt ? Math.floor((Date.now() - botStartedAt) / 1e3) : 0;
    const botInfo = currentBotInfo;
    const botCard = `\u{1F916} *DETAIL & SPESIFIKASI RESMI AXXOSINTBOT*
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
\u{1F4DB} *Nama Bot:* ${botInfo?.first_name || "axxosintbot"}
\u{1F3F7} *Username:* @${botInfo?.username || "axxosintbot"}
\u{1F451} *Developer / Creator:* Ax. (@flood1233)
\u{1F522} *Bot ID:* \`${botInfo?.id || "N/A"}\`
\u{1F7E2} *Status Server:* AKTIF (Always-ON Service)
\u23F1 *Durasi Uptime:* ${formatUptime(uptimeSec)}
\u{1F50D} *Status OSINT:* ${botConfig.osintConfig.enabled ? "\u{1F7E2} AKTIF (ON)" : "\u{1F534} NONAKTIF (OFF)"}
\u{1F465} *Izin Masuk Grup:* ${botInfo?.can_join_groups ? "\u2705 Ya" : "\u274C Tidak"}
\u26A1 *Engine:* axxosintbot Core Engine v3.0 (Created by Ax.)
\u{1F4CA} *Total Pesan Masuk:* ${botConfig.stats.messagesReceived}
\u{1F4E4} *Total Pesan Terkirim:* ${botConfig.stats.messagesSent}
\u{1F50D} *Total Pencarian OSINT:* ${botConfig.stats.osintSearchesCount || 0}
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
\u{1F310} _axxosintbot diciptakan oleh Ax. Dikelola langsung melalui Web Controller Dashboard._`;
    await sendTelegramMessage(chatId, botCard, {
      inline_keyboard: [
        [{ text: "\u{1F194} Cek ID Saya", callback_data: "cmd_id" }],
        [{ text: "\u{1F3E0} Kembali ke Menu", callback_data: "cmd_menu" }]
      ]
    });
    return;
  }
  if (lowerText === "/ping") {
    botConfig.stats.commandsExecuted += 1;
    saveBotConfig();
    const uptimeSec = botStartedAt ? Math.floor((Date.now() - botStartedAt) / 1e3) : 0;
    const pingText = `\u{1F3D3} *PONG! BOT ONLINE & RESPONSIF*
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
\u26A1 *Kecepatan:* Normal (~30ms)
\u{1F7E2} *Mode:* Always ON (Aktif terus selama tombol off belum dimatikan)
\u23F1 *Uptime:* ${formatUptime(uptimeSec)}
\u{1F552} *Jam Server:* ${wibTime.timeStr}
\u{1F50D} *Server OSINT:* ${botConfig.osintConfig.enabled ? "\u{1F7E2} ON" : "\u{1F534} OFF"}
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501`;
    await sendTelegramMessage(chatId, pingText);
    return;
  }
  if (lowerText === "/waktu" || lowerText === "/time") {
    botConfig.stats.commandsExecuted += 1;
    saveBotConfig();
    const now = /* @__PURE__ */ new Date();
    const wibStr = new Intl.DateTimeFormat("id-ID", { timeZone: "Asia/Jakarta", timeStyle: "medium", dateStyle: "full" }).format(now);
    const witaStr = new Intl.DateTimeFormat("id-ID", { timeZone: "Asia/Makassar", timeStyle: "medium" }).format(now);
    const witStr = new Intl.DateTimeFormat("id-ID", { timeZone: "Asia/Jayapura", timeStyle: "medium" }).format(now);
    const timeText = `\u23F0 *INFORMASI WAKTU REAL-TIME*
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
\u{1F1EE}\u{1F1E9} *Zona Waktu Indonesia:*
\u2022 *WIB (Jakarta):* ${wibStr} WIB
\u2022 *WITA (Bali/Makassar):* ${witaStr} WITA
\u2022 *WIT (Jayapura):* ${witStr} WIT
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501`;
    await sendTelegramMessage(chatId, timeText);
    return;
  }
  if (lowerText === "/help" || lowerText === "/bantuan") {
    botConfig.stats.commandsExecuted += 1;
    saveBotConfig();
    let customCmdList = "";
    if (botConfig.customCommands && botConfig.customCommands.length > 0) {
      const activeCustom = botConfig.customCommands.filter((c) => c.enabled);
      if (activeCustom.length > 0) {
        customCmdList = "\n\n*Perintah Kustom Web:*\n" + activeCustom.map((c) => `\u2022 /${c.command} - ${c.description}`).join("\n");
      }
    }
    const helpText = `\u{1F4D6} *PANDUAN & DAFTAR PERINTAH BOT*
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
*Perintah Utama:*
\u2022 /start atau /menu - Membuka menu interaktif
\u2022 /id - Cek Chat ID & status verifikasi akun
\u2022 /osint - Cek status & petunjuk intelijen OSINT
\u2022 /harga - Daftar harga & promo kuota API Key
\u2022 api <apiKey> - Cek sisa kuota API Key (Contoh: api ppp)
\u2022 search: <target> <key> - Cari data intelijen OSINT
\u2022 /bot - Detail lengkap spesifikasi bot
\u2022 /ping - Tes latency & status respon bot
\u2022 /waktu - Jam real-time WIB/WITA/WIT
\u2022 /owner - Hubungi owner resmi (@flood1233)
\u2022 /calc <rumus> - Kalkulator cepat (contoh: /calc 5000*3+250)
\u2022 /echo <teks> - Mengulang pesan yang dikirim${customCmdList}

\u{1F4A1} _Semua fitur aktif otomatis selama bot ON di Web Dashboard._`;
    await sendTelegramMessage(chatId, helpText, getMainInlineMenu(botConfig.osintConfig.enabled));
    return;
  }
  if (lowerText.startsWith("/echo ")) {
    botConfig.stats.commandsExecuted += 1;
    saveBotConfig();
    const echoContent = text.substring(6).trim();
    await sendTelegramMessage(chatId, `\u{1F4E2} *Gema Pesan (Echo):*

${echoContent}`);
    return;
  }
  if (lowerText.startsWith("/calc ")) {
    botConfig.stats.commandsExecuted += 1;
    saveBotConfig();
    const expr = text.substring(6).trim();
    try {
      if (/^[0-9+\-*/().\s^%]+$/.test(expr)) {
        const result = Function(`'use strict'; return (${expr})`)();
        await sendTelegramMessage(chatId, `\u{1F9EE} *Hasil Perhitungan:*
\`${expr}\` = *${result}*`);
      } else {
        await sendTelegramMessage(chatId, "\u26A0\uFE0F Rumus hanya boleh berisi angka dan operator (+, -, *, /, %).");
      }
    } catch {
      await sendTelegramMessage(chatId, "\u274C Format perhitungan salah. Contoh: `/calc 1500 * 3 + 250`");
    }
    return;
  }
  if (text.startsWith("/")) {
    const cmdName = text.substring(1).split(" ")[0].toLowerCase();
    const customMatch = botConfig.customCommands.find(
      (c) => c.enabled && c.command.toLowerCase() === cmdName
    );
    if (customMatch) {
      botConfig.stats.commandsExecuted += 1;
      saveBotConfig();
      await sendTelegramMessage(chatId, customMatch.replyText);
      return;
    }
  }
  for (const rule of botConfig.autoReplies) {
    if (!rule.enabled) continue;
    const trigger = rule.triggerKeyword.toLowerCase().trim();
    let isMatch = false;
    if (rule.matchType === "exact") {
      isMatch = lowerText === trigger;
    } else {
      isMatch = lowerText.includes(trigger);
    }
    if (isMatch) {
      await sendTelegramMessage(chatId, rule.replyText);
      return;
    }
  }
  if (isGroup) {
    if (isExplicitMention) {
      await sendTelegramMessage(
        chatId,
        `\u{1F44B} Halo *${senderName}*! Saya Bot Intelligence siap digunakan di grup ini.

Gunakan perintah resmi:
\u2022 /menu - Menu Interaktif
\u2022 /id - Cek Chat ID Grup & Profil
\u2022 /osint - Status Server Intelijen
\u2022 \`search: <target> <apiKey>\` - Cari Data Intelijen
\u2022 /ping - Tes Kecepatan Bot`
      );
    }
    return;
  }
  const looksLikeQuery = !isGroup && rawText.length >= 3 && rawText.length <= 60 && !rawText.includes("\n") && !rawText.startsWith("/") && currentUser.personalQuota && currentUser.personalQuota > 0;
  if (looksLikeQuery) {
    botConfig.stats.commandsExecuted += 1;
    saveBotConfig();
    const norm = sanitizeAndNormalizeQuery(rawText);
    if (!norm.isValid) {
      await sendTelegramMessage(chatId, `\u26A0\uFE0F *Pencarian Ditolak:* ${norm.reason}`);
      return;
    }
    const queryTarget = norm.clean;
    recordSearchAndDetectSpike(chatId, senderName, queryTarget);
    const cost = botConfig.quotaConfig?.quotaCostPerSearch || 1;
    await sendTelegramChatAction(chatId, "typing");
    let localResult = null;
    const cacheKey = queryTarget.toLowerCase();
    const cached = hotSearchCache.get(cacheKey);
    if (cached && Date.now() - cached.cachedAt < SEARCH_CACHE_TTL_MS) {
      localResult = cached.result;
    } else {
      try {
        localResult = await smartSearchDatasets(queryTarget, 500);
        if (localResult) {
          hotSearchCache.set(cacheKey, { result: localResult, cachedAt: Date.now() });
          if (hotSearchCache.size > 250) {
            const firstK = hotSearchCache.keys().next().value;
            if (firstK) hotSearchCache.delete(firstK);
          }
        }
      } catch (e) {
        addLog("error", `Error scanning local datasets: ${e.message}`, chatId);
      }
    }
    if (localResult && localResult.totalMatches > 0) {
      currentUser.personalQuota = Math.max(0, currentUser.personalQuota - cost);
      syncUserApiKey(currentUser);
      botConfig.stats.osintSearchesCount = (botConfig.stats.osintSearchesCount || 0) + 1;
      saveBotConfig();
      const newRemaining = `${currentUser.personalQuota}x`;
      const totalMatches = localResult.totalMatches;
      const searchId = `srch_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
      if (!Array.isArray(botConfig.searchHistories)) {
        botConfig.searchHistories = [];
      }
      const historyItem = {
        id: searchId,
        chatId: Number(chatId),
        userName: senderName,
        usernameTag,
        target: queryTarget,
        apiKey: currentUser.personalApiKey || `usr_${from.id}`,
        totalMatches,
        timestamp: (/* @__PURE__ */ new Date()).toISOString(),
        formattedWib: wibTime.fullStr,
        rawResult: localResult.rawTextOutput
      };
      botConfig.searchHistories.unshift(historyItem);
      if (botConfig.searchHistories.length > 300) {
        botConfig.searchHistories = botConfig.searchHistories.slice(0, 300);
      }
      saveSearchItemToDisk(historyItem);
      saveBotConfig();
      const { messageText, replyMarkup } = formatOsintPresentation(
        queryTarget,
        currentUser.personalApiKey || `usr_${from.id}`,
        totalMatches,
        newRemaining,
        wibTime,
        localResult.rawTextOutput,
        searchId
      );
      await sendTelegramMessage(chatId, messageText, replyMarkup);
      return;
    } else {
      const notFoundCard = `\u2139\uFE0F *DATA TIDAK DITEMUKAN*
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
\u{1F3AF} *Target:* \`${queryTarget}\`
\u{1F4C1} *Sumber Data:* \`dataset.txt\` & Arsip Dataset Pintar
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
Sistem telah memindai seluruh file dataset aktif, namun data untuk target \`${queryTarget}\` belum ditemukan.

\u{1F6E1}\uFE0F *Status Kuota:*
Kuota Anda *TIDAK DIPOTONG* (Sisa kuota: *${currentUser.personalQuota}x*).

\u{1F4A1} *Format Pencarian Resmi:*
\`search: <target>\` atau \`/search <target>\``;
      await sendTelegramMessage(chatId, notFoundCard, {
        inline_keyboard: [
          [{ text: "\u{1F48E} Cek Saldo Kuota", callback_data: "cmd_my_quota" }],
          [{ text: "\u{1F3E0} Menu Utama", callback_data: "cmd_menu" }]
        ]
      });
      return;
    }
  }
  const defaultReply = `Halo *${senderName}*! Pesan kamu telah diterima oleh server bot.
Ketik /id untuk melihat Chat ID, ketik /osint untuk fitur intelijen, atau ketik /menu untuk membuka menu lengkap.`;
  await sendTelegramMessage(chatId, defaultReply, getMainInlineMenu(botConfig.osintConfig.enabled));
}
async function safeAnswerCallbackQuery(callbackQueryId, text, showAlert = false, timeoutMs = 8e3) {
  if (!botConfig.token || !callbackQueryId) return;
  try {
    const payload = { callback_query_id: callbackQueryId };
    if (text) {
      payload.text = text;
      payload.show_alert = showAlert;
    }
    await callTelegramApi(botConfig.token, "answerCallbackQuery", payload, timeoutMs);
  } catch (_err) {
  }
}
async function handleCallbackQuery(cbQuery, sourceBot) {
  if (!cbQuery || !cbQuery.message) return;
  const data = cbQuery.data;
  const message = cbQuery.message;
  const chatId = message.chat.id;
  const from = cbQuery.from;
  const senderName = [from.first_name, from.last_name].filter(Boolean).join(" ") || from.username || "Pengguna";
  const usernameTag = from.username ? `@${from.username}` : "-";
  addLog("callback", `Tombol ditekan: "${data}"`, chatId, `${senderName} (${usernameTag})`);
  const cbKey = `cb_${from.id}`;
  const nowCb = Date.now();
  const lastCb = lastUserActionTimestamp.get(cbKey) || 0;
  if (nowCb - lastCb < 1200) {
    safeAnswerCallbackQuery(cbQuery.id, "\u23F3 Mohon tunggu sebentar...", false, 4e3);
    return;
  }
  lastUserActionTimestamp.set(cbKey, nowCb);
  safeAnswerCallbackQuery(cbQuery.id);
  const wibTime = getFormattedWIB();
  const pricing = getPricingData(from.language_code);
  if (data === "verify_id") {
    const user = botConfig.activeUsers.find((u) => Number(u.chatId) === Number(chatId));
    if (user && user.isVerified) {
      const alreadyVerifiedCard = `\u2139\uFE0F *AKUN ANDA SUDAH TERVERIFIKASI RESMI!*
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
Halo, *${senderName}*! Akun Anda sebelumnya telah terverifikasi di sistem kami sejak:
\u{1F552} *${formatWibDate(user.verifiedAt || user.firstSeen)}*

\u{1F194} *Chat ID:* \`${chatId}\`
\u{1F48E} *Sisa Kuota Pribadi:* *${user.personalQuota || 0}x Pencarian*
\u{1F511} *API Key Pribadi:* \`${user.personalApiKey || `usr_${chatId}`}\`

\u{1F4A1} _Status akun Anda tetap aman dan tidak pernah direset. Anda dapat langsung menggunakan semua fitur bot atau mengklaim kuota gratis di bawah._`;
      await sendTelegramMessage(chatId, alreadyVerifiedCard, {
        inline_keyboard: [
          [{ text: "\u{1F381} Menu Klaim Kuota", callback_data: "cmd_claim_menu" }],
          [{ text: "\u{1F48E} Cek Kuota Saya", callback_data: "cmd_my_quota" }],
          [{ text: "\u{1F3E0} Buka Menu Utama", callback_data: "cmd_menu" }]
        ]
      });
      return;
    }
    if (user) {
      user.isVerified = true;
      user.verifiedAt = (/* @__PURE__ */ new Date()).toISOString();
      syncUserApiKey(user);
      saveBotConfig();
    }
    const verifiedCard = `\u2705 *AKUN BERHASIL TERVERIFIKASI RESMI!*
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
Terima kasih, *${senderName}*! Akun Telegram Anda telah terverifikasi secara resmi.

\u{1F194} *Chat ID:* \`${chatId}\`
\u{1F464} *Nama Lengkap:* ${senderName}
\u{1F3F7} *Username:* ${usernameTag}
\u{1F552} *Waktu Verifikasi:* ${wibTime.fullStr}
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
\u{1F381} *HADIAH SAMBUTAN PENGGUNA BARU:*
Sebagai pengguna terverifikasi, Anda berhak mengklaim *+5x Kuota Pencarian OSINT Gratis* (1x seumur hidup)!

\u{1F449} *Klik tombol di bawah untuk mengambil kuota gratis Anda:*`;
    await sendTelegramMessage(chatId, verifiedCard, {
      inline_keyboard: [
        [{ text: "\u{1F381} Ambil Kuota Pengguna Baru (+5x)", callback_data: "claim_new_user" }],
        [{ text: "\u{1F3E0} Buka Menu Utama", callback_data: "cmd_menu" }]
      ]
    });
    return;
  }
  if (data === "cmd_claim_menu") {
    await sendClaimQuotaDashboard(from.id, chatId, senderName);
    return;
  }
  if (data === "cmd_my_quota") {
    await sendUserQuotaStatus(from.id, chatId, senderName);
    return;
  }
  if (data === "cmd_referral" || data === "ref_dashboard") {
    await sendReferralDashboard(from.id, chatId, senderName);
    return;
  }
  if (data === "ref_withdraw_all") {
    await handleWithdrawReferralQuota(from.id, chatId, senderName, "all");
    return;
  }
  if (data === "ref_withdraw_1") {
    await handleWithdrawReferralQuota(from.id, chatId, senderName, 1);
    return;
  }
  if (data === "ref_withdraw_2") {
    await handleWithdrawReferralQuota(from.id, chatId, senderName, 2);
    return;
  }
  if (data === "ref_withdraw_5") {
    await handleWithdrawReferralQuota(from.id, chatId, senderName, 5);
    return;
  }
  if (data === "ref_withdraw_custom") {
    const user = botConfig.activeUsers.find((u) => Number(u.userId || u.chatId) === Number(from.id));
    const currentVault = user?.referralVaultBalance || 0;
    await sendTelegramMessage(
      chatId,
      `\u{1F522} *TARIK KUOTA TABUNGAN DENGAN JUMLAH KUSTOM*
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
\u{1F4BC} Saldo Tabungan Anda saat ini: *${currentVault}x Kuota*

\u{1F449} *Ketik perintah:* \`/tarik <jumlah>\`

*Contoh:*
\u2022 \`/tarik 1\` (Tarik 1 kuota)
\u2022 \`/tarik 3\` (Tarik 3 kuota)
\u2022 \`/tarik 10\` (Tarik 10 kuota)
\u2022 \`/tarik semua\` (Tarik seluruh saldo tabungan)

Kuota yang ditarik akan langsung masuk ke Saldo Kuota Pencarian Aktif Anda dan siap dipakai untuk perintah \`search:\`!`,
      {
        inline_keyboard: [
          [{ text: "\u{1F4B0} Tarik Semua Sekarang", callback_data: "ref_withdraw_all" }],
          [{ text: "\u{1F4BC} Kembali ke Dashboard Tabungan", callback_data: "cmd_referral" }]
        ]
      }
    );
    return;
  }
  if (data === "ref_share_info") {
    await sendReferralShareCard(from.id, chatId, senderName);
    return;
  }
  if (data === "ref_my_friends") {
    await sendReferralFriendsList(from.id, chatId, senderName);
    return;
  }
  if (data === "claim_new_user") {
    await handleClaimNewUserQuota(from.id, chatId, senderName);
    return;
  }
  if (data === "claim_daily") {
    await handleClaimDailyQuota(from.id, chatId, senderName);
    return;
  }
  if (data === "cmd_osint") {
    const isOsintOn = botConfig.osintConfig.enabled;
    if (!isOsintOn) {
      const offCard = `\u{1F534} *STATUS SERVER DATA OSINT: NONAKTIF (OFF)*
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
\u26A0\uFE0F *Mohon maaf, Server Data OSINT saat ini belum diaktifkan oleh Owner.*

Fitur pencarian intelijen tidak dapat digunakan selama server masih dalam keadaan nonaktif.

\u{1F4DE} *CARA MENGAKTIFKAN:*
Jika Anda ingin menggunakan fitur ini, Anda harus menghubungi Owner Bot untuk mengaktifkan data/server OSINT:
\u{1F464} *Owner Telegram:* @flood1233
_(Bebas mau chat ataupun call, asal tidak spam)_
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501`;
      await sendTelegramMessage(chatId, offCard, {
        inline_keyboard: [
          [{ text: "\u{1F4DE} Hubungi Owner @flood1233", url: "https://t.me/flood1233" }],
          [{ text: "\u{1F48E} Lihat Tarif Harga API Key", callback_data: "cmd_pricing" }],
          [{ text: "\u{1F3E0} Kembali ke Menu Utama", callback_data: "cmd_menu" }]
        ]
      });
    } else {
      const onCard = `\u{1F7E2} *STATUS SERVER DATA OSINT: AKTIF (ON)*
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
Server Data OSINT saat ini *SEDANG AKTIF* dan siap digunakan!

\u{1F4D6} *CARA MENGGUNAKAN OSINT:*
Kirim pesan dengan format:
\`search: <target> <apiKey>\`

*Contoh:* \`search: jokowi ppp\`

\u{1F50D} *CEK SISA KUOTA API KEY:*
Ketik: \`api <apiKey>\` (Contoh: \`api ppp\`)

\u{1F48E} *TARIF HARGA API KEY (${pricing.currency}):*
${pricing.formatted}

${pricing.note}

\u{1F6D2} *PEMBELIAN & TOP UP API KEY:*
\u{1F464} *Owner Telegram:* @flood1233
_(Bebas mau chat ataupun call, asal tidak spam)_
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501`;
      await sendTelegramMessage(chatId, onCard, {
        inline_keyboard: [
          [{ text: "\u{1F48E} Cek Kuota API Key", callback_data: "cmd_pricing" }],
          [{ text: "\u{1F4DE} Hubungi Owner @flood1233", url: "https://t.me/flood1233" }],
          [{ text: "\u{1F3E0} Kembali ke Menu Utama", callback_data: "cmd_menu" }]
        ]
      });
    }
    return;
  }
  if (data === "cmd_pricing") {
    const priceCard = `\u{1F48E} *DAFTAR HARGA API KEY & SEWA BOT TELEGRAM*
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
Mata Uang Terdeteksi: *${pricing.currency}*

\u{1F511} *1. PAKET API KEY OSINT:*
${pricing.formatted}

${pricing.note}

\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
\u{1F916} *2. SEWA BOT TELEGRAM PRIBADI (DEDICATED):*
\u2022 *Paket 1 Bulan:* *Rp 50.000* _(Dedicated Bot + Full OSINT)_
\u2022 *Paket 3 Bulan (VIP):* *Rp 125.000* _(Prioritas + Custom Menu + Unlimited Admin)_
\u2022 *Paket Lifetime:* *Rp 250.000* _(Sekali Bayar Aktif Selamanya)_

\u{1F4A1} _Bot sewa akan memakai username & profil Anda sendiri, berjalan 24/7 tanpa perlu sewa VPS pribadi._

\u{1F4DE} *Pemesanan & Top Up Langsung:* @flood1233
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501`;
    await sendTelegramMessage(chatId, priceCard, {
      inline_keyboard: [
        [{ text: "\u{1F916} Detail Paket Sewa Bot", callback_data: "cmd_rental_info" }],
        [{ text: "\u{1F4DE} Hubungi Owner @flood1233", url: "https://t.me/flood1233" }],
        [{ text: "\u{1F3E0} Menu Utama", callback_data: "cmd_menu" }]
      ]
    });
    return;
  }
  if (data === "cmd_rental_info") {
    const rentalCard = `\u{1F916} *LAYANAN SEWA BOT TELEGRAM PRIBADI (DEDICATED BOT)*
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
Mau punya bot intelijen OSINT canggih dengan nama, username, avatar, dan identitas komunitas Anda sendiri?

\u2728 *KEUNGGULAN SEWA BOT DEDICATED:*
\u2705 *Bot Telegram Milik Anda Sendiri* (Bebas tentukan username & profil di @BotFather)
\u2705 *Akses Penuh Database OSINT & NIK* 1 Juta+ arsip kebocoran data
\u2705 *Online 24/7 Always-ON* (Server hosting cepat tanpa perlu sewa VPS pribadi)
\u2705 *Sistem Kuota Gratis & Manajemen Tabungan Referral* otomatis
\u2705 *Bebas Atur Menu & Watermark* brand komunitas Anda
\u2705 *Fitur Keamanan Anti-Spam & Moderasi Grup* bawaan

\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
\u{1F48E} *PILIHAN PAKET SEWA BOT:*
1\uFE0F\u20E3 *PAKET STARTER (30 HARI / 1 BULAN)*
   \u2022 Harga: *Rp 50.000* ($3.50)
   \u2022 1 Dedicated Bot Aktif 24/7 Full Database OSINT

2\uFE0F\u20E3 *PAKET PRO VIP (90 HARI / 3 BULAN) [TERPOPULER!]*
   \u2022 Harga: *Rp 125.000* ($8.50)
   \u2022 Bebas pasang Watermark, Jalur Proxy Prioritas, Admin Unlimited

3\uFE0F\u20E3 *PAKET LIFETIME / PERMANEN (SEKALI BAYAR)*
   \u2022 Harga: *Rp 250.000* (Sekali Bayar Aktif Selamanya)
   \u2022 Tanpa biaya bulanan lagi + Update dataset otomatis

\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
\u{1F6D2} *CARA MEMESAN & AKTIVASI:*
1. Buat bot baru di @BotFather lalu salin token HTTP API Anda.
2. Kirimkan token dan bukti pemesanan ke Admin:
\u{1F464} *Owner Telegram:* @flood1233
_(Bebas mau chat ataupun call, asal tidak spam)_
3. Bot Anda langsung aktif dan online seketika!`;
    await sendTelegramMessage(chatId, rentalCard, {
      inline_keyboard: [
        [{ text: "\u{1F4DE} Pesan ke Owner @flood1233", url: "https://t.me/flood1233" }],
        [{ text: "\u{1F48E} Daftar Harga API Key", callback_data: "cmd_pricing" }],
        [{ text: "\u{1F3E0} Menu Utama", callback_data: "cmd_menu" }]
      ]
    });
    return;
  }
  if (data === "cmd_multibot_info" || data === "cmd_list_bots") {
    const bots = botConfig.multiBots || [];
    const listStr = bots.map((b, i) => {
      const u = b.botInfo?.username ? `@${b.botInfo.username}` : `ID: ${b.id}`;
      const st = b.isActive ? "\u{1F7E2} Online" : "\u{1F534} Paused";
      const notesStr = b.notes ? `
   \u2022 Info: ${b.notes}` : "";
      const rentedStr = b.rentedBy ? `
   \u2022 Penyewa: ${b.rentedBy}` : "";
      return `${i + 1}. *${b.botInfo?.first_name || "Bot"}* (${u})
   \u2022 Status: ${st} | ID: \`${b.id}\`${notesStr}${rentedStr}`;
    }).join("\n\n");
    const multiCard = `\u{1F310} *STATUS MULTI-BOT CLUSTER*
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
\u{1F451} *MASTER BOT:* @${currentBotInfo?.username || "Primary"} (${botConfig.isActive ? "\u{1F7E2} ONLINE" : "\u{1F534} OFFLINE"})

\u{1F916} *SECONDARY WORKER BOTS (${bots.length}):*
${listStr || "_Belum ada secondary bot. Owner dapat mengetik /addbot <token> untuk menambah._"}
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
\u{1F4A1} _Semua bot terhubung ke database OSINT, kuota, dan sistem referral yang sama._`;
    await sendTelegramMessage(chatId, multiCard, {
      inline_keyboard: [
        [{ text: "\u{1F916} Info Paket Sewa Bot", callback_data: "cmd_rental_info" }],
        [{ text: "\u{1F4DE} Hubungi Owner @flood1233", url: "https://t.me/flood1233" }],
        [{ text: "\u{1F3E0} Menu Utama", callback_data: "cmd_menu" }]
      ]
    });
    return;
  }
  if (data === "cmd_owner") {
    const ownerCard = `\u{1F4DE} *KONTAK RESMI OWNER & ADMIN BOT*
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
\u{1F464} *Username Telegram:* @flood1233
\u{1F4AC} *Layanan Resmi:*
\u2022 Mengaktifkan Server Data OSINT
\u2022 Pembelian & Top Up Kuota API Key
\u2022 Paket Hemat & Unlimited
\u2022 Bantuan Teknis Bot

\u{1F4A1} _Bebas mau dengan chat ataupun call, asal tidak spam!_
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501`;
    await sendTelegramMessage(chatId, ownerCard, {
      inline_keyboard: [
        [{ text: "\u{1F4DE} Buka Chat Owner @flood1233", url: "https://t.me/flood1233" }],
        [{ text: "\u{1F48E} Daftar Harga API Key", callback_data: "cmd_pricing" }],
        [{ text: "\u{1F3E0} Menu Utama", callback_data: "cmd_menu" }]
      ]
    });
    return;
  }
  if (data === "cmd_calc_info") {
    await sendTelegramMessage(
      chatId,
      `\u{1F9EE} *FITUR KALKULATOR CEPAT BOT*

Ketik perintah dengan format:
\`/calc <rumus>\`

*Contoh:* \`/calc 2500 * 4 + 1500\`
\u2022 Mendukung perkalian (*), pembagian (/), penambahan (+), pengurangan (-), dan pangkat (^).`
    );
    return;
  }
  if (data === "ax_on") {
    botConfig.osintConfig.enabled = true;
    botConfig.osintConfig.lastToggledAt = (/* @__PURE__ */ new Date()).toISOString();
    saveBotConfig();
    await sendTelegramMessage(chatId, `\u{1F7E2} *SERVER OSINT DIAKTIFKAN (ON)*

Menyiarkan ke seluruh pengguna...`);
    if (botConfig.osintConfig.notifyOnStatusChange) {
      broadcastOsintStatusChange(true).catch(console.error);
    }
    return;
  }
  if (data === "ax_off") {
    botConfig.osintConfig.enabled = false;
    botConfig.osintConfig.lastToggledAt = (/* @__PURE__ */ new Date()).toISOString();
    saveBotConfig();
    await sendTelegramMessage(chatId, `\u{1F534} *SERVER OSINT DINONAKTIFKAN (OFF)*

Menyiarkan ke seluruh pengguna...`);
    if (botConfig.osintConfig.notifyOnStatusChange) {
      broadcastOsintStatusChange(false).catch(console.error);
    }
    return;
  }
  if (data === "ax_keys") {
    const keys = botConfig.osintConfig.apiKeys;
    const listStr = keys.map((k, i) => `${i + 1}. \`${k.key}\` - ${k.tier === "unlimited" ? "Unlimited" : `${k.remainingQuota}x (+${k.bonusQuota} bonus)`} (Pakai: ${k.totalUsed}x)`).join("\n");
    await sendTelegramMessage(chatId, `\u{1F511} *DAFTAR API KEY (${keys.length}):*
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
${listStr || "Kosong"}`);
    return;
  }
  if (data === "ax_test") {
    try {
      const testTarget = `${botConfig.osintConfig.ngrokUrl.replace(/\/$/, "")}/api/v1/search?q=ping&apiKey=test`;
      const testRes = await fetch(testTarget, { method: "GET" });
      await sendTelegramMessage(chatId, `\u2705 *RESPON NGROK OK:* HTTP ${testRes.status}`);
    } catch (err) {
      await sendTelegramMessage(chatId, `\u274C *NGROK OFFLINE:* ${err.message}`);
    }
    return;
  }
  if (data === "ax_menus") {
    const menus = botConfig.customMenus || [];
    const listStr = menus.map((m, i) => `${i + 1}. *${m.label}* [ID: \`${m.id}\`] (${m.enabled ? "Aktif" : "Nonaktif"})`).join("\n");
    await sendTelegramMessage(chatId, `\u{1F5C2}\uFE0F *DAFTAR MENU KUSTOM TAMBAHAN:*
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
${listStr || "Belum ada menu kustom."}`);
    return;
  }
  if (data.startsWith("cmenu_")) {
    const menuId = data.replace("cmenu_", "");
    const matched = (botConfig.customMenus || []).find((m) => m.id === menuId);
    if (matched) {
      const reply = matched.responseText || `\u{1F4CC} *${matched.label}*`;
      await sendTelegramMessage(chatId, reply, {
        inline_keyboard: [
          [{ text: "\u{1F3E0} Kembali ke Menu Utama", callback_data: "cmd_menu" }]
        ]
      });
      return;
    }
  }
  if (data === "cmd_id") {
    const user = botConfig.activeUsers.find((u) => Number(u.chatId) === Number(chatId));
    const todayWib = getWibDateString();
    const countdown = getTimeUntilNextWibMidnight();
    const firstSeenFormatted = formatWibDate(user?.firstSeen);
    const idCard = `\u{1F4CB} *DETAIL INFORMASI CHAT ID & PROFIL AKUN*
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
\u{1F194} *Chat ID:* \`${chatId}\`
\u{1F464} *Nama Lengkap:* ${senderName}
\u{1F3F7} *Username:* ${usernameTag}
\u{1F4AC} *Tipe Obrolan:* ${message.chat.type.toUpperCase()}
\u{1F552} *Waktu Sistem:* ${wibTime.fullStr}
\u{1F512} *Status Akun:* ${user?.isVerified ? "\u2705 *Terverifikasi Resmi*" : "\u26A0\uFE0F *Belum Verifikasi*"} (Terdaftar sejak: ${firstSeenFormatted})
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
\u{1F48E} *STATUS KUOTA PRIBADI ANDA:*
\u2022 *Sisa Kuota Aktif:* *${user?.personalQuota || 0}x Pencarian*
\u2022 *API Key Pribadi:* \`${user?.personalApiKey || `usr_${chatId}`}\`

\u{1F381} *STATUS JATAH KLAIM:*
\u2022 *Kuota Pengguna Baru (5x):* ${user?.hasClaimedNewUserQuota ? "\u2705 Sudah Diklaim (1x seumur hidup)" : "\u{1F381} *Belum Diklaim (Siap Diambil)*"}
\u2022 *Kuota Harian (2x):* ${user?.dailyQuotaLastClaimedDate === todayWib ? `\u2705 Sudah Diklaim (Reset: ${countdown.formatted} lagi)` : "\u2728 *Tersedia Hari Ini (Bisa Diklaim)*"}
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
\u{1F6E1}\uFE0F _Data akun Anda tersimpan permanen & aman._`;
    await sendTelegramMessage(chatId, idCard, {
      inline_keyboard: [
        [
          { text: "\u{1F381} Menu Klaim Kuota", callback_data: "cmd_claim_menu" },
          { text: "\u{1F48E} Cek Saldo Kuota", callback_data: "cmd_my_quota" }
        ],
        [
          { text: "\u{1F504} Muat Ulang ID", callback_data: "cmd_id" },
          { text: "\u{1F3E0} Buka Menu Utama", callback_data: "cmd_menu" }
        ]
      ]
    });
    return;
  } else if (data === "cmd_bot") {
    const uptimeSec = botStartedAt ? Math.floor((Date.now() - botStartedAt) / 1e3) : 0;
    const botInfo = currentBotInfo;
    const botCard = `\u{1F916} *DETAIL & SPESIFIKASI RESMI AXXOSINTBOT*
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
\u{1F4DB} *Nama Bot:* ${botInfo?.first_name || "axxosintbot"}
\u{1F3F7} *Username:* @${botInfo?.username || "axxosintbot"}
\u{1F451} *Developer / Creator:* Ax. (@flood1233)
\u{1F522} *Bot ID:* \`${botInfo?.id || "N/A"}\`
\u{1F7E2} *Status:* AKTIF & STANDBY (Always-ON)
\u23F1 *Durasi Uptime:* ${formatUptime(uptimeSec)}
\u{1F50D} *Status OSINT:* ${botConfig.osintConfig.enabled ? "\u{1F7E2} AKTIF" : "\u{1F534} NONAKTIF"}
\u{1F465} *Izin Grup:* ${botInfo?.can_join_groups ? "Diizinkan" : "Dibatasi"}
\u{1F4D6} *Mode Baca Pesan:* ${botInfo?.can_read_all_group_messages ? "Aktif" : "Default"}
\u26A1 *Engine:* axxosintbot Core Engine v3.0 (Created by Ax.)
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501`;
    await sendTelegramMessage(chatId, botCard, {
      inline_keyboard: [
        [{ text: "\u{1F194} Cek ID Saya", callback_data: "cmd_id" }],
        [{ text: "\u{1F3E0} Menu Utama", callback_data: "cmd_menu" }]
      ]
    });
    return;
  } else if (data === "cmd_ping") {
    const uptimeSec = botStartedAt ? Math.floor((Date.now() - botStartedAt) / 1e3) : 0;
    await sendTelegramMessage(
      chatId,
      `\u{1F3D3} *PONG! Respon Kilat!*

\u2022 Server: Online
\u2022 Latency: ~30ms
\u2022 Uptime: ${formatUptime(uptimeSec)}
\u2022 Waktu: ${wibTime.timeStr}
\u2022 OSINT: ${botConfig.osintConfig.enabled ? "\u{1F7E2} ON" : "\u{1F534} OFF"}`
    );
    return;
  } else if (data === "cmd_waktu") {
    const now = /* @__PURE__ */ new Date();
    const wibStr = new Intl.DateTimeFormat("id-ID", { timeZone: "Asia/Jakarta", timeStyle: "medium", dateStyle: "full" }).format(now);
    await sendTelegramMessage(chatId, `\u23F0 *Waktu Indonesia Barat (WIB):*

${wibStr} WIB`);
    return;
  } else if (data === "cmd_help" || data === "cmd_menu") {
    const welcome = botConfig.welcomeMessage || DEFAULT_WELCOME_MESSAGE;
    await sendTelegramMessage(chatId, welcome, getMainInlineMenu(botConfig.osintConfig.enabled));
    return;
  }
  if (data.startsWith("dl_txt_")) {
    const searchId = data.replace("dl_txt_", "");
    const lockKey = `dl_${chatId}`;
    if (activeDownloads.has(lockKey)) {
      safeAnswerCallbackQuery(cbQuery.id, "\u23F3 Berkas sedang dikirim ke chat Anda, mohon tunggu sebentar...", false, 4e3);
      return;
    }
    activeDownloads.add(lockKey);
    try {
      const item = findSearchHistoryItem(searchId, chatId);
      if (!item) {
        await sendTelegramMessage(
          chatId,
          "\u26A0\uFE0F *Data pencarian ini tidak ditemukan atau sudah kadaluarsa.*\n\nData sesi pencarian telah diperbarui atau server baru direstart.\nSilakan lakukan pencarian ulang dengan format:\n`search: <target> <apiKey>`"
        );
        return;
      }
      await sendTelegramChatAction(chatId, "upload_document");
      const txtContent = generateTxtReport(item);
      const safeTarget = (item.target || "target").replace(/[^a-zA-Z0-9_-]/g, "_").substring(0, 30);
      const filename = `osint_${safeTarget}_${item.id || Date.now()}.txt`;
      await sendTelegramMessage(chatId, `\u23F3 *Menyiapkan & mengirim berkas .TXT lengkap (${item.totalMatches} Data - Target: ${item.target})...*`);
      const sent = await sendTelegramDocument(
        chatId,
        txtContent,
        filename,
        `\u{1F4C4} Berkas Lengkap OSINT: ${item.target}
\u2022 Total: ${item.totalMatches} Data
\u2022 API Key: ${item.apiKey}
\u2022 Waktu: ${item.formattedWib || "-"}`
      );
      if (!sent) {
        await sendTelegramMessage(
          chatId,
          `\u26A0\uFE0F *Gagal mengirim berkas dokumen ke Telegram.*
Koneksi jaringan Telegram sedang sibuk atau data terlalu besar. Anda dapat mencoba lagi atau melihat pratinjau di menu riwayat.`
        );
      }
    } finally {
      setTimeout(() => activeDownloads.delete(lockKey), 2500);
    }
    return;
  }
  if (data.startsWith("dl_json_")) {
    const searchId = data.replace("dl_json_", "");
    const lockKey = `dl_${chatId}`;
    if (activeDownloads.has(lockKey)) {
      safeAnswerCallbackQuery(cbQuery.id, "\u23F3 Berkas sedang dikirim ke chat Anda, mohon tunggu sebentar...", false, 4e3);
      return;
    }
    activeDownloads.add(lockKey);
    try {
      const item = findSearchHistoryItem(searchId, chatId);
      if (!item) {
        await sendTelegramMessage(
          chatId,
          "\u26A0\uFE0F *Data pencarian ini tidak ditemukan atau sudah kadaluarsa.*\n\nData sesi pencarian telah diperbarui atau server baru direstart.\nSilakan lakukan pencarian ulang dengan format:\n`search: <target> <apiKey>`"
        );
        return;
      }
      await sendTelegramChatAction(chatId, "upload_document");
      const safeTarget = (item.target || "target").replace(/[^a-zA-Z0-9_-]/g, "_").substring(0, 30);
      const filename = `osint_${safeTarget}_${item.id || Date.now()}.json`;
      await sendTelegramMessage(chatId, `\u23F3 *Menyiapkan & mengirim berkas .JSON lengkap (${item.totalMatches} Data - Target: ${item.target})...*`);
      const sent = await sendTelegramDocument(
        chatId,
        item.rawResult,
        filename,
        `\u{1F4E6} Berkas Raw JSON OSINT: ${item.target}
\u2022 Total: ${item.totalMatches} Data
\u2022 API Key: ${item.apiKey}
\u2022 Waktu: ${item.formattedWib || "-"}`
      );
      if (!sent) {
        await sendTelegramMessage(
          chatId,
          `\u26A0\uFE0F *Gagal mengirim berkas dokumen ke Telegram.*
Koneksi jaringan Telegram sedang sibuk. Anda dapat mencoba kembali beberapa saat lagi.`
        );
      }
    } finally {
      setTimeout(() => activeDownloads.delete(lockKey), 2500);
    }
    return;
  }
  if (data.startsWith("copy_all_")) {
    const searchId = data.replace("copy_all_", "");
    const item = findSearchHistoryItem(searchId, chatId);
    if (!item) {
      await sendTelegramMessage(chatId, "\u26A0\uFE0F Data pencarian ini tidak ditemukan atau sudah dibersihkan.");
      return;
    }
    const chunkSize = 3500;
    const fullText = item.rawResult || "";
    const totalChunks = Math.ceil(fullText.length / chunkSize);
    if (item.totalMatches > 50 || totalChunks > 3) {
      await sendTelegramMessage(
        chatId,
        `\u26A0\uFE0F *PERINGATAN UKURAN DATA BESAR (${item.totalMatches} Data / ${totalChunks} Bagian):*
Menampilkan ratusan baris data langsung ke chat dapat menyebabkan Telegram mobile Anda freeze, lag, atau terkena limit pesan.

\u{1F4E6} *Sangat disarankan langsung mengunduh berkas lengkap di bawah ini (100% utuh & lancar tanpa batas):*`,
        {
          inline_keyboard: [
            [{ text: "\u{1F4E5} Download File .TXT (Sangat Direkomendasikan)", callback_data: `dl_txt_${item.id}` }],
            [{ text: "\u{1F4E5} Download File .JSON", callback_data: `dl_json_${item.id}` }],
            [{ text: "\u{1F3E0} Menu Utama", callback_data: "cmd_menu" }]
          ]
        }
      );
      return;
    }
    for (let i = 0; i < totalChunks; i++) {
      const chunk = fullText.substring(i * chunkSize, (i + 1) * chunkSize);
      await sendTelegramMessage(
        chatId,
        `\u{1F4CB} *BAGIAN ${i + 1}/${totalChunks} (Target: ${item.target}) - Salin Teks Utuh:*
\`\`\`
${chunk}
\`\`\``
      );
    }
    return;
  }
  if (data === "user_history") {
    await handleUserHistoryCommand(Number(chatId), senderName);
    return;
  }
  if (data.startsWith("view_hist_")) {
    const searchId = data.replace("view_hist_", "");
    const item = findSearchHistoryItem(searchId, chatId);
    if (!item) {
      await sendTelegramMessage(chatId, "\u26A0\uFE0F Catatan riwayat ini tidak ditemukan atau sudah kadaluarsa.");
      return;
    }
    const { messageText, replyMarkup } = formatOsintPresentation(
      item.target,
      item.apiKey,
      item.totalMatches,
      "Sesuai Key",
      { fullStr: item.formattedWib },
      item.rawResult,
      item.id
    );
    await sendTelegramMessage(chatId, `\u{1F4C2} *Membuka Kembali Dari Riwayat Pribadi:*

` + messageText, replyMarkup);
    return;
  }
  if (data === "confirm_clear_my_hist") {
    await sendTelegramMessage(
      chatId,
      `\u26A0\uFE0F *KONFIRMASI PENGHAPUSAN RIWAYAT PRIBADI*
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
Apakah Anda yakin ingin menghapus seluruh riwayat pencarian OSINT untuk akun Chat ID \`${chatId}\`?

_Tindakan ini hanya menghapus riwayat milik Anda sendiri dan tidak mempengaruhi pengguna lain._`,
      {
        inline_keyboard: [
          [
            { text: "\u{1F5D1}\uFE0F Ya, Hapus Riwayat Saya", callback_data: "do_clear_my_hist" },
            { text: "\u274C Batal", callback_data: "user_history" }
          ]
        ]
      }
    );
    return;
  }
  if (data === "do_clear_my_hist") {
    if (Array.isArray(botConfig.searchHistories)) {
      const initialLen = botConfig.searchHistories.length;
      botConfig.searchHistories = botConfig.searchHistories.filter((h) => h.chatId !== Number(chatId));
      const deletedCount = initialLen - botConfig.searchHistories.length;
      saveBotConfig();
      await sendTelegramMessage(
        chatId,
        `\u2705 *BERHASIL DIHAPUS!*
Sebanyak *${deletedCount} catatan riwayat pencarian* milik Chat ID \`${chatId}\` telah dibersihkan.`,
        {
          inline_keyboard: [[{ text: "\u{1F3E0} Kembali ke Menu", callback_data: "cmd_menu" }]]
        }
      );
    }
    return;
  }
}
async function runTelegramPollingLoop() {
  if (isPollingRunning) return;
  isPollingRunning = true;
  pollingAbortController = new AbortController();
  console.log("[Telegram Polling] Starting continuous polling loop (ALWAYS ON)...");
  addLog("system", "Service polling Telegram dimulai. Bot status: AKTIF (Always-ON).");
  while (botConfig.isActive) {
    if (!botConfig.token) {
      lastError = "Token belum dikonfigurasi.";
      addLog("error", "Polling berhenti: Token Telegram belum diisi.");
      botConfig.isActive = false;
      saveBotConfig();
      break;
    }
    try {
      lastPollingTimestamp = (/* @__PURE__ */ new Date()).toISOString();
      const url = `https://api.telegram.org/bot${botConfig.token}/getUpdates?offset=${pollingOffset}&timeout=15&allowed_updates=["message","callback_query"]`;
      const response = await fetch(url, {
        signal: pollingAbortController?.signal
      });
      if (!botConfig.isActive) break;
      if (!response.ok) {
        const errorBody = await response.text();
        lastError = `Telegram API Error (${response.status}): ${errorBody}`;
        addLog("error", `Gagal polling Telegram API (${response.status}). Menunggu retry...`);
        await new Promise((resolve) => setTimeout(resolve, 4e3));
        continue;
      }
      const data = await response.json();
      if (!data.ok) {
        lastError = data.description || "Error getUpdates";
        addLog("error", `Telegram getUpdates Error: ${data.description}`);
        if (data.error_code === 401) {
          addLog("error", "Token bot tidak valid atau telah dicabut oleh BotFather! Mematikan polling otomatis.");
          botConfig.isActive = false;
          saveBotConfig();
          break;
        }
        await new Promise((resolve) => setTimeout(resolve, 5e3));
        continue;
      }
      lastError = null;
      const updates = data.result || [];
      for (const update of updates) {
        if (!botConfig.isActive) break;
        if (update.update_id >= pollingOffset) {
          pollingOffset = update.update_id + 1;
          botConfig.lastPollingOffset = pollingOffset;
        }
        if (processedUpdateIds.has(update.update_id)) {
          continue;
        }
        processedUpdateIds.add(update.update_id);
        if (processedUpdateIds.size > 1e3) {
          const first = processedUpdateIds.values().next().value;
          if (first !== void 0) processedUpdateIds.delete(first);
        }
        if (update.message) {
          await handleIncomingMessage(update.message);
        } else if (update.callback_query) {
          await handleCallbackQuery(update.callback_query);
        }
      }
    } catch (err) {
      if (err.name === "AbortError" || !botConfig.isActive) {
        console.log("[Telegram Polling] Polling aborted cleanly.");
        break;
      }
      lastError = err.message;
      addLog("error", `Koneksi polling terganggu: ${err.message}. Mencoba kembali dalam 3 detik...`);
      await new Promise((resolve) => setTimeout(resolve, 3e3));
    }
  }
  isPollingRunning = false;
  console.log("[Telegram Polling] Polling loop stopped.");
  addLog("system", "Service polling Telegram dinonaktifkan (Status: OFF).");
}
async function runSingleSecondaryBotWorker(botItem) {
  if (activeSecondaryBotWorkers.has(botItem.id)) {
    const existing = activeSecondaryBotWorkers.get(botItem.id);
    if (existing?.isRunning) return;
  }
  const abortController = new AbortController();
  const workerState = {
    abortController,
    isRunning: true,
    offset: 0
  };
  activeSecondaryBotWorkers.set(botItem.id, workerState);
  console.log(`[Multi-Bot Worker] Starting polling worker for @${botItem.botInfo?.username || botItem.id}...`);
  addLog("system", `Multi-Bot Worker dimulai untuk @${botItem.botInfo?.username || botItem.id} (Status: AKTIF).`);
  while (botItem.isActive && workerState.isRunning) {
    try {
      botItem.lastPollingAt = (/* @__PURE__ */ new Date()).toISOString();
      const url = `https://api.telegram.org/bot${botItem.token}/getUpdates?offset=${workerState.offset}&timeout=15&allowed_updates=["message","callback_query"]`;
      const response = await fetch(url, {
        signal: abortController.signal
      });
      if (!botItem.isActive || !workerState.isRunning) break;
      if (!response.ok) {
        const errorBody = await response.text();
        botItem.lastError = `HTTP ${response.status}: ${errorBody}`;
        await new Promise((resolve) => setTimeout(resolve, 4e3));
        continue;
      }
      const data = await response.json();
      if (!data.ok) {
        botItem.lastError = data.description || "Error getUpdates";
        if (data.error_code === 401) {
          botItem.isActive = false;
          saveBotConfig();
          break;
        }
        await new Promise((resolve) => setTimeout(resolve, 5e3));
        continue;
      }
      botItem.lastError = null;
      const updates = data.result || [];
      for (const update of updates) {
        if (!botItem.isActive || !workerState.isRunning) break;
        if (update.update_id >= workerState.offset) {
          workerState.offset = update.update_id + 1;
        }
        const dedupKey = `bot_${botItem.id}_${update.update_id}`;
        if (processedUpdateIds.has(dedupKey)) continue;
        processedUpdateIds.add(dedupKey);
        activeBotContextToken = botItem.token;
        activeBotContextInfo = botItem.botInfo;
        if (update.message) {
          if (!botItem.stats) botItem.stats = { messagesReceived: 0, messagesSent: 0, commandsExecuted: 0 };
          botItem.stats.messagesReceived += 1;
          await handleIncomingMessage(update.message, botItem);
        } else if (update.callback_query) {
          await handleCallbackQuery(update.callback_query, botItem);
        }
        activeBotContextToken = null;
        activeBotContextInfo = null;
      }
    } catch (err) {
      if (err.name === "AbortError" || !botItem.isActive || !workerState.isRunning) {
        break;
      }
      botItem.lastError = err.message;
      await new Promise((resolve) => setTimeout(resolve, 3e3));
    }
  }
  workerState.isRunning = false;
  activeSecondaryBotWorkers.delete(botItem.id);
  console.log(`[Multi-Bot Worker] Worker stopped for @${botItem.botInfo?.username || botItem.id}.`);
}
function stopSingleSecondaryBotWorker(botId) {
  const worker = activeSecondaryBotWorkers.get(botId);
  if (worker) {
    worker.isRunning = false;
    try {
      worker.abortController.abort();
    } catch {
    }
    activeSecondaryBotWorkers.delete(botId);
  }
}
function syncAllSecondaryBotWorkers() {
  if (!Array.isArray(botConfig.multiBots)) {
    botConfig.multiBots = [];
  }
  for (const bot of botConfig.multiBots) {
    if (bot.isActive) {
      runSingleSecondaryBotWorker(bot).catch((err) => {
        console.error(`[Multi-Bot Worker] Error on bot ${bot.id}:`, err);
      });
    } else {
      stopSingleSecondaryBotWorker(bot.id);
    }
  }
}
async function startBotEngine() {
  if (!botConfig.token) {
    return { success: false, message: "Token Telegram belum diisi. Silakan masukkan token terlebih dahulu." };
  }
  const validation = await verifyTelegramToken(botConfig.token);
  if (!validation.valid || !validation.botInfo) {
    lastError = validation.errorMessage || "Token tidak valid";
    return {
      success: false,
      message: `Token tidak valid: ${validation.errorMessage || "Unauthorized"}`
    };
  }
  currentBotInfo = validation.botInfo;
  botConfig.isActive = true;
  if (!botStartedAt) {
    botStartedAt = Date.now();
  }
  lastError = null;
  saveBotConfig();
  runTelegramPollingLoop().catch((err) => {
    console.error("[Telegram Polling] Unhandled loop error:", err);
  });
  syncAllSecondaryBotWorkers();
  return {
    success: true,
    message: `Bot @${validation.botInfo.username} berhasil diaktifkan dan akan selalu aktif!`,
    botInfo: validation.botInfo
  };
}
function stopBotEngine() {
  botConfig.isActive = false;
  botStartedAt = null;
  saveBotConfig();
  if (pollingAbortController) {
    try {
      pollingAbortController.abort();
    } catch (e) {
    }
    pollingAbortController = null;
  }
  return {
    success: true,
    message: "Bot Telegram telah dimatikan (Status: OFF)."
  };
}
loadBotConfig();
setTimeout(() => {
  if (botConfig.isActive) {
    syncAllSecondaryBotWorkers();
  }
}, 1e3);
async function startServer() {
  const app = (0, import_express.default)();
  const PORT = 3e3;
  app.use((req, res, next) => {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept, Authorization");
    if (req.method === "OPTIONS") {
      return res.sendStatus(200);
    }
    next();
  });
  app.use(import_express.default.json({ limit: "500mb" }));
  app.use(import_express.default.urlencoded({ limit: "500mb", extended: true }));
  app.get("/api/health", (req, res) => {
    res.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
    res.json({
      status: "ok",
      service: "Telegram Bot Automation Controller",
      botActive: botConfig.isActive,
      botUsername: currentBotInfo?.username || null,
      timestamp: (/* @__PURE__ */ new Date()).toISOString()
    });
  });
  app.get("/api/bot/status", async (req, res) => {
    try {
      const uptimeSec = botStartedAt && botConfig.isActive ? Math.floor((Date.now() - botStartedAt) / 1e3) : 0;
      const response = {
        isActive: Boolean(botConfig.isActive),
        token: botConfig.token || "",
        maskedToken: maskToken(botConfig.token),
        isTokenValid: Boolean(currentBotInfo),
        botInfo: currentBotInfo,
        lastError,
        uptimeSeconds: uptimeSec,
        startedAt: botStartedAt ? new Date(botStartedAt).toISOString() : null,
        stats: botConfig.stats || {
          messagesReceived: 0,
          messagesSent: 0,
          commandsExecuted: 0,
          activeUsersCount: 0
        },
        recentLogs: (recentLogs || []).slice(0, 80),
        activeUsers: botConfig.activeUsers || [],
        // FIX: Return all active users without 50 truncate limit!
        customCommands: botConfig.customCommands || [],
        autoReplies: botConfig.autoReplies || [],
        customMenus: botConfig.customMenus || [],
        welcomeMessage: botConfig.welcomeMessage || DEFAULT_WELCOME_MESSAGE,
        lastPollingAt: lastPollingTimestamp || void 0,
        osintConfig: botConfig.osintConfig,
        searchHistories: botConfig.searchHistories || [],
        githubSync: botConfig.githubSync || DEFAULT_GITHUB_SYNC,
        groupConfig: botConfig.groupConfig || DEFAULT_GROUP_CONFIG,
        quotaConfig: botConfig.quotaConfig || DEFAULT_QUOTA_CONFIG,
        menuConfig: botConfig.menuConfig || DEFAULT_MENU_CONFIG,
        moderationConfig: botConfig.moderationConfig || DEFAULT_MODERATION_CONFIG,
        spikeAlerts: recentSpikeAlerts,
        referralConfig: botConfig.referralConfig || DEFAULT_REFERRAL_CONFIG,
        referralAccounts: getAllReferralAccounts(),
        referralRecords: botConfig.referralRecords || [],
        referralWithdrawLogs: botConfig.referralWithdrawLogs || [],
        multiBots: botConfig.multiBots || [],
        rentalPlans: botConfig.rentalPlans || DEFAULT_RENTAL_PLANS,
        quotaPackages: botConfig.quotaPackages || DEFAULT_QUOTA_PACKAGES,
        messageLogs: (messageTrafficLogs || []).slice(0, 150),
        ownerWebsitePasskey: botConfig.ownerWebsitePasskey || "ax0895"
      };
      res.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
      return res.json(response);
    } catch (err) {
      console.error("Error in /api/bot/status handler:", err);
      return res.status(500).json({
        isActive: false,
        token: "",
        maskedToken: "",
        isTokenValid: false,
        botInfo: null,
        lastError: err?.message || "Internal status error",
        uptimeSeconds: 0,
        startedAt: null,
        stats: { messagesReceived: 0, messagesSent: 0, commandsExecuted: 0, activeUsersCount: 0 },
        recentLogs: [],
        activeUsers: [],
        customCommands: [],
        autoReplies: [],
        customMenus: [],
        welcomeMessage: "",
        osintConfig: DEFAULT_OSINT_CONFIG
      });
    }
  });
  app.get("/api/bot/spike-alerts", (req, res) => {
    res.json({
      success: true,
      alerts: recentSpikeAlerts,
      totalEventsLastMinute: recentSearchEvents.length
    });
  });
  app.delete("/api/bot/spike-alerts", (req, res) => {
    recentSpikeAlerts = [];
    res.json({
      success: true,
      message: "Riwayat alert lonjakan pencarian berhasil dibersihkan."
    });
  });
  app.post("/api/bot/verify-token", async (req, res) => {
    const { token = "" } = req.body;
    const result = await verifyTelegramToken(token);
    res.json(result);
  });
  app.post("/api/bot/update-token", async (req, res) => {
    const { token = "" } = req.body;
    const trimmed = (token || "").trim();
    if (!trimmed) {
      return res.status(400).json({
        success: false,
        message: "Token Telegram tidak boleh kosong."
      });
    }
    const validation = await verifyTelegramToken(trimmed);
    if (!validation.valid || !validation.botInfo) {
      return res.status(400).json({
        success: false,
        message: validation.errorMessage || "Token tidak valid menurut Telegram API.",
        details: validation
      });
    }
    const wasActive = botConfig.isActive;
    if (wasActive) {
      stopBotEngine();
    }
    botConfig.token = trimmed;
    currentBotInfo = validation.botInfo;
    saveBotConfig();
    addLog("system", `Token bot diperbarui ke @${validation.botInfo.username}`);
    if (wasActive) {
      await startBotEngine();
    }
    res.json({
      success: true,
      message: `Token berhasil disimpan! Terverifikasi milik @${validation.botInfo.username}.`,
      botInfo: validation.botInfo,
      latencyMs: validation.latencyMs
    });
  });
  app.post("/api/bot/toggle", async (req, res) => {
    const { active } = req.body;
    if (active) {
      const result = await startBotEngine();
      if (!result.success) {
        return res.status(400).json({
          success: false,
          message: result.message
        });
      }
      return res.json({
        success: true,
        isActive: true,
        message: result.message,
        botInfo: result.botInfo
      });
    } else {
      const result = stopBotEngine();
      return res.json({
        success: true,
        isActive: false,
        message: result.message
      });
    }
  });
  app.post("/api/bot/send-message", async (req, res) => {
    const { chatId, text, parseMode = "Markdown" } = req.body;
    if (!chatId || !text) {
      return res.status(400).json({
        success: false,
        message: "Chat ID dan pesan wajib diisi."
      });
    }
    if (!botConfig.token) {
      return res.status(400).json({
        success: false,
        message: "Bot token belum dikonfigurasi."
      });
    }
    try {
      const payload = {
        chat_id: chatId,
        text,
        parse_mode: parseMode
      };
      const response = await callTelegramApi(botConfig.token, "sendMessage", payload, 1e4);
      if (response && response.ok) {
        botConfig.stats.messagesSent += 1;
        saveBotConfig();
        addLog("outgoing", `[Direct Web] Pesan ke ${chatId}: "${text.substring(0, 60)}"`, chatId);
        return res.json({
          success: true,
          message: `Pesan berhasil terkirim ke Chat ID ${chatId}!`,
          result: response.result
        });
      } else {
        return res.status(400).json({
          success: false,
          message: `Telegram Error: ${response?.description || "Gagal mengirim pesan"}`
        });
      }
    } catch (err) {
      return res.status(500).json({
        success: false,
        message: `Terjadi kesalahan pengiriman: ${err.message}`
      });
    }
  });
  app.post("/api/bot/broadcast", async (req, res) => {
    const { text } = req.body;
    if (!text || !text.trim()) {
      return res.status(400).json({
        success: false,
        message: "Pesan broadcast tidak boleh kosong."
      });
    }
    if (!botConfig.token) {
      return res.status(400).json({
        success: false,
        message: "Bot token belum dikonfigurasi."
      });
    }
    const users = botConfig.activeUsers || [];
    if (users.length === 0) {
      return res.status(400).json({
        success: false,
        message: "Belum ada pengguna yang pernah berinteraksi dengan bot untuk dikirimkan broadcast."
      });
    }
    let successCount = 0;
    let failCount = 0;
    for (const u of users) {
      try {
        const payload = {
          chat_id: u.chatId,
          text: `\u{1F4E2} *PENGUMUMAN DARI CONTROLLER*

${text}`,
          parse_mode: "Markdown"
        };
        const response = await callTelegramApi(botConfig.token, "sendMessage", payload, 5e3);
        if (response && response.ok) {
          successCount++;
        } else {
          failCount++;
        }
      } catch {
        failCount++;
      }
      await new Promise((r) => setTimeout(r, 80));
    }
    botConfig.stats.messagesSent += successCount;
    saveBotConfig();
    addLog("outgoing", `Broadcast terkirim: ${successCount} berhasil, ${failCount} gagal.`);
    res.json({
      success: true,
      totalUsers: users.length,
      successCount,
      failCount,
      message: `Broadcast selesai: ${successCount} pengguna menerima pesan.`
    });
  });
  app.post("/api/bot/custom-commands", (req, res) => {
    const { customCommands } = req.body;
    if (!Array.isArray(customCommands)) {
      return res.status(400).json({ success: false, message: "Format custom commands harus berupa array." });
    }
    botConfig.customCommands = customCommands;
    saveBotConfig();
    addLog("system", `Daftar perintah kustom diperbarui (${customCommands.length} perintah).`);
    res.json({ success: true, customCommands: botConfig.customCommands });
  });
  app.post("/api/bot/auto-replies", (req, res) => {
    const { autoReplies } = req.body;
    if (!Array.isArray(autoReplies)) {
      return res.status(400).json({ success: false, message: "Format auto replies harus berupa array." });
    }
    botConfig.autoReplies = autoReplies;
    saveBotConfig();
    addLog("system", `Aturan balasan otomatis diperbarui (${autoReplies.length} aturan).`);
    res.json({ success: true, autoReplies: botConfig.autoReplies });
  });
  app.post("/api/bot/welcome-message", (req, res) => {
    const { welcomeMessage } = req.body;
    if (typeof welcomeMessage !== "string") {
      return res.status(400).json({ success: false, message: "Welcome message harus berupa teks string." });
    }
    botConfig.welcomeMessage = welcomeMessage;
    saveBotConfig();
    addLog("system", "Pesan selamat datang /start diperbarui.");
    res.json({ success: true, welcomeMessage: botConfig.welcomeMessage });
  });
  app.post("/api/bot/clear-logs", (req, res) => {
    recentLogs = [];
    addLog("system", "Log aktivitas dibersihkan.");
    res.json({ success: true });
  });
  app.post("/api/bot/reset-stats", (req, res) => {
    botConfig.stats = {
      messagesReceived: 0,
      messagesSent: 0,
      commandsExecuted: 0,
      activeUsersCount: botConfig.activeUsers.length,
      osintSearchesCount: 0
    };
    saveBotConfig();
    res.json({ success: true, stats: botConfig.stats });
  });
  app.post("/api/bot/osint/toggle", async (req, res) => {
    const { enabled, broadcast = true } = req.body;
    botConfig.osintConfig.enabled = Boolean(enabled);
    botConfig.osintConfig.lastToggledAt = (/* @__PURE__ */ new Date()).toISOString();
    saveBotConfig();
    addLog("system", `Status server OSINT diubah via Web Dashboard ke: ${botConfig.osintConfig.enabled ? "ON" : "OFF"}`);
    if (broadcast && botConfig.osintConfig.notifyOnStatusChange) {
      broadcastOsintStatusChange(botConfig.osintConfig.enabled).catch(console.error);
    }
    res.json({
      success: true,
      enabled: botConfig.osintConfig.enabled,
      osintConfig: botConfig.osintConfig,
      message: `Server OSINT berhasil ${botConfig.osintConfig.enabled ? "DIAKTIFKAN (ON)" : "DINONAKTIFKAN (OFF)"}.`
    });
  });
  app.post("/api/bot/osint/config", (req, res) => {
    const { ngrokUrl, ownerUsername, notifyOnStatusChange } = req.body;
    if (typeof ngrokUrl === "string" && ngrokUrl.trim()) {
      botConfig.osintConfig.ngrokUrl = ngrokUrl.trim();
    }
    if (typeof ownerUsername === "string" && ownerUsername.trim()) {
      botConfig.osintConfig.ownerUsername = ownerUsername.trim();
    }
    if (typeof notifyOnStatusChange === "boolean") {
      botConfig.osintConfig.notifyOnStatusChange = notifyOnStatusChange;
    }
    saveBotConfig();
    addLog("system", `Konfigurasi server OSINT diperbarui via Web.`);
    res.json({ success: true, osintConfig: botConfig.osintConfig, message: "Konfigurasi OSINT berhasil disimpan." });
  });
  app.post("/api/bot/osint/api-keys", (req, res) => {
    const { apiKeys } = req.body;
    if (!Array.isArray(apiKeys)) {
      return res.status(400).json({ success: false, message: "Format apiKeys harus array." });
    }
    botConfig.osintConfig.apiKeys = apiKeys;
    saveBotConfig();
    addLog("system", `Daftar API Key OSINT diperbarui via Web (${apiKeys.length} keys).`);
    res.json({ success: true, apiKeys: botConfig.osintConfig.apiKeys, message: "Daftar API Key berhasil disimpan." });
  });
  app.post("/api/bot/osint/test-ngrok", async (req, res) => {
    const { url } = req.body;
    const targetUrl = (url || botConfig.osintConfig.ngrokUrl).replace(/\/$/, "");
    const testEndpoint = `${targetUrl}/api/v1/search?q=ping&apiKey=test`;
    try {
      const start = Date.now();
      const testRes = await fetch(testEndpoint, {
        method: "GET",
        headers: { "User-Agent": "TelegramBotController/2.0" }
      });
      const latency = Date.now() - start;
      res.json({
        success: true,
        status: testRes.status,
        statusText: testRes.statusText,
        latencyMs: latency,
        message: `Koneksi ke Ngrok berhasil! (HTTP ${testRes.status} ${testRes.statusText})`
      });
    } catch (err) {
      res.json({
        success: false,
        message: `Gagal tersambung ke tunnel Ngrok: ${err.message}`
      });
    }
  });
  app.post("/api/bot/custom-menus", (req, res) => {
    const { customMenus } = req.body;
    if (!Array.isArray(customMenus)) {
      return res.status(400).json({ success: false, message: "Format customMenus harus array." });
    }
    botConfig.customMenus = customMenus;
    saveBotConfig();
    addLog("system", `Menu kustom Telegram diperbarui via Web (${customMenus.length} menu).`);
    res.json({ success: true, customMenus: botConfig.customMenus, message: "Menu kustom berhasil diperbarui." });
  });
  app.post("/api/bot/users/verify", (req, res) => {
    const { chatId, isVerified } = req.body;
    const user = botConfig.activeUsers.find((u) => Number(u.chatId) === Number(chatId));
    if (!user) {
      return res.status(404).json({ success: false, message: "Pengguna tidak ditemukan." });
    }
    user.isVerified = Boolean(isVerified);
    if (user.isVerified) {
      user.verifiedAt = (/* @__PURE__ */ new Date()).toISOString();
      syncUserApiKey(user);
    }
    saveBotConfig();
    addLog("system", `Status verifikasi pengguna ${chatId} (${user.firstName}) diubah ke: ${user.isVerified ? "Terverifikasi" : "Belum"}`);
    res.json({ success: true, user, message: `Status pengguna berhasil diperbarui.` });
  });
  app.post("/api/bot/users/quota", (req, res) => {
    const { chatId, personalQuota, hasClaimedNewUserQuota, resetDailyClaim } = req.body;
    const user = botConfig.activeUsers.find((u) => Number(u.chatId) === Number(chatId));
    if (!user) {
      return res.status(404).json({ success: false, message: "Pengguna tidak ditemukan." });
    }
    if (typeof personalQuota === "number") {
      user.personalQuota = Math.max(0, personalQuota);
    }
    if (typeof hasClaimedNewUserQuota === "boolean") {
      user.hasClaimedNewUserQuota = hasClaimedNewUserQuota;
    }
    if (resetDailyClaim) {
      user.dailyQuotaLastClaimedDate = void 0;
    }
    syncUserApiKey(user);
    saveBotConfig();
    addLog("system", `Kuota pengguna ${chatId} (${user.firstName}) diperbarui via Web: Sisa Kuota ${user.personalQuota}x`);
    res.json({ success: true, user, message: "Kuota pengguna berhasil disimpan." });
  });
  app.post("/api/bot/users/gift-quota", async (req, res) => {
    const { chatId, amount = 5, notifyUser = true, notes = "Hadiah dari Admin" } = req.body;
    const user = botConfig.activeUsers.find((u) => Number(u.chatId) === Number(chatId));
    if (!user) {
      return res.status(404).json({ success: false, message: "Pengguna tidak ditemukan." });
    }
    user.personalQuota = (user.personalQuota || 0) + Number(amount);
    syncUserApiKey(user);
    saveBotConfig();
    addLog("system", `Admin memberikan hadiah +${amount} kuota ke pengguna ${chatId} (${user.firstName}).`);
    if (notifyUser && botConfig.token) {
      const giftMessage = `\u{1F381} *ANDA MENDAPATKAN BONUS KUOTA DARI ADMIN!*
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
Halo *${user.firstName}*! Admin Web Controller baru saja menambahkan kuota ke akun Anda:

\u2795 *Bonus Kuota:* *+${amount}x Pencarian OSINT*
\u{1F48E} *Total Sisa Kuota Pribadi:* *${user.personalQuota}x Pemakaian*
\u{1F4DD} *Catatan:* ${notes}
\u{1F511} *API Key Anda:* \`${user.personalApiKey || `usr_${chatId}`}\`
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
\u{1F4A1} _Gunakan perintah \`search: <target>\` untuk mencari intelijen._`;
      try {
        await sendTelegramMessage(chatId, giftMessage, {
          inline_keyboard: [
            [{ text: "\u{1F48E} Cek Saldo Kuota", callback_data: "cmd_my_quota" }],
            [{ text: "\u{1F3E0} Menu Utama", callback_data: "cmd_menu" }]
          ]
        });
      } catch (e) {
        console.error("Failed to notify user of gifted quota:", e.message);
      }
    }
    res.json({
      success: true,
      user,
      message: `Berhasil menambahkan +${amount} kuota ke ${user.firstName} (${chatId}).`
    });
  });
  app.get("/api/bot/osint/history", (req, res) => {
    const { chatId } = req.query;
    let histories = botConfig.searchHistories || [];
    if (chatId) {
      histories = histories.filter((h) => h.chatId === Number(chatId));
    }
    res.json({
      success: true,
      total: histories.length,
      histories
    });
  });
  app.delete("/api/bot/osint/history/:id", (req, res) => {
    const { id } = req.params;
    const initialLen = (botConfig.searchHistories || []).length;
    botConfig.searchHistories = (botConfig.searchHistories || []).filter((h) => h.id !== id);
    const deletedCount = initialLen - botConfig.searchHistories.length;
    saveBotConfig();
    addLog("system", `Riwayat pencarian OSINT #${id} dihapus via Web.`);
    res.json({ success: true, deletedCount, message: "Riwayat pencarian berhasil dihapus." });
  });
  app.post("/api/bot/osint/history/clear", (req, res) => {
    const { chatId } = req.body;
    if (chatId) {
      botConfig.searchHistories = (botConfig.searchHistories || []).filter((h) => h.chatId !== Number(chatId));
      addLog("system", `Riwayat pencarian OSINT untuk Chat ID ${chatId} dibersihkan.`);
    } else {
      botConfig.searchHistories = [];
      addLog("system", `Seluruh riwayat pencarian OSINT dibersihkan via Web.`);
    }
    saveBotConfig();
    res.json({ success: true, message: "Riwayat pencarian berhasil dibersihkan." });
  });
  app.get("/api/bot/osint/download/:id", (req, res) => {
    const { id } = req.params;
    const format = (req.query.format || "txt").toLowerCase();
    const item = (botConfig.searchHistories || []).find((h) => h.id === id);
    if (!item) {
      return res.status(404).send("Data pencarian tidak ditemukan atau sudah dibersihkan.");
    }
    const sanitizedTarget = item.target.replace(/[^a-zA-Z0-9_-]/g, "_");
    if (format === "json") {
      res.setHeader("Content-Type", "application/json; charset=utf-8");
      res.setHeader("Content-Disposition", `attachment; filename="osint_${sanitizedTarget}_${item.id}.json"`);
      return res.send(item.rawResult);
    } else {
      const txtContent = generateTxtReport(item);
      res.setHeader("Content-Type", "text/plain; charset=utf-8");
      res.setHeader("Content-Disposition", `attachment; filename="osint_${sanitizedTarget}_${item.id}.txt"`);
      return res.send(txtContent);
    }
  });
  app.get("/api/datasets", async (req, res) => {
    try {
      const files = await getAllDatasetFiles();
      res.json({ success: true, files });
    } catch (err) {
      res.status(500).json({ success: false, message: `Gagal memuat daftar file: ${err.message}` });
    }
  });
  app.post("/api/datasets/upload", (req, res) => {
    datasetUpload.single("file")(req, res, async (err) => {
      if (err) {
        console.error("Multer upload error:", err);
        return res.status(400).json({ success: false, message: `Gagal upload: ${err.message}` });
      }
      try {
        if (!req.file) {
          return res.status(400).json({ success: false, message: "Tidak ada file yang diunggah." });
        }
        const setAsDefault = req.body.setAsDefault === "true" || req.body.setAsDefault === true;
        const uploadedPath = req.file.path;
        const originalName = import_path2.default.basename(req.file.originalname || "dataset.txt");
        if (setAsDefault || originalName.toLowerCase() === "dataset.txt") {
          import_fs2.default.copyFileSync(uploadedPath, DEFAULT_DATASET_FILE);
        }
        addLog("system", `File dataset diunggah: ${originalName} (${(req.file.size / 1024).toFixed(1)} KB)`);
        const files = await getAllDatasetFiles();
        res.json({
          success: true,
          message: `File ${originalName} berhasil diunggah! Sistem pintar otomatis siap menggunakannya untuk pencarian intelijen.`,
          file: req.file,
          files
        });
      } catch (uploadErr) {
        res.status(500).json({ success: false, message: `Gagal memproses file unggahan: ${uploadErr.message}` });
      }
    });
  });
  app.post("/api/datasets/create", async (req, res) => {
    try {
      const { filename, content } = req.body;
      if (!filename || typeof filename !== "string") {
        return res.status(400).json({ success: false, message: "Nama file wajib diisi." });
      }
      const baseName = sanitizeDatasetFilename(filename);
      await writeDatasetContent(baseName, content || "");
      addLog("system", `File dataset baru dibuat: ${baseName}`);
      const files = await getAllDatasetFiles();
      res.json({
        success: true,
        message: `File dataset ${baseName} berhasil dibuat dan siap dicari!`,
        files
      });
    } catch (err) {
      res.status(500).json({ success: false, message: `Gagal membuat file: ${err.message}` });
    }
  });
  app.get("/api/datasets/content", async (req, res) => {
    try {
      const filename = sanitizeDatasetFilename(req.query.filename || "dataset.txt");
      const maxLines = req.query.maxLines ? parseInt(req.query.maxLines, 10) : void 0;
      const data = await readDatasetContent(filename, maxLines);
      res.json({ success: true, ...data });
    } catch (err) {
      res.status(500).json({ success: false, message: `Gagal membaca isi file: ${err.message}` });
    }
  });
  app.put("/api/datasets/content", async (req, res) => {
    try {
      const { filename, content } = req.body;
      if (!filename || typeof filename !== "string") {
        return res.status(400).json({ success: false, message: "Nama file tidak valid." });
      }
      const baseName = sanitizeDatasetFilename(filename);
      await writeDatasetContent(baseName, content || "");
      addLog("system", `File dataset diperbarui: ${baseName}`);
      const files = await getAllDatasetFiles();
      res.json({
        success: true,
        message: `Perubahan pada ${baseName} berhasil disimpan!`,
        files
      });
    } catch (err) {
      res.status(500).json({ success: false, message: `Gagal menyimpan file: ${err.message}` });
    }
  });
  app.delete("/api/datasets/:filename", async (req, res) => {
    try {
      const rawParam = req.params.filename ? decodeURIComponent(req.params.filename) : "dataset.txt";
      const filename = sanitizeDatasetFilename(rawParam);
      const result = await deleteDatasetFile(filename);
      addLog("system", `File dataset dihapus/dibersihkan: ${filename}`);
      const files = await getAllDatasetFiles();
      res.json({
        success: true,
        message: result.message || `File ${filename} berhasil dihapus.`,
        files
      });
    } catch (err) {
      res.status(500).json({ success: false, message: `Gagal menghapus file: ${err.message}` });
    }
  });
  app.get("/api/datasets/download/:filename", (req, res) => {
    try {
      const rawParam = req.params.filename ? decodeURIComponent(req.params.filename) : "dataset.txt";
      const sanitized = sanitizeDatasetFilename(rawParam);
      const filePath = sanitized.toLowerCase() === "dataset.txt" ? DEFAULT_DATASET_FILE : import_path2.default.join(DATASETS_DIR, sanitized);
      if (!import_fs2.default.existsSync(filePath)) {
        return res.status(404).send("File dataset tidak ditemukan.");
      }
      res.setHeader("Content-Type", "text/plain; charset=utf-8");
      res.setHeader("Content-Disposition", `attachment; filename="${sanitized}"`);
      import_fs2.default.createReadStream(filePath).pipe(res);
    } catch (err) {
      res.status(500).send(`Gagal mendownload file: ${err.message}`);
    }
  });
  app.post("/api/datasets/search", async (req, res) => {
    try {
      const { query, limit } = req.body;
      if (!query || typeof query !== "string") {
        return res.status(400).json({ success: false, message: "Query target pencarian wajib diisi." });
      }
      const result = await smartSearchDatasets(query.trim(), limit ? parseInt(limit, 10) : 100);
      res.json({
        success: true,
        result
      });
    } catch (err) {
      res.status(500).json({ success: false, message: `Error saat memproses pencarian: ${err.message}` });
    }
  });
  app.post("/api/bot/osint/mode", (req, res) => {
    const { mode } = req.body;
    if (mode && ["smart_dataset", "hybrid", "ngrok_only"].includes(mode)) {
      botConfig.osintConfig.searchEngineMode = mode;
      saveBotConfig();
      addLog("system", `Mode mesin pencarian OSINT diubah ke: ${mode}`);
      res.json({ success: true, mode, message: `Mode pencarian berhasil diubah ke ${mode}` });
    } else {
      res.status(400).json({ success: false, message: "Mode tidak valid. Pilihan: smart_dataset, hybrid, ngrok_only." });
    }
  });
  app.get("/api/datasets/github/config", (req, res) => {
    res.json({
      success: true,
      config: botConfig.githubSync || DEFAULT_GITHUB_SYNC
    });
  });
  app.post("/api/datasets/github/config", (req, res) => {
    try {
      const incoming = req.body;
      botConfig.githubSync = {
        ...DEFAULT_GITHUB_SYNC,
        ...botConfig.githubSync || {},
        ...incoming
      };
      saveBotConfig();
      res.json({
        success: true,
        message: "Konfigurasi sinkronisasi GitHub berhasil disimpan.",
        config: botConfig.githubSync
      });
    } catch (err) {
      res.status(500).json({ success: false, message: `Gagal menyimpan konfigurasi: ${err.message}` });
    }
  });
  app.post("/api/datasets/github/test", async (req, res) => {
    try {
      const { url, githubToken } = req.body;
      const targetUrl = (url || botConfig.githubSync?.url || "").trim();
      if (!targetUrl) {
        return res.status(400).json({ success: false, message: "URL GitHub dataset wajib diisi." });
      }
      const testResult = await testGithubDataset(targetUrl, githubToken || botConfig.githubSync?.githubToken);
      if (!botConfig.githubSync) {
        botConfig.githubSync = { ...DEFAULT_GITHUB_SYNC };
      }
      botConfig.githubSync.url = targetUrl;
      botConfig.githubSync.rawUrl = testResult.rawUrl;
      botConfig.githubSync.lastTestedAt = (/* @__PURE__ */ new Date()).toISOString();
      botConfig.githubSync.lastTestStatus = testResult.success ? "success" : "error";
      botConfig.githubSync.lastTestMessage = testResult.message;
      botConfig.githubSync.lastTestSizeFormatted = testResult.sizeFormatted;
      botConfig.githubSync.lastTestLinesPreview = testResult.previewLines;
      saveBotConfig();
      addLog("system", `Uji koneksi dataset GitHub: ${testResult.success ? "BERHASIL" : "GAGAL"} (${targetUrl})`);
      res.json({
        success: testResult.success,
        result: testResult
      });
    } catch (err) {
      res.status(500).json({ success: false, message: `Gagal menguji GitHub dataset: ${err.message}` });
    }
  });
  app.post("/api/datasets/github/sync", async (req, res) => {
    try {
      const { url, targetFilename, replacePrimary, githubToken } = req.body;
      const syncUrl = (url || botConfig.githubSync?.url || "https://github.com/THEOYS123/track-call/blob/main/data/dataset.txt").trim();
      const filename = (targetFilename || botConfig.githubSync?.targetFilename || "dataset.txt").trim();
      const isPrimary = replacePrimary !== void 0 ? Boolean(replacePrimary) : botConfig.githubSync?.replacePrimary ?? true;
      const token = githubToken || botConfig.githubSync?.githubToken;
      addLog("system", `Memulai sinkronisasi dataset dari GitHub: ${syncUrl} -> ${filename}`);
      const syncResult = await syncGithubDataset(syncUrl, filename, isPrimary, token);
      if (!botConfig.githubSync) {
        botConfig.githubSync = { ...DEFAULT_GITHUB_SYNC };
      }
      botConfig.githubSync.url = syncUrl;
      botConfig.githubSync.targetFilename = filename;
      botConfig.githubSync.replacePrimary = isPrimary;
      botConfig.githubSync.lastSyncedAt = (/* @__PURE__ */ new Date()).toISOString();
      botConfig.githubSync.lastSyncStatus = "success";
      botConfig.githubSync.lastSyncMessage = syncResult.message;
      botConfig.githubSync.lastSyncedBytes = syncResult.downloadedBytes;
      saveBotConfig();
      addLog("system", `Sinkronisasi GitHub selesai: ${syncResult.message}`);
      const files = await getAllDatasetFiles();
      res.json({
        success: true,
        message: syncResult.message,
        fileInfo: syncResult.fileInfo,
        files,
        githubSync: botConfig.githubSync
      });
    } catch (err) {
      if (botConfig.githubSync) {
        botConfig.githubSync.lastSyncStatus = "error";
        botConfig.githubSync.lastSyncMessage = err.message;
        saveBotConfig();
      }
      addLog("error", `Gagal sinkronisasi dataset GitHub: ${err.message}`);
      res.status(500).json({ success: false, message: `Gagal sinkronisasi GitHub: ${err.message}` });
    }
  });
  app.get("/api/groups/config", (req, res) => {
    res.json({
      success: true,
      config: botConfig.groupConfig || DEFAULT_GROUP_CONFIG
    });
  });
  app.post("/api/groups/config", (req, res) => {
    try {
      const incoming = req.body;
      botConfig.groupConfig = {
        ...DEFAULT_GROUP_CONFIG,
        ...botConfig.groupConfig || {},
        ...incoming,
        knownGroups: Array.isArray(incoming.knownGroups) ? incoming.knownGroups : botConfig.groupConfig?.knownGroups || []
      };
      saveBotConfig();
      addLog("system", `Pengaturan grup Telegram & anti-spam diperbarui.`);
      res.json({
        success: true,
        message: "Pengaturan grup berhasil disimpan!",
        config: botConfig.groupConfig
      });
    } catch (err) {
      res.status(500).json({ success: false, message: `Gagal menyimpan konfigurasi grup: ${err.message}` });
    }
  });
  app.post("/api/groups/toggle", (req, res) => {
    try {
      const { setting, value } = req.body;
      if (!botConfig.groupConfig) {
        botConfig.groupConfig = { ...DEFAULT_GROUP_CONFIG };
      }
      if (setting in botConfig.groupConfig) {
        botConfig.groupConfig[setting] = Boolean(value);
        saveBotConfig();
        addLog("system", `Pengaturan grup ${setting} diubah menjadi: ${value}`);
        return res.json({ success: true, config: botConfig.groupConfig });
      }
      res.status(400).json({ success: false, message: "Setting tidak valid." });
    } catch (err) {
      res.status(500).json({ success: false, message: err.message });
    }
  });
  app.post("/api/groups/block", (req, res) => {
    try {
      const { groupId, blocked } = req.body;
      const numId = Number(groupId);
      if (!numId) {
        return res.status(400).json({ success: false, message: "Group ID tidak valid." });
      }
      if (!botConfig.groupConfig) {
        botConfig.groupConfig = { ...DEFAULT_GROUP_CONFIG };
      }
      if (!Array.isArray(botConfig.groupConfig.blockedGroupIds)) {
        botConfig.groupConfig.blockedGroupIds = [];
      }
      if (blocked) {
        if (!botConfig.groupConfig.blockedGroupIds.includes(numId)) {
          botConfig.groupConfig.blockedGroupIds.push(numId);
        }
      } else {
        botConfig.groupConfig.blockedGroupIds = botConfig.groupConfig.blockedGroupIds.filter((id) => id !== numId);
      }
      const matched = botConfig.groupConfig.knownGroups?.find((g) => g.id === numId);
      if (matched) {
        matched.status = blocked ? "blocked" : "active";
      }
      saveBotConfig();
      addLog("system", `Status blokir grup ID ${numId}: ${blocked ? "DIBLOKIR" : "DIIZINKAN"}`);
      res.json({
        success: true,
        message: `Grup ${numId} berhasil ${blocked ? "diblokir" : "diaktifkan kembali"}.`,
        config: botConfig.groupConfig
      });
    } catch (err) {
      res.status(500).json({ success: false, message: err.message });
    }
  });
  app.post("/api/groups/whitelist", (req, res) => {
    try {
      const { groupId, whitelist } = req.body;
      const numId = Number(groupId);
      if (!numId) {
        return res.status(400).json({ success: false, message: "Group ID tidak valid." });
      }
      if (!botConfig.groupConfig) {
        botConfig.groupConfig = { ...DEFAULT_GROUP_CONFIG };
      }
      if (!Array.isArray(botConfig.groupConfig.allowedGroupIds)) {
        botConfig.groupConfig.allowedGroupIds = [];
      }
      if (whitelist) {
        if (!botConfig.groupConfig.allowedGroupIds.includes(numId)) {
          botConfig.groupConfig.allowedGroupIds.push(numId);
        }
      } else {
        botConfig.groupConfig.allowedGroupIds = botConfig.groupConfig.allowedGroupIds.filter((id) => id !== numId);
      }
      saveBotConfig();
      addLog("system", `Whitelist grup ID ${numId}: ${whitelist ? "DITAMBAHKAN" : "DIHAPUS"}`);
      res.json({
        success: true,
        message: `Grup ${numId} ${whitelist ? "ditambahkan ke" : "dihapus dari"} whitelist.`,
        config: botConfig.groupConfig
      });
    } catch (err) {
      res.status(500).json({ success: false, message: err.message });
    }
  });
  app.delete("/api/groups/:groupId", (req, res) => {
    try {
      const numId = Number(req.params.groupId);
      if (botConfig.groupConfig && Array.isArray(botConfig.groupConfig.knownGroups)) {
        botConfig.groupConfig.knownGroups = botConfig.groupConfig.knownGroups.filter((g) => g.id !== numId);
        saveBotConfig();
      }
      res.json({ success: true, message: "Grup dihapus dari daftar.", config: botConfig.groupConfig });
    } catch (err) {
      res.status(500).json({ success: false, message: err.message });
    }
  });
  app.get("/api/bot/quota-config", (req, res) => {
    res.json({
      success: true,
      config: botConfig.quotaConfig || DEFAULT_QUOTA_CONFIG
    });
  });
  app.post("/api/bot/quota-config", (req, res) => {
    try {
      const incoming = req.body;
      botConfig.quotaConfig = {
        ...DEFAULT_QUOTA_CONFIG,
        ...botConfig.quotaConfig || {},
        ...incoming
      };
      saveBotConfig();
      addLog("system", `Konfigurasi kuota & klaim bot diperbarui.`);
      res.json({
        success: true,
        message: "Pengaturan kuota & klaim berhasil disimpan!",
        config: botConfig.quotaConfig
      });
    } catch (err) {
      res.status(500).json({ success: false, message: `Gagal menyimpan konfigurasi kuota: ${err.message}` });
    }
  });
  app.post("/api/bot/quota/reset-claims", (req, res) => {
    try {
      const { userId, resetNewUser, resetDaily } = req.body;
      const numId = Number(userId);
      const user = botConfig.activeUsers.find(
        (u) => u.userId && Number(u.userId) === numId || Number(u.chatId) === numId
      );
      if (!user) {
        return res.status(404).json({ success: false, message: "Pengguna tidak ditemukan." });
      }
      if (resetNewUser) {
        user.hasClaimedNewUserQuota = false;
        user.newUserQuotaClaimedAt = void 0;
      }
      if (resetDaily) {
        user.dailyQuotaLastClaimedDate = void 0;
        user.dailyQuotaLastClaimedAt = void 0;
      }
      saveBotConfig();
      addLog("system", `Status klaim kuota pengguna ${numId} direset oleh Admin.`);
      res.json({ success: true, message: `Status klaim untuk ${user.firstName} berhasil direset.`, user });
    } catch (err) {
      res.status(500).json({ success: false, message: err.message });
    }
  });
  app.get("/api/bot/menu-config", (req, res) => {
    res.json({
      success: true,
      config: botConfig.menuConfig || DEFAULT_MENU_CONFIG
    });
  });
  app.post("/api/bot/menu-config", (req, res) => {
    try {
      const incoming = req.body;
      botConfig.menuConfig = {
        ...DEFAULT_MENU_CONFIG,
        ...botConfig.menuConfig || {},
        ...incoming,
        customButtons: Array.isArray(incoming.customButtons) ? incoming.customButtons : botConfig.menuConfig?.customButtons || []
      };
      saveBotConfig();
      addLog("system", `Konfigurasi tampilan menu bot diperbarui.`);
      res.json({
        success: true,
        message: "Pengaturan menu bot berhasil disimpan!",
        config: botConfig.menuConfig
      });
    } catch (err) {
      res.status(500).json({ success: false, message: `Gagal menyimpan konfigurasi menu: ${err.message}` });
    }
  });
  app.get("/api/moderation/config", (req, res) => {
    res.json({
      success: true,
      config: botConfig.moderationConfig || DEFAULT_MODERATION_CONFIG
    });
  });
  app.post("/api/moderation/config", (req, res) => {
    try {
      const incoming = req.body;
      botConfig.moderationConfig = {
        ...DEFAULT_MODERATION_CONFIG,
        ...botConfig.moderationConfig || {},
        ...incoming,
        cyberWhitelistKeywords: Array.isArray(incoming.cyberWhitelistKeywords) ? incoming.cyberWhitelistKeywords : botConfig.moderationConfig?.cyberWhitelistKeywords || DEFAULT_MODERATION_CONFIG.cyberWhitelistKeywords,
        customBannedKeywords: Array.isArray(incoming.customBannedKeywords) ? incoming.customBannedKeywords : botConfig.moderationConfig?.customBannedKeywords || [],
        whitelistKeywords: Array.isArray(incoming.whitelistKeywords) ? incoming.whitelistKeywords : botConfig.moderationConfig?.whitelistKeywords || [],
        recentIncidents: Array.isArray(botConfig.moderationConfig?.recentIncidents) ? botConfig.moderationConfig.recentIncidents : []
      };
      saveBotConfig();
      addLog("system", `Pengaturan sistem moderasi konten & auto-delete diperbarui.`);
      res.json({
        success: true,
        message: "Pengaturan moderasi & auto-delete berhasil disimpan!",
        config: botConfig.moderationConfig
      });
    } catch (err) {
      res.status(500).json({ success: false, message: `Gagal menyimpan konfigurasi moderasi: ${err.message}` });
    }
  });
  app.post("/api/moderation/test", (req, res) => {
    try {
      const { text } = req.body;
      if (!text || typeof text !== "string") {
        return res.status(400).json({ success: false, message: "Teks pesan uji coba wajib diisi." });
      }
      const result = checkMessageModeration(text);
      res.json({
        success: true,
        text,
        result
      });
    } catch (err) {
      res.status(500).json({ success: false, message: err.message });
    }
  });
  app.post("/api/moderation/clear-incidents", (req, res) => {
    try {
      if (botConfig.moderationConfig) {
        botConfig.moderationConfig.recentIncidents = [];
        saveBotConfig();
      }
      res.json({
        success: true,
        message: "Riwayat insiden pesan terlarang berhasil dibersihkan."
      });
    } catch (err) {
      res.status(500).json({ success: false, message: err.message });
    }
  });
  app.get("/api/bot/referral/data", (req, res) => {
    try {
      const accounts = getAllReferralAccounts();
      res.json({
        success: true,
        config: botConfig.referralConfig || DEFAULT_REFERRAL_CONFIG,
        accounts,
        records: botConfig.referralRecords || [],
        withdrawLogs: botConfig.referralWithdrawLogs || []
      });
    } catch (err) {
      res.status(500).json({ success: false, message: `Gagal memuat data referral: ${err.message}` });
    }
  });
  app.post("/api/bot/referral/config", (req, res) => {
    try {
      const { enabled, quotaPerInvite, allowInstantWithdraw, minWithdrawAmount, notifyInviterOnRegister } = req.body;
      const current = botConfig.referralConfig || DEFAULT_REFERRAL_CONFIG;
      botConfig.referralConfig = {
        enabled: typeof enabled === "boolean" ? enabled : current.enabled,
        quotaPerInvite: typeof quotaPerInvite === "number" ? Math.max(1, quotaPerInvite) : current.quotaPerInvite,
        allowInstantWithdraw: typeof allowInstantWithdraw === "boolean" ? allowInstantWithdraw : current.allowInstantWithdraw,
        minWithdrawAmount: typeof minWithdrawAmount === "number" ? Math.max(1, minWithdrawAmount) : current.minWithdrawAmount,
        notifyInviterOnRegister: typeof notifyInviterOnRegister === "boolean" ? notifyInviterOnRegister : current.notifyInviterOnRegister
      };
      saveReferralData();
      saveBotConfig();
      addLog("system", `Konfigurasi sistem referral & tabungan kuota diperbarui via Web.`);
      res.json({
        success: true,
        config: botConfig.referralConfig,
        message: "Pengaturan program referral berhasil disimpan!"
      });
    } catch (err) {
      res.status(500).json({ success: false, message: `Gagal menyimpan konfigurasi: ${err.message}` });
    }
  });
  app.post("/api/bot/referral/adjust-vault", async (req, res) => {
    try {
      const { userId, amount = 1, actionType = "add_savings", notifyUser = true } = req.body;
      const numericUserId = Number(userId);
      const user = botConfig.activeUsers.find((u) => Number(u.userId || u.chatId) === numericUserId);
      if (!user) {
        return res.status(404).json({ success: false, message: "Pengguna tidak ditemukan." });
      }
      const numAmount = Math.max(1, Number(amount) || 1);
      const prevVault = user.referralVaultBalance || 0;
      if (actionType === "add_savings") {
        user.referralVaultBalance = prevVault + numAmount;
        saveBotConfig();
        saveReferralData();
        addLog("system", `Admin menambahkan +${numAmount} kuota ke Tabungan ${user.firstName} (ID: ${numericUserId}). Total tabungan: ${user.referralVaultBalance}x`);
        if (notifyUser && botConfig.token) {
          const wibTime = getFormattedWIB();
          const notifyMsg = `\u{1F381} *ADMIN MENAMBAHKAN KUOTA KE TABUNGAN ANDA!*
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
Halo *${user.firstName}*! Admin Web Controller baru saja menambahkan saldo ke Tabungan Kuota Anda:

\u2795 *Tambahan Saldo:* *+${numAmount}x Kuota*
\u{1F4BC} *Total Saldo Tabungan Anda:* *${user.referralVaultBalance}x Kuota*
\u{1F552} *Waktu:* ${wibTime.fullStr}
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
\u{1F4A1} _Ketik /tabungan atau /tarik untuk mencairkan saldo tabungan ke kuota pencarian aktif Anda._`;
          sendTelegramMessage(user.chatId || numericUserId, notifyMsg, {
            inline_keyboard: [
              [{ text: "\u{1F4BC} Buka Tabungan Kuota", callback_data: "cmd_referral" }],
              [{ text: "\u{1F4B0} Tarik Semua Kuota", callback_data: "ref_withdraw_all" }]
            ]
          }).catch(() => {
          });
        }
        return res.json({
          success: true,
          user,
          message: `Berhasil menambahkan +${numAmount} kuota ke tabungan ${user.firstName}.`
        });
      } else if (actionType === "withdraw_to_quota") {
        if (numAmount > prevVault) {
          return res.status(400).json({ success: false, message: `Saldo tabungan pengguna (${prevVault}x) tidak mencukupi untuk menarik ${numAmount}x kuota.` });
        }
        user.referralVaultBalance = prevVault - numAmount;
        user.personalQuota = (user.personalQuota || 0) + numAmount;
        user.totalReferralQuotaClaimed = (user.totalReferralQuotaClaimed || 0) + numAmount;
        syncUserApiKey(user);
        saveBotConfig();
        saveReferralData();
        addLog("system", `Admin mencairkan ${numAmount}x kuota tabungan milik ${user.firstName} (ID: ${numericUserId}) ke kuota aktif.`);
        if (notifyUser && botConfig.token) {
          const wibTime = getFormattedWIB();
          const notifyMsg = `\u{1F4B0} *TABUNGAN KUOTA TELAH DICAIRKAN OLEH ADMIN!*
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
Halo *${user.firstName}*! Kuota tabungan Anda berhasil dicairkan ke Saldo Kuota Aktif:

\u{1F4B0} *Kuota Ditarik:* *+${numAmount}x Kuota*
\u{1F4BC} *Sisa Tabungan:* *${user.referralVaultBalance}x Kuota*
\u{1F48E} *Saldo Kuota Pencarian Aktif Baru:* *${user.personalQuota}x Pencarian*
\u{1F552} *Waktu:* ${wibTime.fullStr}
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
\u{1F4A1} _Anda dapat langsung mencari intelijen dengan format: \`search: <target>\`_`;
          sendTelegramMessage(user.chatId || numericUserId, notifyMsg, {
            inline_keyboard: [
              [{ text: "\u{1F48E} Cek Kuota Saya", callback_data: "cmd_my_quota" }],
              [{ text: "\u{1F3E0} Menu Utama", callback_data: "cmd_menu" }]
            ]
          }).catch(() => {
          });
        }
        return res.json({
          success: true,
          user,
          message: `Berhasil mencairkan ${numAmount} kuota tabungan ke kuota aktif ${user.firstName}.`
        });
      }
    } catch (err) {
      res.status(500).json({ success: false, message: `Error adjust vault: ${err.message}` });
    }
  });
  app.post("/api/bot/referral/reset-user", (req, res) => {
    try {
      const { userId } = req.body;
      const numericUserId = Number(userId);
      const user = botConfig.activeUsers.find((u) => Number(u.userId || u.chatId) === numericUserId);
      if (user) {
        user.referralVaultBalance = 0;
        user.totalReferralsCount = 0;
        user.totalReferralQuotaClaimed = 0;
      }
      botConfig.referralRecords = (botConfig.referralRecords || []).filter((r) => Number(r.inviterUserId) !== numericUserId);
      saveReferralData();
      saveBotConfig();
      addLog("system", `Data referral & tabungan kuota user ${numericUserId} direset via Web.`);
      res.json({
        success: true,
        message: `Data referral user ${numericUserId} berhasil direset.`
      });
    } catch (err) {
      res.status(500).json({ success: false, message: `Gagal reset: ${err.message}` });
    }
  });
  app.get("/api/multibot/list", (req, res) => {
    try {
      res.json({
        success: true,
        primaryBot: {
          token: botConfig.token ? maskToken(botConfig.token) : "",
          isActive: botConfig.isActive,
          botInfo: currentBotInfo,
          isPrimary: true
        },
        multiBots: botConfig.multiBots || [],
        rentalPlans: botConfig.rentalPlans || DEFAULT_RENTAL_PLANS
      });
    } catch (err) {
      res.status(500).json({ success: false, message: err.message });
    }
  });
  app.post("/api/multibot/add", async (req, res) => {
    try {
      const { token, notes, rentedBy, rentExpiryDate } = req.body;
      const trimmedToken = (token || "").trim();
      if (!trimmedToken) {
        return res.status(400).json({ success: false, message: "Token Telegram wajib diisi." });
      }
      if (trimmedToken === botConfig.token) {
        return res.status(400).json({ success: false, message: "Token ini sudah digunakan sebagai Master Bot." });
      }
      const val = await verifyTelegramToken(trimmedToken);
      if (!val.valid || !val.botInfo) {
        return res.status(400).json({
          success: false,
          message: val.errorMessage || "Token tidak valid menurut Telegram API."
        });
      }
      const botId = `bot_${val.botInfo.id}`;
      const normalizedExpiry = parseRentExpiryInput(rentExpiryDate);
      const newBot = {
        id: botId,
        token: trimmedToken,
        maskedToken: maskToken(trimmedToken),
        isActive: true,
        botInfo: val.botInfo,
        addedAt: (/* @__PURE__ */ new Date()).toISOString(),
        startedAt: (/* @__PURE__ */ new Date()).toISOString(),
        latencyMs: val.latencyMs,
        notes: (notes || "").trim() || void 0,
        rentedBy: (rentedBy || "").trim() || void 0,
        rentExpiryDate: normalizedExpiry,
        stats: { messagesReceived: 0, messagesSent: 0, commandsExecuted: 0 }
      };
      if (!Array.isArray(botConfig.multiBots)) {
        botConfig.multiBots = [];
      }
      botConfig.multiBots = botConfig.multiBots.filter((b) => b.token !== trimmedToken && b.id !== botId);
      botConfig.multiBots.unshift(newBot);
      saveBotConfig();
      runSingleSecondaryBotWorker(newBot).catch((err) => {
        console.error(`[Multi-Bot Worker] Startup error for ${botId}:`, err);
      });
      addLog("system", `Bot baru ditambahkan ke Cluster: @${val.botInfo.username} (${notes || "Secondary Bot"})`);
      res.json({
        success: true,
        bot: newBot,
        multiBots: botConfig.multiBots,
        message: `Bot @${val.botInfo.username} berhasil disambungkan ke cluster dan langsung online!`
      });
    } catch (err) {
      res.status(500).json({ success: false, message: `Gagal menambahkan bot: ${err.message}` });
    }
  });
  app.post("/api/multibot/toggle", async (req, res) => {
    try {
      const { botId, active } = req.body;
      if (!botId) {
        return res.status(400).json({ success: false, message: "ID Bot wajib diisi." });
      }
      const bot = (botConfig.multiBots || []).find((b) => b.id === botId);
      if (!bot) {
        return res.status(404).json({ success: false, message: "Bot tidak ditemukan di cluster." });
      }
      bot.isActive = Boolean(active);
      saveBotConfig();
      if (bot.isActive) {
        runSingleSecondaryBotWorker(bot).catch(console.error);
        addLog("system", `Multi-Bot @${bot.botInfo?.username || bot.id} diaktifkan.`);
      } else {
        stopSingleSecondaryBotWorker(bot.id);
        addLog("system", `Multi-Bot @${bot.botInfo?.username || bot.id} dipause.`);
      }
      res.json({
        success: true,
        bot,
        multiBots: botConfig.multiBots,
        message: `Bot @${bot.botInfo?.username || bot.id} berhasil ${bot.isActive ? "diaktifkan" : "dipause"}.`
      });
    } catch (err) {
      res.status(500).json({ success: false, message: err.message });
    }
  });
  app.post("/api/multibot/update", async (req, res) => {
    try {
      const { botId, token, notes, rentedBy, rentExpiryDate, isActive } = req.body;
      if (!botId) {
        return res.status(400).json({ success: false, message: "ID Bot wajib diisi." });
      }
      if (!Array.isArray(botConfig.multiBots)) {
        botConfig.multiBots = [];
      }
      const bot = botConfig.multiBots.find((b) => b.id === botId);
      if (!bot) {
        return res.status(404).json({ success: false, message: "Bot tidak ditemukan di cluster." });
      }
      const trimmedToken = (token || "").trim();
      let tokenChanged = false;
      if (trimmedToken && trimmedToken !== bot.token) {
        tokenChanged = true;
        const val = await verifyTelegramToken(trimmedToken);
        if (!val.valid || !val.botInfo) {
          return res.status(400).json({
            success: false,
            message: val.errorMessage || "Token baru tidak valid menurut Telegram API."
          });
        }
        bot.token = trimmedToken;
        bot.maskedToken = maskToken(trimmedToken);
        bot.botInfo = val.botInfo;
        bot.latencyMs = val.latencyMs;
      }
      if (notes !== void 0) bot.notes = (notes || "").trim() || void 0;
      if (rentedBy !== void 0) bot.rentedBy = (rentedBy || "").trim() || void 0;
      if (rentExpiryDate !== void 0) bot.rentExpiryDate = parseRentExpiryInput(rentExpiryDate);
      if (isActive !== void 0) bot.isActive = Boolean(isActive);
      saveBotConfig();
      if (tokenChanged || bot.isActive) {
        stopSingleSecondaryBotWorker(bot.id);
        if (bot.isActive) {
          runSingleSecondaryBotWorker(bot).catch(console.error);
        }
      } else if (!bot.isActive) {
        stopSingleSecondaryBotWorker(bot.id);
      }
      addLog("system", `Pengaturan Multi-Bot @${bot.botInfo?.username || bot.id} berhasil diperbarui.`);
      res.json({
        success: true,
        bot,
        multiBots: botConfig.multiBots,
        message: `Pengaturan bot @${bot.botInfo?.username || bot.id} berhasil diperbarui!`
      });
    } catch (err) {
      res.status(500).json({ success: false, message: `Gagal memperbarui bot: ${err.message}` });
    }
  });
  app.post("/api/multibot/delete", (req, res) => {
    try {
      const { botId } = req.body;
      if (!botId) {
        return res.status(400).json({ success: false, message: "ID Bot wajib diisi." });
      }
      stopSingleSecondaryBotWorker(botId);
      const initialCount = (botConfig.multiBots || []).length;
      botConfig.multiBots = (botConfig.multiBots || []).filter((b) => b.id !== botId);
      saveBotConfig();
      addLog("system", `Bot #${botId} dihapus dari cluster.`);
      res.json({
        success: true,
        deleted: initialCount > (botConfig.multiBots || []).length,
        multiBots: botConfig.multiBots,
        message: "Bot berhasil dihapus dari cluster."
      });
    } catch (err) {
      res.status(500).json({ success: false, message: err.message });
    }
  });
  app.post("/api/multibot/test-ping", async (req, res) => {
    try {
      const { botId } = req.body;
      const bot = (botConfig.multiBots || []).find((b) => b.id === botId);
      const token = bot ? bot.token : botId;
      if (!token) {
        return res.status(400).json({ success: false, message: "Bot token tidak ditemukan." });
      }
      const val = await verifyTelegramToken(token);
      if (bot && val.latencyMs !== void 0) {
        bot.latencyMs = val.latencyMs;
        saveBotConfig();
      }
      res.json({
        success: val.valid,
        latencyMs: val.latencyMs,
        botInfo: val.botInfo,
        message: val.valid ? `Ping sukses: ${val.latencyMs} ms` : `Ping gagal: ${val.errorMessage}`
      });
    } catch (err) {
      res.status(500).json({ success: false, message: err.message });
    }
  });
  app.get("/api/multibot/rental-plans", (req, res) => {
    res.json({
      success: true,
      plans: botConfig.rentalPlans || DEFAULT_RENTAL_PLANS
    });
  });
  app.post("/api/multibot/rental-plans", (req, res) => {
    try {
      const { plans } = req.body;
      if (!Array.isArray(plans)) {
        return res.status(400).json({ success: false, message: "Format plans harus array." });
      }
      botConfig.rentalPlans = plans;
      saveBotConfig();
      addLog("system", `Daftar paket sewa bot diperbarui via Web.`);
      res.json({
        success: true,
        plans: botConfig.rentalPlans,
        message: "Paket sewa bot berhasil disimpan."
      });
    } catch (err) {
      res.status(500).json({ success: false, message: err.message });
    }
  });
  app.get(["/api/download/full-source-zip", "/downloads/axxosintbot-source.zip"], (req, res) => {
    try {
      const filename = `axxosintbot-full-source-${(/* @__PURE__ */ new Date()).toISOString().slice(0, 10)}.zip`;
      res.setHeader("Content-Type", "application/zip");
      res.setHeader("Content-Disposition", `attachment; filename="${filename}"`);
      res.setHeader("Cache-Control", "no-cache");
      const archive = archiver("zip", {
        zlib: { level: 9 }
        // Maximum compression
      });
      archive.on("error", (err) => {
        console.error("Error generating source zip:", err);
        if (!res.headersSent) {
          res.status(500).json({ success: false, message: `Gagal kompresi zip: ${err.message}` });
        }
      });
      archive.pipe(res);
      archive.glob("**/*", {
        cwd: process.cwd(),
        ignore: [
          "node_modules/**",
          ".git/**",
          "dist/**",
          ".cache/**",
          "coverage/**",
          "*.log",
          "project.zip",
          "axxosintbot-source.zip",
          "public/downloads/**"
        ],
        dot: true
      });
      const deployGuide = `# AXXOSINTBOT - PANDUAN LENGKAP HOSTING SENDIRI & NETLIFY

File zip ini berisi 100% SELURUH kode sumber aplikasi axxosintbot tanpa ada yang terpotong.
Anda dapat menjalankannya di VPS Linux Anda sendiri, Docker, ataupun di Netlify.

---

## \u{1F5A5}\uFE0F METODE 1: HOSTING DI SERVER / VPS LINUX SENDIRI (REKOMENDASI TERBAIK)
Cocok untuk: Ubuntu 20.04/22.04/24.04, Debian, CentOS, AlmaLinux, Arch, atau Docker VPS.
Persyaratan: Node.js 18 atau 20 ke atas (disertai npm).

### Langkah-langkah Cepat:
1. Upload & Ekstrak file zip ini di VPS:
   \`\`\`bash
   unzip axxosintbot-full-source-*.zip -d axxosintbot
   cd axxosintbot
   \`\`\`

2. Install dependency proyek:
   \`\`\`bash
   npm install
   \`\`\`

3. Build aplikasi frontend & backend bundle:
   \`\`\`bash
   npm run build
   \`\`\`

4. Jalankan server secara permanen 24/7 menggunakan PM2:
   \`\`\`bash
   # Install PM2 jika belum ada
   npm install -g pm2

   # Jalankan bot & website dashboard
   pm2 start "npm run dev" --name "axxosintbot"

   # Simpan agar otomatis hidup saat VPS reboot
   pm2 save
   pm2 startup
   \`\`\`

5. Selesai! Buka browser Anda:
   http://IP_VPS_ANDA:3000

---

## \u{1F310} METODE 2: DEPLOY DI NETLIFY (FRONTEND CLOUD)
Cocok jika Anda ingin tampilan website aktif di Netlify Cloud secara gratis.

### Langkah-langkah:
1. Di komputer lokal Anda, jalankan \`npm install && npm run build\`.
2. Folder \`dist/\` yang dihasilkan sudah otomatis memiliki file \`_redirects\` untuk SPA routing.
3. Buka https://app.netlify.com/drop di browser Anda.
4. Drag-and-drop folder \`dist/\` ke halaman Netlify Drop tersebut.
5. Website langsung aktif online dengan domain gratis .netlify.app!
6. Buka menu "Panduan Netlify / .ZIP" di website dan hubungkan URL backend VPS Anda.

---

## \u{1F451} KATA KUNCI OWNER & AKSES ADMIN
- Kata Kunci Default: ax0895 (bisa diubah di menu Owner Access Website)
- Perintah Telegram Tambah Bot: /addbot <token> [catatan] [tanggal_sewa] [jam]
- Perintah Telegram Atur Masa Sewa: /setexpiry <id/username> <tanggal> [jam]
- Perintah Telegram Hapus Bot: /delbot <id/username>
- Perintah Telegram List Bot: /listbot atau /multibot
- Kontrol OSINT: ax0895 on / ax0895 off
`;
      archive.append(deployGuide, { name: "PANDUAN_HOSTING_SENDIRI_DAN_NETLIFY.txt" });
      archive.finalize();
    } catch (err) {
      console.error("Error initiating zip download:", err);
      if (!res.headersSent) {
        res.status(500).json({ success: false, message: err.message });
      }
    }
  });
  app.get(["/api/download/netlify-dist-zip", "/downloads/axxosintbot-netlify-dist.zip"], (req, res) => {
    try {
      const filename = `axxosintbot-netlify-dist-${(/* @__PURE__ */ new Date()).toISOString().slice(0, 10)}.zip`;
      res.setHeader("Content-Type", "application/zip");
      res.setHeader("Content-Disposition", `attachment; filename="${filename}"`);
      res.setHeader("Cache-Control", "no-cache");
      const archive = archiver("zip", {
        zlib: { level: 9 }
      });
      archive.on("error", (err) => {
        console.error("Error generating netlify dist zip:", err);
        if (!res.headersSent) {
          res.status(500).json({ success: false, message: `Gagal kompresi dist: ${err.message}` });
        }
      });
      archive.pipe(res);
      const distDir = import_path2.default.join(process.cwd(), "dist");
      if (import_fs2.default.existsSync(distDir)) {
        archive.directory(distDir, false);
      } else {
        archive.glob("**/*", {
          cwd: process.cwd(),
          ignore: ["node_modules/**", ".git/**", "*.zip"]
        });
      }
      archive.append("/*    /index.html   200\n", { name: "_redirects" });
      archive.finalize();
    } catch (err) {
      if (!res.headersSent) {
        res.status(500).json({ success: false, message: err.message });
      }
    }
  });
  app.get("/api/traffic/logs", (req, res) => {
    res.json({
      success: true,
      logs: messageTrafficLogs || []
    });
  });
  app.post("/api/traffic/clear", (req, res) => {
    messageTrafficLogs = [];
    addLog("system", "Riwayat pemantau lalu lintas pesan dibersihkan oleh Admin.");
    res.json({ success: true, message: "Riwayat lalu lintas pesan berhasil dibersihkan." });
  });
  app.post("/api/traffic/reply", async (req, res) => {
    try {
      const { botId, chatId, text } = req.body;
      if (!chatId || !text) {
        return res.status(400).json({ success: false, message: "Chat ID dan teks pesan wajib diisi." });
      }
      let tokenToUse = botConfig.token;
      let senderUsername = currentBotInfo?.username || "axxosintbot";
      let senderName = currentBotInfo?.first_name || "Master Bot";
      if (botId && botId !== "primary") {
        const matchedBot = (botConfig.multiBots || []).find((b) => b.id === botId);
        if (matchedBot && matchedBot.token) {
          tokenToUse = matchedBot.token;
          senderUsername = matchedBot.botInfo?.username || senderUsername;
          senderName = matchedBot.botInfo?.first_name || senderName;
        }
      }
      const result = await sendTelegramMessage(chatId, text, void 0, "Markdown", tokenToUse);
      if (result) {
        res.json({ success: true, message: "Pesan balasan berhasil dikirim!" });
      } else {
        res.status(500).json({ success: false, message: "Gagal mengirim pesan melalui Telegram API." });
      }
    } catch (err) {
      res.status(500).json({ success: false, message: `Error kirim: ${err.message}` });
    }
  });
  app.post("/api/owner/verify-passkey", (req, res) => {
    try {
      const { passkey } = req.body;
      const expected = botConfig.ownerWebsitePasskey || "ax0895";
      const isValid = (passkey || "").trim().toLowerCase() === expected.trim().toLowerCase();
      res.json({
        success: isValid,
        message: isValid ? "Kata kunci owner valid." : "Kata kunci salah."
      });
    } catch (err) {
      res.status(500).json({ success: false, message: err.message });
    }
  });
  app.post("/api/owner/update-passkey", (req, res) => {
    try {
      const { oldPasskey, newPasskey } = req.body;
      const expected = botConfig.ownerWebsitePasskey || "ax0895";
      if ((oldPasskey || "").trim().toLowerCase() !== expected.trim().toLowerCase()) {
        return res.status(400).json({ success: false, message: "Kata kunci lama tidak cocok." });
      }
      if (!newPasskey || newPasskey.trim().length < 4) {
        return res.status(400).json({ success: false, message: "Kata kunci baru minimal 4 karakter." });
      }
      botConfig.ownerWebsitePasskey = newPasskey.trim();
      saveBotConfig();
      addLog("system", "Kata kunci akses Owner pada Website berhasil diperbarui.");
      res.json({
        success: true,
        message: "Kata kunci akses Owner berhasil disimpan!"
      });
    } catch (err) {
      res.status(500).json({ success: false, message: err.message });
    }
  });
  app.post("/api/broadcast/send", async (req, res) => {
    try {
      const { target, botId, text, customTargetIds, pinMessage } = req.body;
      if (!text || !text.trim()) {
        return res.status(400).json({ success: false, message: "Isi teks broadcast tidak boleh kosong." });
      }
      let targetChatIds = [];
      if (target === "groups") {
        const groups = botConfig.groupConfig?.knownGroups || [];
        targetChatIds = groups.map((g) => g.id);
      } else if (target === "all") {
        const groupIds = (botConfig.groupConfig?.knownGroups || []).map((g) => g.id);
        const userIds = (botConfig.activeUsers || []).map((u) => u.chatId);
        targetChatIds = Array.from(/* @__PURE__ */ new Set([...groupIds, ...userIds]));
      } else if (target === "custom") {
        const raw = String(customTargetIds || "");
        targetChatIds = raw.split(/[\n,;]+/).map((s) => s.trim()).filter(Boolean).map((s) => isNaN(Number(s)) ? s : Number(s));
      }
      if (targetChatIds.length === 0) {
        return res.status(400).json({ success: false, message: "Tidak ada target tujuan broadcast yang ditemukan." });
      }
      const availableBots = [];
      if (botConfig.isActive && botConfig.token) {
        availableBots.push({ token: botConfig.token, botInfo: currentBotInfo, id: "primary" });
      }
      for (const b of botConfig.multiBots || []) {
        if (b.isActive && b.token) {
          availableBots.push({ token: b.token, botInfo: b.botInfo, id: b.id });
        }
      }
      if (availableBots.length === 0) {
        return res.status(400).json({ success: false, message: "Tidak ada bot yang sedang aktif untuk mengirim broadcast." });
      }
      let successCount = 0;
      let failedCount = 0;
      for (let i = 0; i < targetChatIds.length; i++) {
        const cId = targetChatIds[i];
        let botToUse = availableBots[0];
        if (botId === "all_cluster") {
          botToUse = availableBots[i % availableBots.length];
        } else if (botId && botId !== "primary") {
          const matched = availableBots.find((b) => b.id === botId);
          if (matched) botToUse = matched;
        }
        try {
          const sent = await sendTelegramMessage(cId, text.trim(), void 0, "Markdown", botToUse.token);
          if (sent && sent.message_id) {
            successCount++;
            if (pinMessage && Number(cId) < 0) {
              callTelegramApi(botToUse.token, "pinChatMessage", {
                chat_id: cId,
                message_id: sent.message_id,
                disable_notification: false
              }).catch(() => {
              });
            }
          } else {
            failedCount++;
          }
        } catch {
          failedCount++;
        }
        if (targetChatIds.length > 1) {
          await new Promise((resolve) => setTimeout(resolve, 150));
        }
      }
      addLog("system", `Broadcast selesai disiarkan: ${successCount} berhasil, ${failedCount} gagal dari total ${targetChatIds.length} target.`);
      res.json({
        success: true,
        total: targetChatIds.length,
        successCount,
        failedCount,
        message: `Broadcast selesai! ${successCount} terkirim, ${failedCount} gagal.`
      });
    } catch (err) {
      res.status(500).json({ success: false, message: `Error broadcast: ${err.message}` });
    }
  });
  app.post("/api/pricing/save-all", (req, res) => {
    try {
      const { rentalPlans, quotaPackages, quotaConfig, referralConfig } = req.body;
      if (Array.isArray(rentalPlans)) {
        botConfig.rentalPlans = rentalPlans;
      }
      if (Array.isArray(quotaPackages)) {
        botConfig.quotaPackages = quotaPackages;
      }
      if (quotaConfig) {
        botConfig.quotaConfig = { ...DEFAULT_QUOTA_CONFIG, ...quotaConfig };
      }
      if (referralConfig) {
        botConfig.referralConfig = { ...DEFAULT_REFERRAL_CONFIG, ...referralConfig };
        saveReferralData();
      }
      saveBotConfig();
      addLog("system", "Seluruh pengaturan harga sewa bot dan paket kuota OSINT berhasil disimpan & diperbarui.");
      res.json({
        success: true,
        message: "Pengaturan harga & kuota berhasil disimpan dan langsung aktif di Telegram!",
        config: {
          rentalPlans: botConfig.rentalPlans,
          quotaPackages: botConfig.quotaPackages,
          quotaConfig: botConfig.quotaConfig,
          referralConfig: botConfig.referralConfig
        }
      });
    } catch (err) {
      res.status(500).json({ success: false, message: `Gagal simpan harga: ${err.message}` });
    }
  });
  app.post("/api/moderation/auto-load-strict", (req, res) => {
    try {
      if (!botConfig.moderationConfig) {
        botConfig.moderationConfig = { ...DEFAULT_MODERATION_CONFIG };
      }
      const existingSet = new Set(botConfig.moderationConfig.customBannedKeywords || []);
      let added = 0;
      DEFAULT_STRICT_BANNED_KEYWORDS.forEach((kw) => {
        if (!existingSet.has(kw)) {
          existingSet.add(kw);
          added++;
        }
      });
      botConfig.moderationConfig.customBannedKeywords = Array.from(existingSet);
      saveBotConfig();
      addLog("system", `Kamus kata kunci moderasi super ketat dimuat: +${added} kata baru ditambahkan.`);
      res.json({
        success: true,
        addedCount: added,
        totalCount: existingSet.size,
        customBannedKeywords: botConfig.moderationConfig.customBannedKeywords,
        message: `Berhasil memuat ${added} kata kunci terlarang ketat.`
      });
    } catch (err) {
      res.status(500).json({ success: false, message: err.message });
    }
  });
  if (process.env.NODE_ENV !== "production") {
    const vite = await (0, import_vite.createServer)({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    const distPath = import_path2.default.join(process.cwd(), "dist");
    app.use(import_express.default.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(import_path2.default.join(distPath, "index.html"));
    });
  }
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Telegram Bot Controller server running on http://localhost:${PORT}`);
    if (botConfig.isActive && botConfig.token) {
      console.log("[Telegram Bot] Resuming master bot from saved state (Always ON)...");
      verifyTelegramToken(botConfig.token).then((res) => {
        if (res.valid && res.botInfo) {
          currentBotInfo = res.botInfo;
          botStartedAt = Date.now();
          runTelegramPollingLoop().catch((loopErr) => {
            console.error("[Telegram Polling] Loop startup error:", loopErr);
          });
        } else {
          console.warn("[Telegram Bot] Saved token failed validation upon resume:", res.errorMessage);
          botConfig.isActive = false;
          saveBotConfig();
        }
      }).catch((err) => {
        console.error("[Telegram Bot] Error during token verification on resume:", err);
      });
    }
    if (Array.isArray(botConfig.multiBots)) {
      for (const bot of botConfig.multiBots) {
        if (bot.isActive && bot.token) {
          console.log(`[Multi-Bot Worker] Auto-resuming secondary worker @${bot.botInfo?.username || bot.id}...`);
          runSingleSecondaryBotWorker(bot).catch((err) => {
            console.error(`[Multi-Bot Worker] Startup error for ${bot.id}:`, err);
          });
        }
      }
    }
  });
}
startServer();
//# sourceMappingURL=server.cjs.map
